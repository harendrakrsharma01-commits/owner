/* Browser checks for the winter family + Scenario Workspace (v3.1).
 *   node tests/winter-scenarios.browser.js [http://127.0.0.1:8321]
 * Needs Playwright (PLAYWRIGHT_PATH may point at a global install) and the dev server. */
'use strict';
const { chromium } = require(process.env.PLAYWRIGHT_PATH || 'playwright');
const BASE = (process.argv[2] || 'http://127.0.0.1:8321').replace(/\/$/, '');
const PAGES = ['snow-day-calculator', 'snow-day-calculator-canada', 'ice-day-calculator', 'college-snow-day-calculator', 'cold-day-calculator', 'wind-chill-calculator'];
let pass = 0, fail = 0;
const ok = (c, m, x) => { if (c) pass++; else { fail++; console.log('FAIL ' + m + (x !== undefined ? '  got ' + JSON.stringify(x) : '')); } };

async function open(b, slug, w, scheme) {
  const ctx = await b.newContext({ viewport: { width: w || 1280, height: 900 }, colorScheme: scheme || 'light' });
  const p = await ctx.newPage(), errors = [], ext = [];
  p.on('pageerror', (e) => errors.push(String(e)));
  p.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
  p.on('request', (r) => { if (!r.url().startsWith(BASE) && !r.url().startsWith('data:')) ext.push(r.url()); });
  await p.goto(BASE + '/' + slug + '/'); await p.waitForTimeout(400);
  return { ctx, p, errors, ext };
}
const mainPct = (p) => p.evaluate(() => window.ECS.winterState.res.closure);

(async () => {
  const b = await chromium.launch({ executablePath: process.env.CHROME || undefined });

  for (const slug of PAGES) for (const w of [375, 390, 412, 768, 1280]) {
    const { ctx, p, errors, ext } = await open(b, slug, w, w === 390 ? 'dark' : 'light');
    const over = await p.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
    ok(over <= 0, `${slug} ${w}px: no horizontal overflow`, over);
    ok(errors.length === 0, `${slug} ${w}px: no console errors`, errors);
    ok(ext.length === 0, `${slug} ${w}px: no external requests (no live weather)`, ext);
    if (w === 1280) {
      const ids = await p.evaluate(() => { const a = [...document.querySelectorAll('[id]')].map((e) => e.id); return a.filter((x, i) => a.indexOf(x) !== i); });
      ok(ids.length === 0, `${slug}: no duplicate ids`, ids);
      const unlabeled = await p.evaluate(() => [...document.querySelectorAll('input:not([type=hidden]):not([type=radio]):not([type=checkbox]), select')].filter((i) => !i.labels.length && !i.getAttribute('aria-label') && !i.closest('[hidden]')).map((i) => i.id || i.className));
      ok(unlabeled.length === 0, `${slug}: every visible input has a label`, unlabeled);
      ok((await p.locator('#scenario-workspace').count()) === (slug === 'snow-day-calculator' ? 1 : 0), `${slug}: scenario workspace only on the main snow day page`);
      ok(await p.evaluate(() => !('geolocation' in navigator) || !window.__geoCalled), `${slug}: no geolocation call`);
    }
    await ctx.close();
  }

  /* ---- main page: workspace behaviour ---- */
  const { ctx, p, errors } = await open(b, 'snow-day-calculator', 1280);
  ok((await p.locator('h1').innerText()).includes('Prediction Scenarios'), 'H1 is the flagship wording');
  const tabs = await p.locator('[data-ws-tab]').count();
  ok(tabs === 8, '8 scenario tools as tabs (one URL)', tabs);
  // keyboard
  await p.focus('[data-ws-tab="delay"]'); await p.keyboard.press('ArrowRight');
  ok(await p.evaluate(() => document.activeElement.getAttribute('data-ws-tab')) === 'timeline', 'ArrowRight moves between tools');
  ok(await p.locator('#ws-panel-timeline').isVisible(), 'keyboard tab shows its panel');
  // four outcomes add to 100
  const outs = await p.locator('[data-ws-panel="delay"] .ws-bar-v').allInnerTexts();
  ok(outs.length === 4 && outs.reduce((t, x) => t + parseInt(x, 10), 0) === 100, 'delay vs closure: four outcomes add to 100', outs);
  // timeline → applies timing to the main calculator
  await p.click('[data-ws-tab="timeline"]');
  await p.fill('#ws-st', '05:00'); await p.fill('#ws-pk', '07:30'); await p.fill('#ws-en', '09:00'); await p.dispatchEvent('#ws-en', 'input');
  ok((await p.locator('[data-ws-out="timeline"]').innerText()).toLowerCase().includes('morning commute'), 'timeline: peak overlaps the morning commute');
  const before = await mainPct(p);
  await p.click('[data-ws-apply="timeline"]');
  ok(await p.evaluate(() => window.ECS.winterState.vals.timing) === 'commute', 'timeline applied → main timing is the commute');
  ok((await mainPct(p)) > before, 'commute timing raises the main estimate', [before, await mainPct(p)]);
  // blocks
  await p.check('#ws-tl-blocks'); await p.waitForTimeout(50);
  ok((await p.locator('[data-ws-blocks] tr').count()) === 3, 'three starting time blocks');
  await p.click('[data-ws-add-block]');
  ok((await p.locator('[data-ws-blocks] tr').count()) === 4, 'add a time block');
  ok((await p.locator('[data-ws-out="timeline"]').innerText()).includes('Totals'), 'blocks: totals shown');
  // treatment lowers the main result
  await p.click('[data-ws-tab="roads"]');
  const c0 = await mainPct(p);
  await p.selectOption('#ws-treat', 'well');
  ok((await mainPct(p)) < c0, 'road treatment lowers the main estimate', [c0, await mainPct(p)]);
  ok(await p.evaluate(() => window.ECS.winterState.res.factors.some((f) => f.key === 'treatment')), 'treatment listed as a factor');
  ok((await p.locator('#ww-why').innerText()).includes('→'), '“Why did my result change?” shows previous → new');
  await p.selectOption('#ws-treat', 'none');
  // policy
  await p.click('[data-ws-tab="policy"]');
  const c1 = await mainPct(p);
  await p.selectOption('#ws-policy', 'higher');
  ok((await mainPct(p)) < c1, 'higher policy threshold lowers the estimate');
  await p.selectOption('#ws-policy', 'custom');
  ok(await p.locator('#ws-policy-custom').isVisible(), 'custom policy shows its input');
  await p.fill('#ws-policy-custom', 'abc'); await p.dispatchEvent('#ws-policy-custom', 'input');
  ok(Number.isFinite(await mainPct(p)), 'invalid custom value does not break the estimate');
  await p.selectOption('#ws-policy', 'typical');
  ok((await p.locator('[data-ws-panel="policy"]').innerText()).includes('not an official district policy'), 'snow-days-used disclaimer visible');
  // bus, commute, plow, compare render
  for (const t of ['bus', 'commute', 'plow']) { await p.click(`[data-ws-tab="${t}"]`); ok((await p.locator(`[data-ws-out="${t}"]`).innerText()).trim().length > 10, `${t} tool renders a result`); }
  await p.fill('#ws-pl-n', '0'); await p.dispatchEvent('#ws-pl-n', 'input');
  ok((await p.locator('[data-ws-panel="plow"] [data-ws-error]').innerText()).length > 5, 'plow: invalid plows → error message');
  await p.fill('#ws-pl-n', '6'); await p.dispatchEvent('#ws-pl-n', 'input');
  await p.click('[data-ws-tab="compare"]');
  await p.click('[data-ws-add-c]');
  ok((await p.locator('.ws-cmp-table thead th').count()) === 4, 'what-if: A, B and C columns');
  ok((await p.locator('.ws-cmp-table').innerText()).includes('Biggest change'), 'what-if: biggest change row');
  // units switch keeps the result
  const r1 = await mainPct(p);
  await p.check('input[name="ww-units"][value="metric"]'); await p.waitForTimeout(50);
  ok((await mainPct(p)) === r1, 'switching units does not change the result');
  ok((await p.locator('[data-ws-unit="dist"]').first().innerText()) === '(km)', 'workspace distance unit follows the unit switch');
  ok(errors.length === 0, 'main page: no console errors during interaction', errors);
  await ctx.close();

  /* ---- reduced motion ---- */
  const rm = await b.newContext({ reducedMotion: 'reduce' }); const rp = await rm.newPage(); const re = [];
  rp.on('pageerror', (e) => re.push(String(e)));
  await rp.goto(BASE + '/snow-day-calculator/'); await rp.waitForTimeout(300);
  ok(re.length === 0, 'reduced motion: page works');
  await rm.close();

  await b.close();
  console.log(`\n${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})();
