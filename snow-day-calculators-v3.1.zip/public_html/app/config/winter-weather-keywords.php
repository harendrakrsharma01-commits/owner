<?php
/**
 * EasyCalculatorSmart — Winter weather family: SEO KEYWORD REGISTRY (v3.1).
 *
 * Content / SEO data only. No calculator code reads this file — removing
 * it changes nothing on the pages' maths. Use it to plan headings, FAQs
 * and internal links; add a keyword here (not in PHP/JS) when the target
 * page and section already cover it.
 *
 * Fields
 *   keyword   the search phrase
 *   lang      language code
 *   market    country / market
 *   intent    primary | scenario | feature | informational | navigational
 *   page      target page slug (existing pages only)
 *   section   article anchor or scenario tool on that page
 *   priority  high | medium | low   (editorial priority, NOT search volume)
 *   status    covered | supporting | avoid
 *   serp      what the October 2026 SERP scan showed, in words — no volume,
 *             KD or CPC figures were available or are implied
 */

declare(strict_types=1);

$k = static fn (string $keyword, string $intent, string $page, string $section, string $priority, string $status, string $serp, string $market = 'US') => [
    'keyword' => $keyword, 'lang' => 'en', 'market' => $market, 'intent' => $intent, 'page' => $page,
    'section' => $section, 'priority' => $priority, 'status' => $status, 'serp' => $serp,
];

return [
    'checked' => '2026-10-01',
    'method'  => 'Web search result pages (titles, snippets, summaries). Google autocomplete / People Also Ask could not be queried from the build environment; no keyword-volume tool data was used.',

    'keywords' => [
        /* A. Existing keywords worth keeping */
        $k('snow day calculator', 'primary', 'snow-day-calculator', 'guide-heading', 'high', 'covered', 'Crowded: many dedicated calculators, most with ZIP lookup and accuracy claims.'),
        $k('snow day predictor', 'primary', 'snow-day-calculator', 'calculator-vs-predictor', 'high', 'covered', 'Crowded; same intent as snow day calculator.'),
        $k('school snow day calculator', 'primary', 'snow-day-calculator', 'guide-heading', 'medium', 'supporting', 'Same intent as snow day calculator.'),
        $k('snow day probability calculator', 'primary', 'snow-day-calculator', 'reading', 'medium', 'covered', 'Covered by general calculators; page labels results as an estimated scenario probability.'),
        $k('snow day calculator today', 'informational', 'snow-day-calculator', 'today-tomorrow', 'medium', 'covered', 'General calculators; manual input covers today/tomorrow.'),
        $k('snow day calculator tomorrow', 'informational', 'snow-day-calculator', 'today-tomorrow', 'medium', 'covered', 'General calculators.'),
        $k('how much snow for a snow day', 'informational', 'snow-day-calculator', 'how-much-snow', 'medium', 'covered', 'News explainers and a widely shared threshold map.'),
        $k('snow day calculator canada', 'primary', 'snow-day-calculator-canada', 'guide-heading', 'high', 'covered', 'Several Canada-specific tools; kept on its own page.', 'CA'),
        $k('ice day calculator', 'primary', 'ice-day-calculator', 'guide-heading', 'high', 'covered', 'Few dedicated results.'),
        $k('college snow day calculator', 'primary', 'college-snow-day-calculator', 'guide-heading', 'high', 'covered', 'Few dedicated results.'),
        $k('cold day calculator', 'primary', 'cold-day-calculator', 'guide-heading', 'medium', 'covered', 'Few dedicated results.'),
        $k('wind chill calculator', 'primary', 'wind-chill-calculator', 'guide-heading', 'high', 'covered', 'Crowded; NWS chart ranks.'),

        /* B. New keyword opportunities — features of the ONE snow day page */
        $k('snow day prediction calculator', 'primary', 'snow-day-calculator', 'calculator-vs-predictor', 'high', 'covered', 'Covered by general calculators; no separate intent.'),
        $k('snow day delay vs closure calculator', 'scenario', 'snow-day-calculator', 'delay-vs-closure', 'high', 'covered', 'No dedicated standalone result surfaced in this SERP scan; some calculators show a delay chance as a feature.'),
        $k('snow day early dismissal calculator', 'scenario', 'snow-day-calculator', 'delay-vs-closure', 'high', 'covered', 'No dedicated standalone result surfaced; one tool mentions early-dismissal probabilities as a feature.'),
        $k('snow day late start calculator', 'scenario', 'snow-day-calculator', 'delay-vs-closure', 'medium', 'covered', 'No dedicated standalone result surfaced; district delay-schedule pages dominate.'),
        $k('2 hour delay predictor', 'scenario', 'snow-day-calculator', 'delay-vs-closure', 'high', 'covered', 'No dedicated standalone result surfaced; district FAQ PDFs rank.'),
        $k('snow day storm timing calculator', 'feature', 'snow-day-calculator', 'storm-timing', 'high', 'covered', 'No dedicated standalone result surfaced; competitors weight morning-commute snow as a feature.'),
        $k('snow day snowfall timing calculator', 'feature', 'snow-day-calculator', 'storm-timing', 'medium', 'covered', 'No dedicated standalone result surfaced.'),
        $k('snow day commute risk calculator', 'feature', 'snow-day-calculator', 'morning-commute', 'medium', 'covered', 'No dedicated standalone result surfaced.'),
        $k('snow day morning commute calculator', 'feature', 'snow-day-calculator', 'morning-commute', 'medium', 'covered', 'No dedicated standalone result surfaced.'),
        $k('snow day school bus calculator', 'feature', 'snow-day-calculator', 'school-bus-risk', 'medium', 'covered', 'No dedicated standalone result surfaced; district snow-route PDFs rank.'),
        $k('snow day bus route risk calculator', 'feature', 'snow-day-calculator', 'school-bus-risk', 'medium', 'covered', 'No dedicated standalone result surfaced.'),
        $k('snow day road condition calculator', 'feature', 'snow-day-calculator', 'road-conditions', 'medium', 'covered', 'No dedicated standalone result surfaced; one competitor lists road scores (rural, hills, treatment) as a feature.'),
        $k('snow day road treatment calculator', 'feature', 'snow-day-calculator', 'road-conditions', 'low', 'covered', 'No dedicated standalone result surfaced; salt/brine news explainers rank.'),
        $k('snow day ice risk calculator school', 'feature', 'snow-day-calculator', 'ice', 'medium', 'covered', 'Ice day calculator covers the dedicated intent.'),
        $k('snow day freezing rain calculator', 'feature', 'ice-day-calculator', 'guide-heading', 'medium', 'covered', 'Few results; ice page is the target.'),
        $k('snow day visibility calculator', 'feature', 'snow-day-calculator', 'road-conditions', 'low', 'supporting', 'No dedicated standalone result surfaced.'),
        $k('snow day district policy calculator', 'feature', 'snow-day-calculator', 'district-policy', 'medium', 'covered', 'No dedicated standalone result surfaced; one competitor offers neutral/liberal/conservative district settings.'),
        $k('snow day regional threshold calculator', 'feature', 'snow-day-calculator', 'district-policy', 'low', 'covered', 'No dedicated standalone result surfaced; threshold maps and news explainers rank.'),
        $k('snow day closure threshold calculator', 'feature', 'snow-day-calculator', 'district-policy', 'low', 'supporting', 'No dedicated standalone result surfaced.'),
        $k('snow day snow days used calculator', 'feature', 'snow-day-calculator', 'district-policy', 'low', 'covered', 'Competitors ask for snow days to date as an input; no standalone result.'),
        $k('snow day plowing calculator school', 'feature', 'snow-day-calculator', 'plowing', 'low', 'covered', 'No school-focused result surfaced; contractor plow-productivity guides rank.'),
        $k('snow day what if calculator', 'scenario', 'snow-day-calculator', 'what-if', 'high', 'covered', 'No dedicated standalone result surfaced; one competitor lists example scenarios.'),
        $k('snow day school cancellation scenario calculator', 'scenario', 'snow-day-calculator', 'what-if', 'low', 'supporting', 'No dedicated standalone result surfaced.'),
        $k('snow day disruption scenario calculator', 'scenario', 'snow-day-calculator', 'what-if', 'low', 'supporting', 'No dedicated standalone result surfaced.'),
        $k('snow day weather impact calculator', 'scenario', 'snow-day-calculator', 'model', 'low', 'supporting', 'No dedicated standalone result surfaced.'),
        $k('snow day wind chill calculator school closure', 'feature', 'cold-day-calculator', 'guide-heading', 'medium', 'covered', 'Cold day page is the target; NWS closing-for-cold guidance ranks.'),

        /* C. Crowded keywords — keep in copy, don't expect quick gains */
        $k('snow day calculator accuracy', 'informational', 'snow-day-calculator', 'accuracy', 'low', 'covered', 'Crowded with accuracy claims; page deliberately claims none.'),
        $k('school closure prediction calculator', 'primary', 'snow-day-calculator', 'guide-heading', 'low', 'supporting', 'Same intent as snow day predictor; crowded.'),

        /* D. Unsupported / speculative — do not target */
        $k('snow day calculator zip code', 'navigational', 'snow-day-calculator', 'calculator-vs-predictor', 'low', 'avoid', 'Implies automatic ZIP forecast lookup, which this calculator deliberately does not do.'),
        $k('snow day calculator 85% accurate', 'informational', 'snow-day-calculator', 'accuracy', 'low', 'avoid', 'Accuracy claims cannot be supported; the model is a heuristic.'),
        $k('live snow day predictor', 'navigational', 'snow-day-calculator', 'calculator-vs-predictor', 'low', 'avoid', 'Implies live weather; not offered.'),
    ],
];
