# Winter weather family v3.1 — Scenario system report

Date: 1 October 2026. Base: the supplied `snow-day-calculators.zip` (v3.0, manual weather input).
Nothing was rebuilt; the existing engine, config, articles, visuals and tests were extended.

## 1. Architecture after v3.1

```
app/config/winter-weather.php            CENTRAL: model weights, timing, roads, visibility, visuals, pages, FAQ
app/config/winter-weather-scenarios.php  NEW: scenario rules (outcome split, timeline windows, treatment,
                                          bus, commute, policy/region profiles, snow days used, plowing, what-if)
app/config/winter-weather-keywords.php   NEW: SEO keyword registry — content data, never read by calculators
app/config/winter-weather-articles.php   article sections (9 new sections on the snow day page)
app/includes/winter-ui.php               renderer (+ scenario workspace scaffold, scenarios in page JSON)
assets/js/lib/snowday.js                 engine: PHYSICS (wind chill, units) + HEURISTIC (config-driven)
assets/js/lib/snowday-scenarios.js       NEW engine: arithmetic only, all assumptions from scenarios config
assets/js/calculators/winter-calc.js     page UI (+ scenario hook, richer "why did my result change")
assets/js/calculators/winter-scenarios.js NEW workspace UI (tabs, panels)
assets/js/lib/winter-scene.js            animation (duplicated fallbacks removed; reads config only)
assets/css/snow-day.css (+ .min.css)     scoped styles (+ workspace, table scrolling)
```

**Physics vs heuristic** — `snowday.js` keeps the published NWS/ECCC wind chill formulas and unit
conversions; every school-decision number (points, shifts, bands, splits) lives in the two config files.
`snowday-scenarios.js` contains only clock, percent and distance ÷ speed arithmetic (a test fails if a
model constant appears in it).

**One URL.** All new intents are tools inside `/snow-day-calculator/` (8 tabs). No new pages; the six
existing pages keep their own intent (general K-12, Canada, ice, college, cold, wind chill formula).

## 2. Keyword report

Method: web-search result pages (titles, snippets, summaries), Oct 2026. Google autocomplete/PAA could not
be queried from the build environment; **no volume, KD, CPC or ranking data was used or is implied.**
"No dedicated standalone result surfaced" means only that — not "no competition".

### A. Existing keywords worth keeping
| Keyword | Intent | Dedicated SERP result? | Broader competitor feature? | Target page | Section | Usage |
|---|---|---|---|---|---|---|
| snow day calculator | primary | Yes, many | — | snow-day-calculator | guide-heading | title, H1, intro |
| snow day predictor | primary | Yes, many | — | snow-day-calculator | calculator-vs-predictor | title, H2 |
| snow day probability calculator | primary | Covered by general tools | Yes | snow-day-calculator | reading | result label |
| snow day calculator today / tomorrow | informational | General tools | Yes | snow-day-calculator | today-tomorrow | FAQ |
| how much snow for a snow day | informational | News explainers, threshold map | — | snow-day-calculator | how-much-snow | H2 |
| snow day calculator canada | primary | Several | — | snow-day-calculator-canada | guide-heading | own page |
| ice day / college snow day / cold day / wind chill calculator | primary | Few / crowded (wind chill) | — | own pages | guide-heading | own pages |

### B. New keyword opportunities (features of the one page)
| Keyword | Intent | Dedicated SERP result? | Broader competitor feature? | Section | Usage |
|---|---|---|---|---|---|
| snow day prediction calculator | primary | Covered by general tools | Yes | calculator-vs-predictor | intro copy |
| snow day delay vs closure calculator | scenario | None surfaced | Some show a delay chance | delay-vs-closure | tab, H2, FAQ |
| snow day early dismissal calculator | scenario | None surfaced | One mentions early-dismissal % | delay-vs-closure | H2, FAQ |
| snow day late start calculator / 2 hour delay predictor | scenario | None surfaced (district PDFs rank) | — | delay-vs-closure | H2 copy |
| snow day storm / snowfall timing calculator | feature | None surfaced | Timing weighting as a feature | storm-timing | tab, H2 |
| snow day commute risk / morning commute calculator | feature | None surfaced | — | morning-commute | tab, H2 |
| snow day school bus / bus route risk calculator | feature | None surfaced (route PDFs rank) | — | school-bus-risk | tab, H2, FAQ |
| snow day road condition / road treatment calculator | feature | None surfaced | One lists road/treatment scores | road-conditions | tab, H2, FAQ |
| snow day district policy / regional threshold / closure threshold calculator | feature | None surfaced | One offers neutral/liberal/conservative settings | district-policy | tab, H2 |
| snow day snow days used calculator | feature | None surfaced | Some ask "snow days to date" | district-policy | tab copy |
| snow day plowing calculator school | feature | None school-focused (plow-productivity guides) | — | plowing | tab, H2 |
| snow day what if / cancellation / disruption scenario calculator | scenario | None surfaced | One lists example scenarios | what-if | tab, H2, FAQ |
| snow day freezing rain calculator / ice risk | feature | Few | — | ice-day-calculator, ice | links |
| snow day wind chill calculator school closure | feature | NWS guidance ranks | — | cold-day-calculator | links |

### C. Crowded
snow day calculator accuracy (accuracy claims everywhere — page claims none), school closure prediction calculator.

### D. Unsupported / speculative — avoid
"snow day calculator zip code", "live snow day predictor" (imply live lookup), "85% accurate" (unsupportable).

Full registry with status per keyword: `app/config/winter-weather-keywords.php`.

## 3. Feature report
| Existing feature | Changed? | New feature | Central config location | SEO intent |
|---|---|---|---|---|
| Closure / delay / normal estimate | Labels: "estimated scenario probability" | 4 outcomes: closed / late start / early dismissal / normal | scenarios `outcomes` | delay vs closure, early dismissal, late start |
| Storm timing selector | Kept | Clock-time and time-block timeline, apply to calculator | scenarios `timeline` | storm / snowfall timing |
| Morning commute road choice | Kept | Road treatment (temp + age effectiveness) | scenarios `treatment`; roads in winter-weather `commute` | road condition / treatment |
| Visibility bands | Kept (config) | Used by bus & commute scores | winter-weather `visibility` | visibility |
| Ice / freezing rain / refreeze | Kept | Block types snow/mixed/freezing rain/rain | winter-weather `model.ice`, `refreeze`; scenarios `block_types` | ice / freezing rain |
| School settings (tendency, area) | Kept | District policy profiles, regional tolerance, snow days used (off by default) | scenarios `policy`, `region`, `days_used` | district policy, regional threshold, snow days used |
| — | — | School bus route risk (optional estimate points, capped) | scenarios `bus` | school bus risk |
| — | — | Commute risk (informational) | scenarios `commute_risk` | commute risk |
| — | — | Plowing scenario (theoretical) | scenarios `plow` | plowing |
| — | — | What-if comparison A/B/C | scenarios `compare` | what-if, cancellation scenario |
| "Why did my result change?" | Now shows previous → new value per factor | — | model `change_threshold` | sensitivity |
| Weather scene | Duplicated JS fallbacks removed | — | winter-weather `visuals` (+ `mix`, `strength`, `timeline_min`, `mist_min_scale`) | — |

## 4. Tests
- `tests/snowday-lib.test.js` (existing): **477 passed** — unchanged expectations.
- `tests/winter-scenarios.test.js` (new): **111 passed** — all scenario tools, invalid/zero/extreme input,
  units, central-config tests (snow table, road weight, policy shift, outcome split edited only in PHP
  config → result changes; restored → original), no-magic-number scan, year scan, no-live-data scan,
  keyword registry integrity.
- `tests/winter-scenarios.browser.js` (new, Playwright): **142 passed** — 6 pages × 375/390/412/768/1280 px
  (no overflow, no console errors, no external requests), labels, duplicate IDs, keyboard tabs, timeline →
  main result, treatment/policy → main result, what-if A/B/C, unit switch invariance, reduced motion.
- `tests/winter-pages.test.js` (existing) needs the real site (sitemap, tools registry); it was not runnable
  in the build environment and must be run on the dev server. Its page list is unchanged (no new URLs).

## 5. Remaining hardcoded values (audit)
- Allowed: wind chill formula coefficients, unit factors (2.54, 25.4, 1.609344, 1.852, 3.6, 9/5), clock
  arithmetic (60, 1440, 12/24 h), percent (100).
- UI drawing geometry in `winter-scene.js` (particle spawn offsets, splash height, near-flake speed factor)
  and input rounding in `snowday.js displayDp` — presentation, not model or animation thresholds.
- No closure threshold, road, bus, snow, policy, scenario or region number remains in JS.

## 6. WHAT WILL STILL WORK WITHOUT EDITING IN FUTURE YEARS
- Calculation engine and scenario engine (no dates, no years, no services).
- Unit conversion and wind chill formulas.
- Manual scenario calculator, four outcomes, delay vs closure.
- Timeline (clock times and blocks), what-if comparison, plowing arithmetic.
- Step-by-step explanations and "why did my result change".
- Weather animation, reduced motion, mobile layout.
- Generic policy, regional and snow-days-used profiles.
- Works offline once the page assets are loaded.

## 7. WHAT MAY EVENTUALLY NEED DATA REFRESH (never required for the calculator to work)
- Source URLs in `winter-weather.php` `references` (link rot; check yearly).
- State notes (`us_state_notes`) and Canadian area profiles — written as dated facts ("checked" date shown).
- The NYC note was reworded as history ("since 2020…, for example in February 2026") so it does not go stale.
- Keyword registry (editorial; does not affect results).

## 8. Where to edit
| Change | File |
|---|---|
| Snow / ice / cold / wind weights, closure centre, bands | `app/config/winter-weather.php` → `model` |
| Road categories, visibility bands, storm timings | `winter-weather.php` → `commute`, `visibility`, `timing` |
| Delay vs early-dismissal split, timeline windows, messages | `app/config/winter-weather-scenarios.php` → `outcomes`, `timeline` |
| Treatment, bus, commute scoring | `winter-weather-scenarios.php` → `treatment`, `bus`, `commute_risk` |
| Policy / region profiles, snow-days-used heuristic | `winter-weather-scenarios.php` → `policy`, `region`, `days_used` |
| Plow assumptions, what-if starts | `winter-weather-scenarios.php` → `plow`, `compare` |
| Keywords | `app/config/winter-weather-keywords.php` |
| Article text | `app/config/winter-weather-articles.php` |
| Title / meta / H1 / FAQ | `winter-weather.php` → `pages` |
| Animation | `winter-weather.php` → `visuals` |
| Engine code | only when a formula itself changes |

## 9. Production upload list
UPLOAD TO PRODUCTION (`public_html/`):
- app/config/winter-weather.php *(changed)*
- app/config/winter-weather-articles.php *(changed)*
- app/config/winter-weather-scenarios.php *(new)*
- app/config/winter-weather-keywords.php *(new — content data)*
- app/includes/winter-ui.php *(changed)*
- assets/js/lib/snowday.js *(changed)*
- assets/js/lib/snowday-scenarios.js *(new)*
- assets/js/lib/winter-scene.js *(changed)*
- assets/js/calculators/winter-calc.js *(changed)*
- assets/js/calculators/winter-scenarios.js *(new)*
- assets/css/snow-day.css *(changed)*, assets/css/snow-day.min.css *(regenerated — was an empty file)*

Unchanged and not needed again: the six `app/calculators/*.php` files, `wind-chill.js`.

TEST / DOCUMENTATION ONLY: `tests/winter-scenarios.test.js`, `tests/winter-scenarios.browser.js`,
`tests/export-winter-config-override.php`, this report.

After upload: clear any page/asset cache (asset versions are not in this package), run
`node tests/snowday-lib.test.js`, `node tests/winter-scenarios.test.js`, then `node tests/winter-pages.test.js`
and `node tests/winter-scenarios.browser.js` against the dev server.
