<?php
/**
 * EasyCalculatorSmart — wind-chill-calculator.
 *
 * Built entirely from the winter weather family's central configuration:
 *   settings, model, SEO, FAQ, sources  app/config/winter-weather.php
 *   article sections                     app/config/winter-weather-articles.php
 *   page layout                          app/includes/winter-ui.php
 * Edit those, not this file.
 */

declare(strict_types=1);

if (!defined('ECS_BOOTSTRAPPED')) {
    exit;
}

require_once ECS_INCLUDES . '/winter-ui.php';

winter_render($tool);
