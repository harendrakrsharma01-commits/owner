<?php
/**
 * Prints the browser config of one winter weather page as JSON — the same
 * document the page embeds as #ww-config — so tests/snowday-lib.test.js
 * runs the engine on the real settings instead of a copy.
 *
 *   php tests/export-winter-config.php snow-day-calculator
 */

declare(strict_types=1);

$_SERVER['REQUEST_URI'] = '/';
$_SERVER['HTTP_HOST'] = $_SERVER['HTTP_HOST'] ?? 'easycalculatorsmart.com';
require dirname(__DIR__) . '/public_html/app/config/config.php';
require_once ECS_INCLUDES . '/functions.php';
foreach (['i18n.php', 'icons.php', 'calc-ui.php'] as $inc) {
    if (is_file(ECS_INCLUDES . '/' . $inc)) {
        require_once ECS_INCLUDES . '/' . $inc;
    }
}
require_once ECS_INCLUDES . '/winter-ui.php';

$slug = $argv[1] ?? 'snow-day-calculator';
echo json_encode(winter_client_config($slug), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
