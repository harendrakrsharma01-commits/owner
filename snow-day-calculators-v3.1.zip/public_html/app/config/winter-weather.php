<?php
/**
 * EasyCalculatorSmart — Winter weather family: THE central configuration.
 *
 * Version 3 (2026-09-25): MANUAL weather calculators. There is no live
 * forecast, no weather API, no geocoding and no location access anywhere
 * in the family. The reader types (or picks) the conditions from their own
 * local forecast; the page calculates from exactly those values and the
 * weather scene behind the calculator follows them.
 *
 * One file drives the six pages (snow day, Canada, ice day, college, cold
 * day, wind chill). The PHP pages read it directly and the browser gets
 * the parts it needs as one JSON block (winter_client_config() in
 * app/includes/winter-ui.php). No weight, threshold, label, preset or
 * animation setting is repeated in a JavaScript file.
 *
 *   references        official and reference sources (articles, panels)
 *   units             the two unit systems and their labels
 *   countries         country context: units, wording, who decides
 *   region_codes      US states and Canadian provinces (context only)
 *   ca_areas          Canadian board / consortium profiles
 *   us_state_notes    sourced state facts, shown when the state matches
 *   school_types, area_types, tendency, commute_sensitivity
 *   college           campus settings and class times
 *   fields            every manual input: label, unit, limits, hint
 *   conditions        the weather condition selector (11 conditions)
 *   timing            storm timing (the evening → school-hours timeline)
 *   commute           morning commute conditions
 *   visibility        visibility choices
 *   rain_intensity    rain intensity choices
 *   model             every heuristic weight and threshold
 *   visuals           the weather scene: particles, speeds, intensities
 *   risk_bands        Environment Canada wind chill risk table
 *   presets           the example scenarios (values + expected results)
 *   disclaimers       sentences every page must carry
 *   pages             per-page SEO, fields, labels, presets, FAQ, sources
 *
 * Long article prose lives next door in winter-weather-articles.php.
 *
 * HONESTY RULES THIS CONFIG ENCODES
 * - The model is a documented heuristic. Nothing here was fitted to
 *   closure records (no public dataset pairs forecasts with closure
 *   decisions). No page may claim an accuracy percentage.
 * - Nothing is fetched: not the weather, not alerts, not closures. The
 *   visual thresholds below drive the animation only; they are not
 *   closure rules.
 * - Units: the engine works in cm, mm, °C and km/h. Switching units
 *   changes what is displayed, never the result.
 */

declare(strict_types=1);

return [

    'version' => '3.1',
    'checked' => '2026-10-01',

    /* =================================================================
     * REFERENCES — [label, url, note]. Keyed so a page lists the ones it
     * needs. None of them is read automatically.
     * ============================================================== */
    'references' => [
        'nws_home'         => ['National Weather Service', 'https://www.weather.gov/', 'official US forecasts, watches and warnings'],
        'nws_cold'         => ['NWS — Closing for cold', 'https://www.weather.gov/wrn/closing-for-cold', 'superintendents decide; how they use hourly forecasts'],
        'nws_wind_chill'   => ['NWS wind chill chart', 'https://www.weather.gov/safety/cold-wind-chill-chart', 'the °F formula, valid range and frostbite times'],
        'nws_ice'          => ['NWS — Winter weather safety: ice storms', 'https://www.weather.gov/safety/winter-ice-frost', 'freezing rain, ice storms and what a glaze does'],
        'wpc_wssi'         => ['NWS Winter Storm Severity Index', 'https://www.wpc.ncep.noaa.gov/wwd/wssi/wssi.php', 'official outlook of winter storm impacts, days 1–3'],
        'eccc_home'        => ['Environment Canada weather and warnings', 'https://weather.gc.ca/', 'official Canadian forecasts and alerts'],
        'eccc_alert_types' => ['Environment Canada — public weather alerts', 'https://www.canada.ca/en/environment-climate-change/services/types-weather-forecasts-use/public/criteria-alerts.html', 'how warnings, watches and advisories are issued'],
        'eccc_wind_chill'  => ['Environment Canada — Wind chill and the Wind Chill Index', 'https://www.canada.ca/en/services/environment/weather/severeweather/wind-chill-index.html', 'risk bands and the metric formula'],
        'mde_michigan'     => ['Michigan Department of Education — snow days', 'https://www.michigan.gov/mde/news-and-information/press-releases/2015/02/05/winter-weather-prompts-snow-days-questions', 'forgiven days under MCL 388.1701'],
        'pde_fid'          => ['Pennsylvania Department of Education — Flexible Instructional Days', 'https://www.pa.gov/agencies/education/programs-and-services/schools/school-services/flexible-instructional-days', 'up to five instruction-at-home days'],
        'mn_elearning'     => ['Minnesota Statutes §120A.414 — E-learning days', 'https://www.revisor.mn.gov/statutes/cite/120A.414', 'up to five e-learning days a year'],
        'nyc_remote'       => ['Chalkbeat New York — NYC schools and remote snow days', 'https://www.chalkbeat.org/newyork/2026/01/21/nyc-schools-remote-learning-winter-storm-plan/', 'remote learning instead of traditional snow days'],
        'nyc_waiver'       => ['Chalkbeat New York — February 2026 snow day waiver', 'https://www.chalkbeat.org/newyork/2026/02/22/mamdani-announces-nyc-schools-snow-day-for-february-2026-blizzard/', 'a traditional snow day by state waiver'],
        'dfe_emergency'    => ['GOV.UK — Emergency planning and response for education settings', 'https://www.gov.uk/government/publications/emergency-planning-and-response-for-education-childcare-and-childrens-social-care-settings', 'school leaders decide on closure (England)'],
        'met_office'       => ['Met Office weather warnings', 'https://weather.metoffice.gov.uk/warnings-and-advice/uk-warnings', 'official UK warnings'],
        'cp24_gta'         => ['CP24 — how GTA school boards decide in winter weather', 'https://www.cp24.com/local/toronto/2025/11/28/how-and-when-do-school-boards-in-the-greater-toronto-area-close-due-to-winter-weather/', 'TDSB, Peel, York, Durham and Halton timing'],
    ],

    /* =================================================================
     * UNITS — display only. `snow`/`rate` in cm or inches; `rain`/`ice`
     * in mm or inches; the engine never sees these.
     * ============================================================== */
    'units' => [
        'us'     => ['label' => '°F · in · mph',   'temp' => '°F', 'snow' => 'in', 'rate' => 'in/h', 'ice' => 'in', 'rain' => 'in', 'wind' => 'mph'],
        'metric' => ['label' => '°C · cm · km/h',  'temp' => '°C', 'snow' => 'cm', 'rate' => 'cm/h', 'ice' => 'mm', 'rain' => 'mm', 'wind' => 'km/h'],
    ],

    /* =================================================================
     * COUNTRIES — context only. The country picks the units, the words
     * and the "who decides" note. It never fetches anything.
     * ============================================================== */
    'countries' => [
        'US' => [
            'name'         => 'United States',
            'units'        => 'us',
            'region_label' => 'State',
            'postal_label' => 'ZIP code (optional)',
            'postal_hint'  => 'Context only — it is not looked up and no weather is fetched for it.',
            'postal_max'   => 10,
            'weather_authority' => 'the National Weather Service',
            'decider'      => 'your school district — usually the superintendent',
            'refs'         => ['nws_home', 'wpc_wssi', 'nws_cold'],
            'note'         => 'The National Weather Service forecasts the weather but does not close schools; your school district makes the call.',
            'forecast_tip' => 'Take the figures from your local forecast or the National Weather Service forecast for your town.',
        ],
        'CA' => [
            'name'         => 'Canada',
            'units'        => 'metric',
            'region_label' => 'Province or territory',
            'postal_label' => 'Postal code (optional)',
            'postal_hint'  => 'Context only — it is not looked up and no weather is fetched for it.',
            'postal_max'   => 7,
            'weather_authority' => 'Environment and Climate Change Canada',
            'decider'      => 'your school board — and, for buses, your student transportation consortium',
            'refs'         => ['eccc_home', 'eccc_alert_types'],
            'note'         => 'Environment and Climate Change Canada issues weather warnings; your school board (and, for buses, your transportation consortium) makes the call.',
            'forecast_tip' => 'Take the figures from your local forecast or Environment Canada’s forecast for your town.',
        ],
        'OTHER' => [
            'name'         => 'Another country',
            'units'        => 'metric',
            'region_label' => 'Region',
            'postal_label' => 'Postal code (optional)',
            'postal_hint'  => 'Context only — it is not looked up and no weather is fetched for it.',
            'postal_max'   => 10,
            'weather_authority' => 'your national weather service',
            'decider'      => 'your school or local education authority',
            'refs'         => ['met_office', 'dfe_emergency'],
            'note'         => 'Outside North America the people who decide differ: in England, for example, school leaders decide on closure after their own risk assessment, and the Met Office issues the warnings.',
            'forecast_tip' => 'Take the figures from your national weather service’s forecast for your town.',
        ],
    ],

    /* US state / Canadian province names for the context selector. */
    'region_codes' => [
        'US' => [
            'AL' => 'Alabama', 'AK' => 'Alaska', 'AZ' => 'Arizona', 'AR' => 'Arkansas', 'CA' => 'California',
            'CO' => 'Colorado', 'CT' => 'Connecticut', 'DE' => 'Delaware', 'DC' => 'District of Columbia',
            'FL' => 'Florida', 'GA' => 'Georgia', 'HI' => 'Hawaii', 'ID' => 'Idaho', 'IL' => 'Illinois',
            'IN' => 'Indiana', 'IA' => 'Iowa', 'KS' => 'Kansas', 'KY' => 'Kentucky', 'LA' => 'Louisiana',
            'ME' => 'Maine', 'MD' => 'Maryland', 'MA' => 'Massachusetts', 'MI' => 'Michigan', 'MN' => 'Minnesota',
            'MS' => 'Mississippi', 'MO' => 'Missouri', 'MT' => 'Montana', 'NE' => 'Nebraska', 'NV' => 'Nevada',
            'NH' => 'New Hampshire', 'NJ' => 'New Jersey', 'NM' => 'New Mexico', 'NY' => 'New York',
            'NC' => 'North Carolina', 'ND' => 'North Dakota', 'OH' => 'Ohio', 'OK' => 'Oklahoma', 'OR' => 'Oregon',
            'PA' => 'Pennsylvania', 'RI' => 'Rhode Island', 'SC' => 'South Carolina', 'SD' => 'South Dakota',
            'TN' => 'Tennessee', 'TX' => 'Texas', 'UT' => 'Utah', 'VT' => 'Vermont', 'VA' => 'Virginia',
            'WA' => 'Washington', 'WV' => 'West Virginia', 'WI' => 'Wisconsin', 'WY' => 'Wyoming',
        ],
        'CA' => [
            'AB' => 'Alberta', 'BC' => 'British Columbia', 'MB' => 'Manitoba', 'NB' => 'New Brunswick',
            'NL' => 'Newfoundland and Labrador', 'NS' => 'Nova Scotia', 'NT' => 'Northwest Territories',
            'NU' => 'Nunavut', 'ON' => 'Ontario', 'PE' => 'Prince Edward Island', 'QC' => 'Quebec',
            'SK' => 'Saskatchewan', 'YT' => 'Yukon',
        ],
    ],

    /* =================================================================
     * CANADIAN AREAS — who announces what. Each entry is a sourced fact
     * about a board or consortium, NEVER a closure status. Checked
     * 2026-09-24. Add an area here and it appears in the selector and in
     * the Canada page's "by area" section automatically.
     *   rule   'separate' = buses can be cancelled while schools stay open
     *          'closes'   = a weather bus cancellation closes schools too
     *          'delay'    = the usual middle outcome is a delayed start
     * ============================================================== */
    'ca_areas' => [
        'gta' => [
            'label'  => 'Toronto and the GTA (Toronto, Peel, York, Durham)',
            'prov'   => 'ON',
            'boards' => 'TDSB, TCDSB, Peel DSB, Dufferin-Peel CDSB, York Region DSB, York Catholic DSB, Durham DSB and Durham CDSB',
            'buses'  => 'each region’s student transportation service',
            'rule'   => 'separate',
            'time'   => 'about 6 to 6:15 a.m.',
            'note'   => 'Boards post decisions by about 6 to 6:15 a.m. TDSB says about 93% of its students do not ride a bus, so it often cancels buses while schools stay open; the boards describe full closures as rare and reserved for extreme conditions.',
            'links'  => [
                ['How GTA boards decide (CP24)', 'https://www.cp24.com/local/toronto/2025/11/28/how-and-when-do-school-boards-in-the-greater-toronto-area-close-due-to-winter-weather/'],
                ['Durham Student Transportation — inclement weather', 'https://www.dsts.on.ca/inclement-weather'],
            ],
        ],
        'halton' => [
            'label'  => 'Milton, Oakville, Burlington, Halton Hills (Halton)',
            'prov'   => 'ON',
            'boards' => 'Halton DSB and Halton Catholic DSB',
            'buses'  => 'Halton Student Transportation Services',
            'rule'   => 'separate',
            'time'   => '6:30 a.m.',
            'note'   => 'Halton is split into three weather zones (1: Burlington and Oakville, 2: Milton, 3: Georgetown and Acton). By 6:30 a.m. HDSB says whether transportation is cancelled and whether schools are closed; when buses are cancelled but schools stay open, in-person and e-learning courses continue.',
            'links'  => [
                ['HDSB bus cancellations and school closures', 'https://www.hdsb.ca/students-families/bus-cancellations-school-closures/'],
                ['Halton Student Transportation Services', 'https://www.haltonbus.ca/'],
            ],
        ],
        'simcoe' => [
            'label'  => 'Barrie, Orillia, Innisfil (Simcoe County)',
            'prov'   => 'ON',
            'boards' => 'Simcoe County DSB and Simcoe Muskoka Catholic DSB',
            'buses'  => 'Simcoe County Student Transportation Consortium',
            'rule'   => 'separate',
            'time'   => 'early morning',
            'note'   => 'Buses are cancelled by zone (north, central, south), so Orillia buses can be off while Barrie buses run. When buses are cancelled, schools usually stay open. Lake-effect squalls off Georgian Bay make zone-by-zone days common.',
            'links'  => [
                ['Bus cancellations (consortium)', 'https://www.simcoecountyschoolbus.ca/'],
                ['SCDSB', 'https://www.scdsb.on.ca/'],
            ],
        ],
        'hamilton' => [
            'label'  => 'Hamilton',
            'prov'   => 'ON',
            'boards' => 'Hamilton-Wentworth DSB and Hamilton-Wentworth Catholic DSB',
            'buses'  => 'Hamilton Wentworth Student Transportation Services',
            'rule'   => 'closes',
            'middle' => 'Buses cancelled (schools close too)',
            'time'   => '6 a.m.',
            'note'   => 'HWDSB’s published rule: when it cancels buses for severe weather, its schools and administrative buildings close too. It aims to announce by 6 a.m.',
            'links'  => [
                ['HWDSB inclement weather', 'https://www.hwdsb.on.ca/severe-weather'],
                ['HWSTS weather page', 'https://www.hamiltonschoolbus.ca/weather.aspx'],
            ],
        ],
        'waterloo' => [
            'label'  => 'Waterloo Region (Waterloo, Kitchener, Cambridge)',
            'prov'   => 'ON',
            'boards' => 'Waterloo Region DSB and Waterloo Catholic DSB',
            'buses'  => 'Student Transportation Services of Waterloo Region',
            'rule'   => 'separate',
            'time'   => 'usually before 7 a.m.',
            'note'   => 'Bus cancellations are posted by the transportation service, usually before 7 a.m.; the boards publish school closures separately.',
            'links'  => [
                ['STSWR — inclement weather communication', 'https://www.stswr.ca/ppf/communication-for-inclement-weather-cancellations'],
                ['WRDSB severe weather', 'https://www.wrdsb.ca/our-schools/student-transportation/severe-weather/'],
            ],
        ],
        'brantford' => [
            'label'  => 'Brantford, Paris, Brant, Haldimand, Norfolk',
            'prov'   => 'ON',
            'boards' => 'Grand Erie DSB and Brant Haldimand Norfolk Catholic DSB',
            'buses'  => 'Student Transportation Services of Brant Haldimand Norfolk',
            'rule'   => 'separate',
            'time'   => 'early morning',
            'note'   => 'Buses can be cancelled while schools stay open; in extreme weather the boards have also closed schools and all transportation together.',
            'links'  => [
                ['STSBHN', 'http://www.stsbhn.ca/'],
                ['BHNCDSB inclement weather', 'https://www1.bhncdsb.ca/inclement-weather/'],
            ],
        ],
        'ottawa' => [
            'label'  => 'Ottawa',
            'prov'   => 'ON',
            'boards' => 'Ottawa-Carleton DSB and Ottawa Catholic School Board',
            'buses'  => 'Ottawa Student Transportation Authority (OSTA)',
            'rule'   => 'separate',
            'time'   => 'about 6:15 a.m.',
            'note'   => 'When OSTA cancels transportation for weather it does so for all schools, and the OCDSB’s own notices say schools remain open. Cancellations are posted by about 6:15 a.m.',
            'links'  => [
                ['OSTA inclement weather', 'http://www.ottawaschoolbus.ca/policies-procedures/inclement-weather/'],
                ['OCDSB notice example: transportation cancelled, schools open', 'https://www.ocdsb.ca/news-events/news/post/march-11-2026-student-transportation-cancelled-ocdsb-schools-remain-open'],
            ],
        ],
        'peterborough' => [
            'label'  => 'Peterborough, Northumberland, Clarington (STSCO)',
            'prov'   => 'ON',
            'boards' => 'Kawartha Pine Ridge DSB and Peterborough Victoria Northumberland and Clarington Catholic DSB',
            'buses'  => 'Student Transportation Services of Central Ontario (STSCO)',
            'rule'   => 'separate',
            'time'   => 'early morning',
            'note'   => 'STSCO can cancel buses for one area (for example Northumberland County) while buses run elsewhere, and its notices say schools remain open. A morning cancellation also cancels the afternoon run.',
            'links'  => [
                ['STSCO delays and cancellations', 'https://www.stsco.ca/delays-cancellations.asp'],
                ['Example notice (PTBO Today)', 'https://www.ptbotoday.ca/2026/01/05/special-weather-statement-prompts-school-bus-cancellations-for-peterborough-city-and-county/'],
            ],
        ],
        'sudbury' => [
            'label'  => 'Greater Sudbury',
            'prov'   => 'ON',
            'boards' => 'Rainbow DSB, Sudbury Catholic DSB and the two French-language boards',
            'buses'  => 'Sudbury Student Services Consortium',
            'rule'   => 'separate',
            'time'   => 'early morning',
            'note'   => 'The consortium says schools in the affected areas stay open when buses are cancelled, and that extreme cold (around −35 °C and colder) can delay or cancel buses because diesel vehicles may break down.',
            'links'  => [
                ['Sudbury Student Services Consortium — weather', 'https://www.businfo.ca/weather/'],
            ],
        ],
        'northbay' => [
            'label'  => 'North Bay and Parry Sound',
            'prov'   => 'ON',
            'boards' => 'Near North DSB and Nipissing-Parry Sound Catholic DSB',
            'buses'  => 'Nipissing-Parry Sound Student Transportation Services',
            'rule'   => 'separate',
            'time'   => 'early morning',
            'note'   => 'Buses are cancelled by weather zone. The Near North DSB says schools remain open when buses are cancelled, and a route cancelled in the morning does not run in the afternoon.',
            'links'  => [
                ['NPSSTS', 'https://npssts.ca/index.php'],
                ['Near North DSB — transportation', 'https://www.nearnorthschools.ca/parents/transportation/'],
            ],
        ],
        'halifax' => [
            'label'  => 'Halifax (Nova Scotia)',
            'prov'   => 'NS',
            'boards' => 'Halifax Regional Centre for Education (HRCE)',
            'buses'  => 'HRCE transportation providers',
            'rule'   => 'separate',
            'time'   => 'as close to 6 a.m. as possible',
            'note'   => 'HRCE aims to decide as close to 6 a.m. as possible. An announcement can be: schools open but some or all buses not running, some schools closed, or all schools closed.',
            'links'  => [
                ['HRCE cancellations', 'https://www.hrce.ca/families/cancellations'],
            ],
        ],
        'pei' => [
            'label'  => 'Prince Edward Island',
            'prov'   => 'PE',
            'boards' => 'Public Schools Branch',
            'buses'  => 'Public Schools Branch',
            'rule'   => 'delay',
            'middle' => 'One-hour delay or partial closure',
            'time'   => '6:30 a.m.',
            'note'   => 'The Public Schools Branch aims to announce by 6:30 a.m.; if it cannot decide by then it announces a one-hour delay and follows up by 8:00 a.m. Partial closures and delays are announced by Family of Schools.',
            'links'  => [
                ['PSB storm closures', 'https://psb.edu.pe.ca/parent-and-student-resources/storm-closures'],
            ],
        ],
        'other-on' => [
            'label'  => 'Elsewhere in Ontario',
            'prov'   => 'ON',
            'boards' => 'Your school board',
            'buses'  => 'your area’s student transportation consortium',
            'rule'   => 'separate',
            'time'   => 'early morning',
            'note'   => 'In most of Ontario, busing is run by a consortium shared by the public and Catholic boards, and bus cancellations are announced separately from school closures.',
            'links'  => [],
            'generic' => true,
        ],
        'other-ca' => [
            'label'  => 'Elsewhere in Canada',
            'prov'   => '',
            'boards' => 'Your school board, division or regional centre',
            'buses'  => 'your board’s transportation service',
            'rule'   => 'separate',
            'time'   => 'early morning',
            'note'   => 'Closure rules are set locally. Check whether your board cancels buses without closing schools, and set the option below to match.',
            'links'  => [],
            'generic' => true,
        ],
    ],

    /* Canada: the bus-rule choices (the Canada page's middle outcome). */
    'bus_rules' => [
        'separate' => ['label' => 'Schools usually stay open', 'middle' => 'Buses cancelled, schools open'],
        'closes'   => ['label' => 'Schools close too',         'middle' => 'Buses cancelled (schools close too)'],
        'delay'    => ['label' => 'A delayed start is usual',  'middle' => 'Delayed start or partial closure'],
    ],

    /* =================================================================
     * US STATE NOTES — sourced facts, shown in the result when the state
     * chosen in "Location context" matches (and, for `cities`, when the
     * city typed matches one of them).
     * ============================================================== */
    'us_state_notes' => [
        'michigan' => [
            'title'  => 'Michigan',
            'state'  => 'MI',
            'cities' => [],
            'text'   => 'Michigan law lets a district count up to six days of cancelled instruction for conditions outside its control (such as severe storms) as “forgiven”, and up to three more through a waiver; days beyond that have to be made up. Lake-effect snow falls in narrow bands, so neighbouring districts can decide differently.',
            'refs'   => ['mde_michigan'],
        ],
        'nyc' => [
            'title'  => 'New York City',
            'state'  => 'NY',
            'cities' => ['new york', 'new york city', 'nyc', 'manhattan', 'brooklyn', 'bronx', 'the bronx', 'queens', 'staten island'],
            'text'   => 'Since 2020, New York City public schools have usually moved classes online when buildings close for a storm instead of taking a traditional snow day, although a traditional snow day has been allowed by state waiver (for example in February 2026). The approach can change from year to year, so check each announcement.',
            'refs'   => ['nyc_remote', 'nyc_waiver'],
        ],
        'pennsylvania' => [
            'title'  => 'Pennsylvania',
            'state'  => 'PA',
            'cities' => [],
            'text'   => 'Districts with an approved Flexible Instructional Day program can turn up to five weather days a year into instruction at home, so a “closure” may be an FID rather than a day off. The state still recommends keeping make-up days in the calendar.',
            'refs'   => ['pde_fid'],
        ],
        'minnesota' => [
            'title'  => 'Minnesota',
            'state'  => 'MN',
            'cities' => [],
            'text'   => 'A district or charter school with an adopted plan may hold up to five e-learning days a year for inclement weather; they count as instruction days.',
            'refs'   => ['mn_elearning'],
        ],
    ],

    /* =================================================================
     * SCHOOL SETTINGS — each shift moves the centre of the closure curve
     * (points of weather pressure). Positive = needs MORE weather to close.
     * These are the reader's judgement about their school, not policy.
     * ============================================================== */
    'school_types' => [
        'public'   => ['label' => 'Public school (the district decides)', 'shift' => 0],
        'private'  => ['label' => 'Private or independent day school', 'shift' => 4],
        'boarding' => ['label' => 'Boarding school (students live on campus)', 'shift' => 20],
    ],

    'area_types' => [
        'city'     => ['label' => 'City', 'hint' => 'most students walk or take transit', 'shift' => 4],
        'suburban' => ['label' => 'Suburban', 'hint' => 'typical bus routes', 'shift' => 0],
        'rural'    => ['label' => 'Rural', 'hint' => 'long bus routes and back roads', 'shift' => -5],
    ],

    /* School sensitivity: "how easily does your school close?" */
    'tendency' => [
        'low'     => ['label' => 'Rarely closes', 'shift' => 10],
        'typical' => ['label' => 'Typical', 'shift' => 0],
        'high'    => ['label' => 'Closes easily', 'shift' => -10],
    ],

    /* Commute sensitivity: how much bad roads matter to your school. */
    'commute_sensitivity' => [
        'low'     => ['label' => 'Short, well-cleared routes', 'shift' => 4],
        'typical' => ['label' => 'Typical', 'shift' => 0],
        'high'    => ['label' => 'Hills, back roads or long routes', 'shift' => -4],
    ],

    'college' => [
        /* Colleges need more weather pressure than K-12 schools. */
        'level_shift' => 12,
        'delay_gap'   => 10,
        'campus_types' => [
            'residential' => ['label' => 'Mostly residential', 'hint' => 'most students live on or next to campus', 'shift' => 6],
            'mixed'       => ['label' => 'Mixed', 'hint' => 'some live on campus, many commute', 'shift' => 0],
            'commuter'    => ['label' => 'Mostly commuters', 'hint' => 'most students and staff drive or take transit in', 'shift' => -4],
        ],
        'online' => [
            'often'     => ['label' => 'Often moves classes online', 'shift' => 4, 'middle' => 'Classes online or delayed'],
            'sometimes' => ['label' => 'Sometimes / not sure', 'shift' => 0, 'middle' => 'Delayed opening or online'],
            'never'     => ['label' => 'Rarely or never', 'shift' => 0, 'middle' => 'Delayed opening'],
        ],
        /* Class time re-weights the storm timing: for each storm time,
           `share` = share of the snow that counts and `points` = timing
           points. Omitted storm times fall back to `timing` below. */
        'class_times' => [
            'morning'      => ['label' => 'Morning (from about 8 a.m.)', 'timing' => []],
            'late_morning' => ['label' => 'Late morning (about 10 a.m.–noon)', 'timing' => [
                'evening'   => ['share' => 0.6, 'points' => 0, 'rate' => 0],
                'overnight' => ['share' => 0.9, 'points' => 2, 'rate' => 0],
                'early'     => ['share' => 1,   'points' => 5, 'rate' => 0.5],
                'commute'   => ['share' => 1,   'points' => 10, 'rate' => 1],
                'school'    => ['share' => 0.7, 'points' => 6, 'rate' => 0.7],
            ]],
            'afternoon'    => ['label' => 'Afternoon (about noon–5 p.m.)', 'timing' => [
                'evening'   => ['share' => 0.5, 'points' => 0, 'rate' => 0],
                'overnight' => ['share' => 0.7, 'points' => 0, 'rate' => 0],
                'early'     => ['share' => 0.9, 'points' => 3, 'rate' => 0],
                'commute'   => ['share' => 1,   'points' => 6, 'rate' => 0.5],
                'school'    => ['share' => 1,   'points' => 10, 'rate' => 1],
            ]],
            'evening'      => ['label' => 'Evening (about 5–9 p.m.)', 'timing' => [
                'evening'   => ['share' => 0.3, 'points' => 0, 'rate' => 0],
                'overnight' => ['share' => 0.5, 'points' => 0, 'rate' => 0],
                'early'     => ['share' => 0.6, 'points' => 0, 'rate' => 0],
                'commute'   => ['share' => 0.8, 'points' => 4, 'rate' => 0.3],
                'school'    => ['share' => 1,   'points' => 10, 'rate' => 1],
            ]],
        ],
    ],

    /* =================================================================
     * FIELDS — every manual input. Limits are in METRIC (the page
     * converts what the reader types before checking). `unit` picks the
     * unit label: snow, rate, rain, ice, temp, wind, hours, minutes.
     * `optional` fields may stay blank; blank never becomes zero silently
     * in a way that changes a derived value (wind chill, rate).
     * ============================================================== */
    'fields' => [
        'snow_cm'    => ['label' => 'Snowfall amount', 'unit' => 'snow', 'min' => 0, 'max' => 200, 'step' => ['us' => 0.5, 'metric' => 1], 'group' => 'precip', 'hint' => 'Total expected, from your local forecast.'],
        'snow_hours' => ['label' => 'Snowfall duration', 'unit' => 'hours', 'min' => 0, 'max' => 48, 'step' => ['us' => 1, 'metric' => 1], 'group' => 'precip', 'optional' => true, 'hint' => 'How many hours it snows. Used for the rate when you leave the rate blank.'],
        'snow_rate'  => ['label' => 'Snowfall rate', 'unit' => 'rate', 'min' => 0, 'max' => 15, 'step' => ['us' => 0.1, 'metric' => 0.5], 'group' => 'precip', 'optional' => true, 'hint' => 'Optional. Blank = amount ÷ duration.'],
        'rain_mm'    => ['label' => 'Rain amount', 'unit' => 'rain', 'min' => 0, 'max' => 200, 'step' => ['us' => 0.05, 'metric' => 1], 'group' => 'precip', 'hint' => 'Liquid rain. It counts as ice only for a freezing condition, or if it refreezes.'],
        'rain_int'   => ['label' => 'Rain intensity', 'type' => 'select', 'options' => 'rain_intensity', 'group' => 'precip'],
        'ice_mm'     => ['label' => 'Freezing rain / ice accretion', 'unit' => 'ice', 'min' => 0, 'max' => 50, 'step' => ['us' => 0.05, 'metric' => 0.5], 'group' => 'precip', 'hint' => 'Ice build-up, kept separate from snow. 0.25 in ≈ 6 mm.'],
        'refreeze_c' => ['label' => 'Overnight low (refreeze temperature)', 'unit' => 'temp', 'min' => -60, 'max' => 25, 'step' => ['us' => 1, 'metric' => 1], 'group' => 'temp', 'optional' => true, 'hint' => 'Optional. Blank = the commute temperature is used.'],
        'temp_c'     => ['label' => 'Temperature at commute time', 'unit' => 'temp', 'min' => -60, 'max' => 25, 'step' => ['us' => 1, 'metric' => 1], 'group' => 'temp', 'hint' => 'The morning low while buses run.'],
        'wind_kmh'   => ['label' => 'Wind speed', 'unit' => 'wind', 'min' => 0, 'max' => 200, 'step' => ['us' => 1, 'metric' => 1], 'group' => 'wind', 'hint' => 'Sustained wind, as a forecast gives it.'],
        'gust_kmh'   => ['label' => 'Wind gusts', 'unit' => 'wind', 'min' => 0, 'max' => 250, 'step' => ['us' => 1, 'metric' => 1], 'group' => 'wind', 'optional' => true, 'hint' => 'Optional. Strongest gust expected.'],
        'wc_c'       => ['label' => 'Wind chill', 'unit' => 'temp', 'min' => -80, 'max' => 25, 'step' => ['us' => 1, 'metric' => 1], 'group' => 'temp', 'optional' => true, 'hint' => 'Optional. Blank = worked out from temperature and wind.'],
        'vis'        => ['label' => 'Visibility', 'type' => 'select', 'options' => 'visibility', 'group' => 'wind'],
        'timing'     => ['label' => 'Storm timing', 'type' => 'select', 'options' => 'timing', 'group' => 'timing'],
        'commute'    => ['label' => 'Morning commute conditions', 'type' => 'select', 'options' => 'commute', 'group' => 'timing'],
        'wait_min'   => ['label' => 'Time at the bus stop or walking', 'unit' => 'minutes', 'min' => 0, 'max' => 90, 'step' => ['us' => 5, 'metric' => 5], 'group' => 'temp', 'hint' => 'Longest time a student is outside in the morning.'],
    ],

    /* =================================================================
     * WEATHER CONDITIONS — the selector. Choosing one:
     *   - sets the scene (`sky`, `layers`) and the icon;
     *   - fills `set` values (metric) — typical figures you then edit;
     *   - moves the temperature into `temp` [min, max] if it is outside
     *     (rain cannot fall at −20 °C), and raises wind to `wind_min`;
     *   - `rain_ice` = share of the rain amount counted as ice (freezing
     *     conditions only — plain rain is never turned into ice);
     *   - `key` fields are highlighted, the others stay editable.
     * `layers`: particle layer → share of its full count (0–1). `floor`
     * keeps the chosen weather visible when an amount is still 0.
     * ============================================================== */
    'conditions' => [
        'clear' => [
            'label' => 'Clear', 'icon' => 'wx-clear', 'sky' => 'clear',
            'layers' => ['crystal' => 0.15], 'floor' => 1,
            'set' => ['snow_cm' => 0, 'snow_hours' => 0, 'rain_mm' => 0, 'ice_mm' => 0],
            'rain_ice' => 0, 'key' => ['temp_c', 'wind_kmh', 'commute'],
        ],
        'snow' => [
            'label' => 'Snow', 'icon' => 'wx-snow', 'sky' => 'snow',
            'layers' => ['snow' => 1], 'floor' => 0.2,
            'set' => ['snow_cm' => 8, 'snow_hours' => 8, 'rain_mm' => 0, 'ice_mm' => 0],
            'temp' => [-30, 1], 'temp_default' => -4,
            'rain_ice' => 0, 'key' => ['snow_cm', 'snow_hours', 'snow_rate', 'timing'],
        ],
        'heavy_snow' => [
            'label' => 'Heavy snow', 'icon' => 'wx-heavy-snow', 'sky' => 'heavy',
            'layers' => ['snow' => 1], 'floor' => 0.7,
            'set' => ['snow_cm' => 25, 'snow_hours' => 12, 'rain_mm' => 0, 'ice_mm' => 0],
            'temp' => [-30, 1], 'temp_default' => -6,
            'rain_ice' => 0, 'key' => ['snow_cm', 'snow_hours', 'snow_rate', 'timing', 'vis'],
        ],
        'rain' => [
            'label' => 'Rain', 'icon' => 'wx-rain', 'sky' => 'rain',
            'layers' => ['rain' => 1], 'floor' => 0.2,
            'set' => ['snow_cm' => 0, 'snow_hours' => 0, 'rain_mm' => 8, 'ice_mm' => 0],
            'temp' => [1, 25], 'temp_default' => 4,
            'rain_ice' => 0, 'key' => ['rain_mm', 'rain_int', 'temp_c'],
        ],
        'freezing_rain' => [
            'label' => 'Freezing rain', 'icon' => 'wx-ice', 'sky' => 'ice',
            'layers' => ['rain' => 0.55, 'crystal' => 0.7], 'floor' => 0.25, 'frost' => 0.6,
            'set' => ['snow_cm' => 0, 'snow_hours' => 0, 'rain_mm' => 0, 'ice_mm' => 4],
            'temp' => [-8, 0], 'temp_default' => -1,
            'rain_ice' => 1, 'key' => ['ice_mm', 'temp_c', 'timing', 'commute'],
        ],
        'ice' => [
            'label' => 'Ice', 'icon' => 'wx-ice', 'sky' => 'ice',
            'layers' => ['crystal' => 1], 'floor' => 0.3, 'frost' => 0.85,
            'set' => ['snow_cm' => 0, 'snow_hours' => 0, 'rain_mm' => 0, 'ice_mm' => 3],
            'temp' => [-20, 0], 'temp_default' => -3,
            'rain_ice' => 1, 'key' => ['ice_mm', 'refreeze_c', 'temp_c', 'commute'],
        ],
        'sleet_mixed' => [
            'label' => 'Sleet / mixed', 'icon' => 'wx-mixed', 'sky' => 'mixed',
            'layers' => ['snow' => 0.6, 'rain' => 0.6, 'crystal' => 0.25], 'floor' => 0.3, 'frost' => 0.25,
            'set' => ['snow_cm' => 4, 'snow_hours' => 6, 'rain_mm' => 5, 'ice_mm' => 0],
            'temp' => [-3, 2], 'temp_default' => 0,
            'rain_ice' => 0.5, 'key' => ['snow_cm', 'rain_mm', 'temp_c', 'commute'],
        ],
        'extreme_cold' => [
            'label' => 'Extreme cold', 'icon' => 'wx-cold', 'sky' => 'cold',
            'layers' => ['mist' => 1, 'crystal' => 0.5], 'floor' => 0.5, 'frost' => 0.8,
            'set' => ['snow_cm' => 0, 'snow_hours' => 0, 'rain_mm' => 0, 'ice_mm' => 0],
            'temp' => [-60, -20], 'temp_default' => -28,
            'rain_ice' => 0, 'key' => ['temp_c', 'wind_kmh', 'wc_c', 'wait_min'],
        ],
        'snow_wind' => [
            'label' => 'Snow + wind', 'icon' => 'wx-wind-snow', 'sky' => 'snow',
            'layers' => ['snow' => 1, 'streak' => 0.6], 'floor' => 0.35,
            'set' => ['snow_cm' => 12, 'snow_hours' => 10, 'rain_mm' => 0, 'ice_mm' => 0],
            'temp' => [-30, 0], 'temp_default' => -7, 'wind_min' => 45, 'gust_min' => 70,
            'rain_ice' => 0, 'key' => ['snow_cm', 'wind_kmh', 'gust_kmh', 'vis'],
        ],
        'snow_ice' => [
            'label' => 'Snow + ice', 'icon' => 'wx-mixed', 'sky' => 'ice',
            'layers' => ['snow' => 0.8, 'crystal' => 0.7], 'floor' => 0.3, 'frost' => 0.6,
            'set' => ['snow_cm' => 5, 'snow_hours' => 6, 'rain_mm' => 0, 'ice_mm' => 2],
            'temp' => [-15, 0], 'temp_default' => -2,
            'rain_ice' => 1, 'key' => ['snow_cm', 'ice_mm', 'temp_c', 'commute'],
        ],
        'rain_freezing' => [
            'label' => 'Rain + freezing temperature', 'icon' => 'wx-rain', 'sky' => 'ice',
            'layers' => ['rain' => 1, 'crystal' => 0.3], 'floor' => 0.25, 'frost' => 0.5,
            'set' => ['snow_cm' => 0, 'snow_hours' => 0, 'rain_mm' => 6, 'ice_mm' => 0],
            'temp' => [-6, 0], 'temp_default' => -1,
            'rain_ice' => 1, 'key' => ['rain_mm', 'temp_c', 'refreeze_c', 'commute'],
        ],
    ],

    /* Which condition do the typed values look like? Checked top to
       bottom; used only to SUGGEST a switch — never to change the result
       or the values. [field, op, value] must all hold (metric). */
    'detect' => [
        ['condition' => 'snow_ice',      'when' => [['snow_cm', '>=', 1], ['ice_mm', '>=', 0.5]]],
        ['condition' => 'sleet_mixed',   'when' => [['snow_cm', '>=', 1], ['rain_mm', '>=', 1]]],
        ['condition' => 'snow_wind',     'when' => [['snow_cm', '>=', 2], ['wind_kmh', '>=', 40]]],
        ['condition' => 'heavy_snow',    'when' => [['snow_cm', '>=', 15]]],
        ['condition' => 'snow',          'when' => [['snow_cm', '>=', 0.5]]],
        ['condition' => 'freezing_rain', 'when' => [['ice_mm', '>=', 0.5], ['rain_mm', '<', 1]]],
        ['condition' => 'rain_freezing', 'when' => [['rain_mm', '>=', 1], ['temp_c', '<=', 0]]],
        ['condition' => 'rain',          'when' => [['rain_mm', '>=', 1]]],
        ['condition' => 'ice',           'when' => [['ice_mm', '>=', 0.2]]],
        ['condition' => 'extreme_cold',  'when' => [['wc_eff', '<=', -28]]],
        ['condition' => 'clear',         'when' => []],
    ],

    /* =================================================================
     * STORM TIMING — the timeline. share = share of the snow counted;
     * rate = share of the snowfall-rate points counted; points = timing
     * points (only while snow or ice is in play).
     * ============================================================== */
    'timing' => [
        'evening'   => ['label' => 'Evening before (ends by midnight)', 'short' => 'Evening',        'share' => 0.8, 'rate' => 0,   'points' => 0],
        'overnight' => ['label' => 'Overnight (ends before 6 a.m.)',    'short' => 'Overnight',      'share' => 1,   'rate' => 0,   'points' => 3],
        'early'     => ['label' => 'Early morning (4–6 a.m.)',          'short' => 'Early morning',  'share' => 1,   'rate' => 0.5, 'points' => 6],
        'commute'   => ['label' => 'During the morning commute',        'short' => 'School commute', 'share' => 1,   'rate' => 1,   'points' => 10],
        'school'    => ['label' => 'During school hours',               'short' => 'School hours',   'share' => 0.5, 'rate' => 0.5, 'points' => 4],
    ],

    /* Morning commute conditions — the reader's description of roads. */
    'commute' => [
        'clear'    => ['label' => 'Clear, dry roads', 'points' => 0],
        'wet'      => ['label' => 'Wet roads', 'points' => 0],
        'slushy'   => ['label' => 'Slush', 'points' => 5],
        'snowy'    => ['label' => 'Snow-covered roads', 'points' => 12],
        'icy'      => ['label' => 'Icy or glazed roads', 'points' => 18],
        'whiteout' => ['label' => 'Blowing snow, near whiteout', 'points' => 20],
    ],

    'visibility' => [
        'good'     => ['label' => 'Good', 'points' => 0, 'haze' => 0],
        'reduced'  => ['label' => 'Reduced (under 1 km / 0.6 mi)', 'points' => 3, 'haze' => 0.12],
        'poor'     => ['label' => 'Poor (under 400 m / ¼ mi)', 'points' => 6, 'haze' => 0.22],
        'verypoor' => ['label' => 'Very poor, whiteout (under 100 m)', 'points' => 10, 'haze' => 0.32],
    ],

    'rain_intensity' => [
        'light'    => ['label' => 'Light', 'visual' => 0.35],
        'moderate' => ['label' => 'Moderate', 'visual' => 0.65],
        'heavy'    => ['label' => 'Heavy', 'visual' => 1],
    ],

    /* =================================================================
     * MODEL — heuristic, documented, reproducible. No random part.
     *
     * Tables are [x, points] pairs, interpolated linearly and flat beyond
     * the ends. Four groups combine like independent risks:
     *   pressure = 100 × (1 − (1−snow/100)(1−ice/100)(1−cold/100)(1−extras/100))
     * where extras = min(extras_cap, rate + wind + gusts + visibility +
     * timing + commute (+ exposure on the cold page)).
     * Pressure goes through a logistic curve centred on `center` (+ the
     * reader's shifts) with scale `spread`; the chance of ANY disruption
     * uses a centre `delay_gap` lower.
     * ============================================================== */
    'model' => [
        'version' => '3.1',

        /* x = effective snow, cm = amount × timing share × warm-ground share. */
        'snow' => [[0, 0], [1, 3], [2.5, 8], [5, 20], [10, 40], [15, 55], [20, 65], [30, 75]],

        /* Warm-ground adjustment: x = commute temperature (°C); y = share
           of the snow counted. At or below 0 °C it counts in full. */
        'melt' => [[0, 1], [1, 0.9], [2, 0.75], [3, 0.6], [5, 0.5]],

        /* x = freezing precipitation, mm (ice + rain counted as ice +
           refreeze allowance). */
        'ice' => [[0, 0], [0.2, 8], [0.5, 15], [2, 30], [6, 50], [12, 65]],

        /* Rain, then a hard freeze: rain not already counted as ice, of at
           least rain_min_mm, with the refreeze temperature (overnight low,
           else the commute temperature) at or below temp_max_c, counts
           `share` of that rain as ice, at most cap_mm. */
        'refreeze' => ['rain_min_mm' => 1, 'temp_max_c' => -1, 'share' => 0.25, 'cap_mm' => 2],

        /* x = −(wind chill, °C). −20 °C adds nothing. */
        'cold' => [[20, 0], [28, 10], [35, 30], [40, 45], [45, 60], [55, 75]],

        /* Extras. rate, wind, gusts, visibility and timing count only
           while snow ≥ wintry_snow_cm or any ice is in play; the commute
           conditions always count (they are what you see on the roads). */
        'rate' => [[0, 0], [1, 5], [2, 10], [3, 12]],   // cm/h
        'wind' => [[20, 0], [40, 4], [60, 8]],           // sustained km/h
        'gust' => [[30, 0], [50, 6], [70, 10]],          // gust km/h
        'extras_cap'     => 30,
        'wintry_snow_cm' => 1,

        /* Cold page: minutes outside, once the wind chill is at or below
           exposure_from_c. */
        'exposure'        => [[5, 0], [15, 4], [30, 8], [60, 12]],
        'exposure_from_c' => -20,

        'center'      => 55,
        'spread'      => 7,
        'delay_gap'   => 14,
        'min'         => 1,
        'max_closure' => 95,
        'max_disrupt' => 97,

        /* Factor influence words, by points. */
        'influence' => ['low' => 0.5, 'moderate' => 10, 'high' => 30],

        /* Closure chance → band word (first "below" that fits). */
        'bands' => [
            ['below' => 10,  'label' => 'Unlikely'],
            ['below' => 30,  'label' => 'Low chance'],
            ['below' => 55,  'label' => 'Possible'],
            ['below' => 80,  'label' => 'Likely'],
            ['below' => 101, 'label' => 'Very likely'],
        ],

        /* "Why did my result change?" lists moves of at least this many points. */
        'change_threshold' => 1,
        /* The factor chart highlights moves of at least this many points. */
        'chart_change_threshold' => 0.5,

        /* Factors each page focus leaves out. */
        'focus_ignore' => [
            'all'  => ['exposure'],
            'ice'  => ['snow', 'rate', 'exposure'],
            'cold' => ['snow', 'ice', 'rate', 'wind', 'gust', 'vis', 'timing', 'commute'],
        ],

        /* Factor names and what each measures, in display order. */
        'factors' => [
            'snow'     => ['label' => 'Snowfall', 'group' => 'snow', 'what' => 'amount × storm-timing share × warm-ground share'],
            'ice'      => ['label' => 'Ice / freezing rain', 'group' => 'ice', 'what' => 'ice accretion, rain counted as ice for a freezing condition, and refreeze'],
            'cold'     => ['label' => 'Wind chill', 'group' => 'cold', 'what' => 'the morning wind chill'],
            'rate'     => ['label' => 'Snowfall rate', 'group' => 'extras', 'what' => 'how fast it snows, weighted by timing'],
            'wind'     => ['label' => 'Wind', 'group' => 'extras', 'what' => 'sustained wind (blowing snow), only with snow or ice'],
            'gust'     => ['label' => 'Wind gusts', 'group' => 'extras', 'what' => 'strongest gust, only with snow or ice'],
            'vis'      => ['label' => 'Visibility', 'group' => 'extras', 'what' => 'visibility, only with snow or ice'],
            'timing'   => ['label' => 'Storm timing', 'group' => 'extras', 'what' => 'when the storm falls relative to the commute'],
            'commute'  => ['label' => 'Morning commute', 'group' => 'extras', 'what' => 'the road conditions you expect'],
            'exposure' => ['label' => 'Time outside', 'group' => 'extras', 'what' => 'minutes at the bus stop in severe wind chill'],
        ],
    ],

    /* =================================================================
     * WEATHER VISUALS — the scene behind the calculator
     * (assets/js/lib/winter-scene.js reads only this).
     *
     * `layers` are the MAXIMUM particle counts at intensity 1; the
     * intensities below scale them down. Thresholds here drive the
     * animation only — they are not closure rules.
     * ============================================================== */
    'visuals' => [
        'engine' => [
            'max_dpr'       => 1.5,
            'mobile_width'  => 640,
            'fps'           => 30,     // desktop frame cap
            'fps_mobile'    => 30,
            'mobile_scale'  => 0.42,   // share of the desktop count on phones
            'max_particles' => 240,    // hard cap across all layers
            'lite_below_cores' => 4,   // hardwareConcurrency below this = "lite" (mobile counts)
            'mist_min_scale'   => 0.6,  // cold mist keeps at least this share on lite devices
        ],
        'layers' => [
            'snow'    => ['count' => 170, 'size' => [0.9, 3.6], 'speed' => [0.35, 1.3], 'drift' => 2.4, 'sway' => 0.6, 'alpha' => [0.35, 0.95], 'spin' => 0.02],
            'rain'    => ['count' => 150, 'length' => [8, 22], 'speed' => [7, 13], 'slant' => 0.18, 'alpha' => [0.16, 0.5], 'splash' => 10],
            'crystal' => ['count' => 44,  'size' => [2, 4.8], 'speed' => [0.04, 0.2], 'twinkle' => 0.025, 'alpha' => [0.25, 0.85]],
            'mist'    => ['count' => 7,   'size' => [100, 220], 'speed' => [0.05, 0.18], 'alpha' => [0.05, 0.14]],
            'streak'  => ['count' => 16,  'length' => [50, 140], 'speed' => [7, 14], 'alpha' => [0.08, 0.22]],
        ],
        /* Value → intensity 0..1 for each layer. */
        'intensity' => [
            'snow_cm'   => [[0, 0], [2, 0.35], [10, 0.7], [25, 1]],     // light · moderate · heavy
            'snow_rate' => [[0, 0], [1, 0.4], [3, 0.8], [5, 1]],        // cm/h (the larger of the two wins)
            'rain_mm'   => [[0, 0], [2, 0.3], [10, 0.65], [30, 1]],
            'ice_mm'    => [[0, 0], [0.5, 0.35], [2, 0.6], [6, 0.85], [12, 1]],
            'cold'      => [[5, 0], [15, 0.25], [28, 0.65], [40, 1]],  // x = −(wind chill °C)
            'wind'      => [[0, 0], [15, 0.12], [40, 0.55], [70, 0.9], [100, 1]],
            'gust'      => [[30, 0], [60, 0.15], [100, 0.3]],           // added on top of wind
        ],
        /* Cold mist / frost appear on ANY condition once cold ≥ this. */
        'cold_mist_from' => 0.2,
        /* Wind streaks appear on any precipitating scene once wind ≥ this. */
        'streak_from'    => 0.45,
        /* Heavy snow haze: haze = (snow − from) × scale, plus visibility haze. */
        'haze_from'      => 0.55,
        'haze_scale'     => 0.5,
        'haze_max'       => 0.42,
        /* Storm timing: how bright each stage of the timeline strip is
           drawn, relative to the chosen stage (visual only). */
        'timeline_falloff' => [1, 0.45, 0.15],
        'timeline_min'     => 0.15,   // dimmest the timeline strip is drawn
        /* How the visual layers borrow from each other (visual only). */
        'mix' => [
            'rain_intensity'    => 0.8,   // share of the chosen rain intensity drawn when any rain is entered
            'crystal_from_cold' => 0.6,   // ice crystals drawn from cold alone
            'clear_sparkle'     => 1,     // crystal layer on a clear scene (a few calm sparkles)
            'streak_from_wind'  => 0.8,   // wind streak strength on precipitating scenes
            'frost_from_cold'   => 0.9,   // frost border from cold
            'frost_from_ice'    => 0.8,   // frost border from ice
        ],
        /* Intensity → word for the screen-reader scene line. */
        'strength' => ['none_below' => 0.05, 'light_below' => 0.4, 'moderate_below' => 0.75],
    ],

    /* =================================================================
     * ENVIRONMENT CANADA WIND CHILL RISK (canada.ca), keyed on the
     * rounded wind chill in °C.
     * ============================================================== */
    'risk_bands' => [
        ['max' => 0,   'min' => -9,   'risk' => 'Low risk',       'short' => 'Low',       'note' => 'Slight increase in discomfort.'],
        ['max' => -10, 'min' => -27,  'risk' => 'Moderate risk',  'short' => 'Moderate',  'note' => 'Uncomfortable; risk of hypothermia and frostbite if outside for long periods without protection.'],
        ['max' => -28, 'min' => -39,  'risk' => 'High risk',      'short' => 'High',      'note' => 'Exposed skin can freeze in 10 to 30 minutes.'],
        ['max' => -40, 'min' => -47,  'risk' => 'Very high risk', 'short' => 'Very high', 'note' => 'Exposed skin can freeze in 5 to 10 minutes.'],
        ['max' => -48, 'min' => -54,  'risk' => 'Severe risk',    'short' => 'Severe',    'note' => 'Exposed skin can freeze in 2 to 5 minutes.'],
        ['max' => -55, 'min' => -999, 'risk' => 'Extreme risk',   'short' => 'Extreme',   'note' => 'Exposed skin can freeze in less than 2 minutes.'],
    ],

    /* =================================================================
     * PRESETS — example scenarios. Values are METRIC. `expect` is the
     * closure chance each page gives with its default settings; the test
     * suite recomputes every one, so a weight change that breaks an
     * example fails the tests.
     * ============================================================== */
    'presets' => [
        'light_snow' => [
            'label' => 'Light snow', 'condition' => 'snow',
            'values' => ['snow_cm' => 2, 'snow_hours' => 4, 'snow_rate' => null, 'rain_mm' => 0, 'rain_int' => 'light', 'ice_mm' => 0, 'refreeze_c' => null,
                         'temp_c' => -3, 'wind_kmh' => 10, 'gust_kmh' => null, 'wc_c' => null, 'vis' => 'good', 'timing' => 'overnight', 'commute' => 'wet', 'wait_min' => 10],
            'expect' => ['snow-day-calculator' => 1, 'snow-day-calculator-canada' => 1, 'college-snow-day-calculator' => 1],
        ],
        'moderate_snow' => [
            'label' => 'Moderate snow', 'condition' => 'snow',
            'values' => ['snow_cm' => 8, 'snow_hours' => 8, 'snow_rate' => null, 'rain_mm' => 0, 'rain_int' => 'light', 'ice_mm' => 0, 'refreeze_c' => null,
                         'temp_c' => -4, 'wind_kmh' => 15, 'gust_kmh' => null, 'wc_c' => null, 'vis' => 'reduced', 'timing' => 'overnight', 'commute' => 'snowy', 'wait_min' => 10],
            'expect' => ['snow-day-calculator' => 18, 'snow-day-calculator-canada' => 18, 'college-snow-day-calculator' => 4],
        ],
        'heavy_snow' => [
            'label' => 'Heavy snow', 'condition' => 'heavy_snow',
            'values' => ['snow_cm' => 25, 'snow_hours' => 12, 'snow_rate' => null, 'rain_mm' => 0, 'rain_int' => 'light', 'ice_mm' => 0, 'refreeze_c' => null,
                         'temp_c' => -6, 'wind_kmh' => 25, 'gust_kmh' => 45, 'wc_c' => null, 'vis' => 'poor', 'timing' => 'commute', 'commute' => 'snowy', 'wait_min' => 10],
            'expect' => ['snow-day-calculator' => 95, 'snow-day-calculator-canada' => 95, 'college-snow-day-calculator' => 85],
        ],
        'snow_ice' => [
            'label' => 'Snow + ice', 'condition' => 'snow_ice',
            'values' => ['snow_cm' => 5, 'snow_hours' => 6, 'snow_rate' => null, 'rain_mm' => 0, 'rain_int' => 'light', 'ice_mm' => 3, 'refreeze_c' => null,
                         'temp_c' => -2, 'wind_kmh' => 15, 'gust_kmh' => null, 'wc_c' => null, 'vis' => 'reduced', 'timing' => 'overnight', 'commute' => 'icy', 'wait_min' => 10],
            'expect' => ['snow-day-calculator' => 69, 'snow-day-calculator-canada' => 69, 'ice-day-calculator' => 35, 'college-snow-day-calculator' => 28],
        ],
        'snow_wind' => [
            'label' => 'Snow + wind', 'condition' => 'snow_wind',
            'values' => ['snow_cm' => 12, 'snow_hours' => 10, 'snow_rate' => null, 'rain_mm' => 0, 'rain_int' => 'light', 'ice_mm' => 0, 'refreeze_c' => null,
                         'temp_c' => -8, 'wind_kmh' => 50, 'gust_kmh' => 80, 'wc_c' => null, 'vis' => 'poor', 'timing' => 'early', 'commute' => 'whiteout', 'wait_min' => 10],
            'expect' => ['snow-day-calculator' => 74, 'snow-day-calculator-canada' => 74, 'college-snow-day-calculator' => 33],
        ],
        'freezing_rain' => [
            'label' => 'Freezing rain', 'condition' => 'freezing_rain',
            'values' => ['snow_cm' => 0, 'snow_hours' => 0, 'snow_rate' => null, 'rain_mm' => 0, 'rain_int' => 'moderate', 'ice_mm' => 5, 'refreeze_c' => null,
                         'temp_c' => -1, 'wind_kmh' => 20, 'gust_kmh' => null, 'wc_c' => null, 'vis' => 'reduced', 'timing' => 'early', 'commute' => 'icy', 'wait_min' => 10],
            'expect' => ['snow-day-calculator' => 67, 'snow-day-calculator-canada' => 67, 'ice-day-calculator' => 67, 'college-snow-day-calculator' => 26],
        ],
        'extreme_cold' => [
            'label' => 'Extreme cold', 'condition' => 'extreme_cold',
            'values' => ['snow_cm' => 0, 'snow_hours' => 0, 'snow_rate' => null, 'rain_mm' => 0, 'rain_int' => 'light', 'ice_mm' => 0, 'refreeze_c' => null,
                         'temp_c' => -32, 'wind_kmh' => 25, 'gust_kmh' => null, 'wc_c' => null, 'vis' => 'good', 'timing' => 'overnight', 'commute' => 'clear', 'wait_min' => 20],
            'expect' => ['snow-day-calculator' => 76, 'snow-day-calculator-canada' => 76, 'cold-day-calculator' => 81, 'college-snow-day-calculator' => 36],
        ],
        'rain' => [
            'label' => 'Rain', 'condition' => 'rain',
            'values' => ['snow_cm' => 0, 'snow_hours' => 0, 'snow_rate' => null, 'rain_mm' => 12, 'rain_int' => 'moderate', 'ice_mm' => 0, 'refreeze_c' => null,
                         'temp_c' => 4, 'wind_kmh' => 20, 'gust_kmh' => null, 'wc_c' => null, 'vis' => 'good', 'timing' => 'overnight', 'commute' => 'wet', 'wait_min' => 10],
            'expect' => ['snow-day-calculator' => 1, 'snow-day-calculator-canada' => 1, 'ice-day-calculator' => 1, 'college-snow-day-calculator' => 1],
        ],
        'clear' => [
            'label' => 'Clear', 'condition' => 'clear',
            'values' => ['snow_cm' => 0, 'snow_hours' => 0, 'snow_rate' => null, 'rain_mm' => 0, 'rain_int' => 'light', 'ice_mm' => 0, 'refreeze_c' => null,
                         'temp_c' => -5, 'wind_kmh' => 10, 'gust_kmh' => null, 'wc_c' => null, 'vis' => 'good', 'timing' => 'overnight', 'commute' => 'clear', 'wait_min' => 10],
            'expect' => ['snow-day-calculator' => 1, 'snow-day-calculator-canada' => 1, 'ice-day-calculator' => 1, 'cold-day-calculator' => 1, 'college-snow-day-calculator' => 1],
        ],
        'rain_refreeze' => [
            'label' => 'Rain, then a hard freeze', 'condition' => 'rain',
            'values' => ['snow_cm' => 0, 'snow_hours' => 0, 'snow_rate' => null, 'rain_mm' => 8, 'rain_int' => 'moderate', 'ice_mm' => 0, 'refreeze_c' => -6,
                         'temp_c' => -4, 'wind_kmh' => 20, 'gust_kmh' => null, 'wc_c' => null, 'vis' => 'good', 'timing' => 'evening', 'commute' => 'icy', 'wait_min' => 10],
            'expect' => ['ice-day-calculator' => 15],
        ],
        'bitter_wind' => [
            'label' => 'Bitter wind', 'condition' => 'extreme_cold',
            'values' => ['snow_cm' => 0, 'snow_hours' => 0, 'snow_rate' => null, 'rain_mm' => 0, 'rain_int' => 'light', 'ice_mm' => 0, 'refreeze_c' => null,
                         'temp_c' => -25, 'wind_kmh' => 40, 'gust_kmh' => null, 'wc_c' => null, 'vis' => 'good', 'timing' => 'overnight', 'commute' => 'clear', 'wait_min' => 30],
            'expect' => ['cold-day-calculator' => 38],
        ],
    ],

    /* =================================================================
     * DISCLAIMERS — sentences every page must carry. Tests check them.
     * ============================================================== */
    'disclaimers' => [
        'badge'     => 'Manual weather estimate',
        'basis'     => 'Based on the conditions you enter.',
        'no_fetch'  => 'This calculator uses the weather conditions you enter. It does not fetch live weather or school closure announcements.',
        'estimate'  => 'The calculator provides an estimate based on the conditions you enter. It is not a guarantee of a school closure.',
        'official'  => 'Actual closure decisions come from your local school, district or board — check their official announcement.',
        'accuracy'  => 'No accuracy percentage is claimed: the model is a transparent heuristic, not a statistical fit to closure records.',
        'college'   => 'Check your college or campus official operating notice — its email, text alert or emergency page.',
        'private'   => 'Nothing you enter leaves your browser.',
        'example'   => 'Example conditions — replace them with your local forecast.',
    ],

    /* =================================================================
     * PAGES — one record per page. 'tool' is the registry record that
     * app/config/tools.php publishes (title, meta description, H1,
     * keywords, related links). Articles: winter-weather-articles.php.
     *
     *   kind     closure | cold | formula
     *   region   default country (units and wording)
     *   focus    all | ice | cold  (which factors the estimate uses)
     *   level    k12 | college
     *   theme    the scene's page identity (sky tint + silhouette)
     *   fields   the manual inputs shown, in order
     *   settings the school / campus settings shown
     *   conditions  condition keys offered (default: all of them)
 *   presets  preset keys offered, `start` = the one loaded first
     * ============================================================== */
    'pages' => [

        'snow-day-calculator' => [
            'tool' => [
                'slug'        => 'snow-day-calculator',
                'name'        => 'Snow Day Calculator',
                'h1'          => 'Snow Day Calculator & Prediction Scenarios',
                'title'       => 'Snow Day Calculator & Predictor — Delay, Closure & What-If',
                'description' => 'Manual snow day calculator and predictor: enter your forecast to estimate a closure, delay or early dismissal, and test timing, roads, buses and what-if scenarios.',
                'short'       => 'Snow day, delay and normal-day chances from the forecast you enter.',
                'category'    => 'weather',
                'primary_kw'  => 'snow day calculator',
                'keywords'    => ['snow day calculator', 'snow day predictor', 'school snow day calculator', 'snow day probability calculator',
                                  'snow day calculator today', 'snow day calculator tomorrow', 'snow day calculator accuracy',
                                  'snow day calculator percentage', 'snow day calculator michigan', 'snow day calculator new york',
                                  'snow day calculator pennsylvania', 'snow day calculator minnesota', 'snow day rituals'],
                'related'     => ['snow-day-calculator-canada', 'ice-day-calculator', 'college-snow-day-calculator', 'cold-day-calculator', 'wind-chill-calculator', 'attendance-percentage-calculator'],
                'featured'    => false,
                'added'       => '2026-09-24',
                'status'      => 'live',
            ],
            'kind'   => 'closure',
            'scenarios' => true,   // the Scenario Workspace (app/config/winter-weather-scenarios.php)
            'region' => 'US',
            'focus'  => 'all',
            'level'  => 'k12',
            'theme'  => 'snow',
            'lede'   => 'Enter the forecast conditions you already have to estimate how a snow, ice or cold event could affect a school day: closed, late start, early dismissal or normal. Then use the scenario tools to test storm timing, road treatment, bus routes, district policy and what-if forecasts. It is a manual prediction tool — every number comes from what you enter, and the final call always belongs to your school district.',
            'fields'   => ['snow_cm', 'snow_hours', 'snow_rate', 'rain_mm', 'rain_int', 'ice_mm', 'temp_c', 'wind_kmh', 'gust_kmh', 'wc_c', 'vis', 'timing', 'commute'],
            'settings' => ['school_type', 'area', 'tendency', 'commute_sens'],
            'labels' => [
                'primary' => 'Estimated snow day scenario probability',
                'closure' => 'Snow day (closed)',
                'middle'  => 'Delay or early dismissal',
                'open'    => 'Normal school day',
                'second'  => 'Estimated delay / early-dismissal chance',
            ],
            'presets' => ['light_snow', 'moderate_snow', 'heavy_snow', 'snow_ice', 'snow_wind', 'freezing_rain', 'extreme_cold', 'rain', 'clear'],
            'start'   => 'moderate_snow',
            'refs'    => ['nws_home', 'wpc_wssi', 'nws_cold', 'nws_wind_chill', 'nws_ice', 'eccc_wind_chill', 'mde_michigan', 'pde_fid', 'mn_elearning', 'nyc_remote', 'dfe_emergency'],
            'faqs' => [
                ['q' => 'How does this snow day calculator work?',
                 'a' => 'You enter the conditions from your local forecast — snowfall, ice, rain, temperature, wind, visibility, storm timing and the roads you expect. Each factor is scored in points, the points combine into a weather pressure out of 100, and that pressure becomes three chances: snow day, delay and normal day. Every step is shown under the result.'],
                ['q' => 'Does it use live weather?',
                 'a' => 'No. It uses only the weather conditions you enter. It does not fetch a forecast, weather alerts or school closure announcements, and it never asks for your location. Enter your local forecast and it calculates from those figures.'],
                ['q' => 'How accurate is a snow day calculator?',
                 'a' => 'Nobody can give an honest single figure. A snow day is a decision made by people, so any calculator is limited by the forecast you enter and by how your district tends to decide. This page does not claim an accuracy percentage; it is a transparent estimate that shows its working.'],
                ['q' => 'Will there be a snow day tomorrow?',
                 'a' => 'Enter tomorrow’s forecast for your town: how much snow, when it falls, any freezing rain, the morning temperature and wind. The calculator gives a chance for that forecast. Only your school district can say for certain; most announce by early morning.'],
                ['q' => 'Can I use it for a snow day today?',
                 'a' => 'Yes — enter this morning’s conditions. Set the storm timing to “During the morning commute” if it is still snowing at bus time, and describe the roads under “Morning commute conditions”.'],
                ['q' => 'How much snow does it take to get a snow day?',
                 'a' => 'There is no national rule. A district that rarely sees snow may close for an inch or two, while districts used to heavy snow often stay open with several inches. Timing matters as much as the amount. Use “How easily does your school close?” to match your area.'],
                ['q' => 'Why did my result change?',
                 'a' => 'Every time you change a value, the box “Why did my result change?” lists each factor that moved and by how many points — for example “Snowfall 4 cm → 12 cm (+22 points)”.'],
                ['q' => 'What temperature causes school to close?',
                 'a' => 'Cold closures are usually about the wind chill at bus-stop time, and each district sets its own rule. There is no universal closing temperature. The cold day calculator compares your morning wind chill with your district’s own rule.'],
                ['q' => 'Can ice close schools even without much snow?',
                 'a' => 'Yes. Freezing rain glazes roads, sidewalks and bus steps, and a small amount can matter more than a few inches of snow. Ice is its own factor here, and the ice day calculator looks at ice on its own.'],
                ['q' => 'Does rain count towards a snow day?',
                 'a' => 'Ordinary rain does not. Rain counts only when you choose a freezing condition (freezing rain, or rain with freezing temperatures), or when it is followed by a hard freeze, when part of it is counted as possible ice.'],
                ['q' => 'Who decides if school is closed for snow?',
                 'a' => 'Your school district, usually the superintendent, often after checking roads before dawn. The National Weather Service forecasts the weather but does not close schools, and this page has no connection to any closure announcement.'],
                ['q' => 'Is this snow day calculator safe to use?',
                 'a' => 'Yes. There is no account, no app and no download, and nothing you enter leaves your browser. The optional city and ZIP code are context for you only; they are not looked up.'],
                ['q' => 'Is a delay or a closure more likely?',
                 'a' => 'Open the Delay vs closure tool under the result. It splits the forecast into four estimated outcomes — closed, late start, early dismissal and normal — and shows which factors push it one way. A storm that ends before dawn usually favours a delay; snow at bus time favours a closure.'],
                ['q' => 'Can it predict an early dismissal?',
                 'a' => 'Yes, as a scenario. Set the storm timing to school hours, or enter clock times in the timing tool. Snow arriving during the school day moves most of the in-between chance from a late start to an early dismissal.'],
                ['q' => 'Does it account for school buses and road treatment?',
                 'a' => 'Yes. The Roads & treatment tool lowers road pressure for treated roads (less in deep cold or when treatment is old), and the School bus risk tool can add a small, capped amount for long, rural or hilly routes. Both are scenario assumptions you control.'],
                ['q' => 'Can I compare two forecasts?',
                 'a' => 'Yes. The What-if comparison keeps your forecast as scenario A and lets you set up B and C — for example more snow, colder air or different timing — and shows the outcomes, weather pressure and the biggest change side by side.'],
                ['q' => 'Do snow day rituals work?',
                 'a' => 'No — pajamas inside out or a spoon under the pillow cannot change the weather. They are fun traditions, and the list below explains the common ones.'],
            ],
        ],

        'snow-day-calculator-canada' => [
            'tool' => [
                'slug'        => 'snow-day-calculator-canada',
                'name'        => 'Snow Day Calculator Canada',
                'h1'          => 'Snow Day Calculator Canada — Closures & Bus Cancellations',
                'title'       => 'Snow Day Calculator Canada — Manual Winter Weather Estimate',
                'description' => 'Canadian snow day calculator in cm, °C and km/h: enter your forecast and see the chance of a school closure, a bus cancellation or a normal day.',
                'short'       => 'Metric snow day estimate with closure vs bus cancellation.',
                'category'    => 'weather',
                'primary_kw'  => 'snow day calculator canada',
                'keywords'    => ['snow day calculator canada', 'snow day predictor canada', 'snow day calculator ontario', 'snow day predictor ontario',
                                  'snow day predictor toronto', 'snow day predictor ottawa', 'snow day predictor barrie', 'snow day predictor hamilton',
                                  'bus cancellations ontario'],
                'related'     => ['snow-day-calculator', 'ice-day-calculator', 'college-snow-day-calculator', 'cold-day-calculator', 'wind-chill-calculator', 'attendance-percentage-calculator'],
                'featured'    => false,
                'added'       => '2026-09-24',
                'status'      => 'live',
            ],
            'kind'   => 'closure',
            'region' => 'CA',
            'focus'  => 'all',
            'level'  => 'k12',
            'theme'  => 'canada',
            'lede'   => 'A snow day calculator for Canada, in centimetres, °C and km/h. Enter your forecast and pick your area: it keeps school closures and bus cancellations apart, because in much of Ontario buses are cancelled while schools stay open. Your board and transportation consortium make the real decisions.',
            'fields'   => ['snow_cm', 'snow_hours', 'snow_rate', 'rain_mm', 'rain_int', 'ice_mm', 'temp_c', 'wind_kmh', 'gust_kmh', 'wc_c', 'vis', 'timing', 'commute'],
            'settings' => ['ca_area', 'bus_rule', 'area', 'tendency', 'commute_sens'],
            'labels' => [
                'primary' => 'Estimated school-closure chance',
                'closure' => 'School closure',
                'middle'  => 'Buses cancelled, schools open',
                'open'    => 'Normal day',
                'second'  => 'Estimated bus-cancellation chance',
            ],
            'presets' => ['light_snow', 'moderate_snow', 'heavy_snow', 'snow_ice', 'snow_wind', 'freezing_rain', 'extreme_cold', 'rain', 'clear'],
            'start'   => 'moderate_snow',
            'refs'    => ['eccc_home', 'eccc_alert_types', 'eccc_wind_chill', 'cp24_gta'],
            'faqs' => [
                ['q' => 'Is there a snow day calculator for Canada?',
                 'a' => 'Yes — this page. Enter your forecast in centimetres, °C and km/h, choose your area, and read the chance of a school closure, of buses being cancelled while schools stay open, and of a normal day. It is free and needs no sign-up.'],
                ['q' => 'Does it read Environment Canada’s forecast?',
                 'a' => 'No. This calculator uses the weather conditions you enter; it does not fetch live weather, alerts or closure announcements. Take the figures from Environment Canada’s forecast for your town and enter them.'],
                ['q' => 'Will there be a snow day tomorrow in Ontario?',
                 'a' => 'Enter tomorrow’s forecast — snow before school, freezing rain, the morning temperature and wind — and choose your area. The estimate follows those figures. Your school board and your student transportation consortium make the real decisions, usually between 6 and 7 a.m.'],
                ['q' => 'What is the difference between a bus cancellation and a school closure?',
                 'a' => 'In much of Ontario, buses are run by a transportation consortium shared by the public and Catholic boards. On a bad morning it can cancel buses for a zone while schools stay open. A school closure means the building is closed to students. Some boards, such as HWDSB in Hamilton, close schools whenever they cancel buses for weather.'],
                ['q' => 'If buses are cancelled, is my child marked absent?',
                 'a' => 'Usually the school stays open on a bus-cancellation day, so a student who stays home is normally recorded as absent — check your board’s own attendance rules. The attendance calculator shows how missed days change an attendance percentage.'],
                ['q' => 'How much snow does it take to close schools in Canada?',
                 'a' => 'There is no national figure, and closures of whole school buildings are less common than bus cancellations. Freezing rain, blowing snow on rural roads and extreme cold often matter more than the snowfall total.'],
                ['q' => 'Does this work for Toronto, Ottawa, Barrie, Hamilton or Sudbury?',
                 'a' => 'Yes. Choose your area: each entry sets the local bus-cancellation rule and links to the board or consortium that makes the announcement. For anywhere else, choose “Elsewhere in Ontario” or “Elsewhere in Canada”.'],
                ['q' => 'How accurate is a Canadian snow day calculator?',
                 'a' => 'No honest single figure exists. This page does not claim an accuracy percentage; it shows every factor and assumption so you can judge the estimate yourself.'],
            ],
        ],

        'ice-day-calculator' => [
            'tool' => [
                'slug'        => 'ice-day-calculator',
                'name'        => 'Ice Day Calculator',
                'h1'          => 'Ice Day Calculator & Predictor',
                'title'       => 'Ice Day Calculator — Estimate School Disruption From Ice',
                'description' => 'Enter freezing rain, temperature and the overnight low to estimate an ice day: ice pressure, refreeze risk and the chance of a closure or delay.',
                'short'       => 'Freezing rain, refreeze risk and the ice-day chance.',
                'category'    => 'weather',
                'primary_kw'  => 'ice day calculator',
                'keywords'    => ['ice day calculator', 'ice day predictor', 'snow ice day calculator', 'free ice day calculator',
                                  'freezing rain school closure', 'freezing rain school delays', 'how much ice closes school', 'flash freeze school'],
                'related'     => ['snow-day-calculator', 'snow-day-calculator-canada', 'cold-day-calculator', 'college-snow-day-calculator', 'wind-chill-calculator'],
                'featured'    => false,
                'added'       => '2026-09-24',
                'status'      => 'live',
            ],
            'kind'   => 'closure',
            'region' => 'US',
            'focus'  => 'ice',
            'level'  => 'k12',
            'theme'  => 'ice',
            'lede'   => 'Will ice close school? Enter the freezing rain, any plain rain, the morning temperature and the overnight low from your forecast. The calculator shows the ice pressure, whether the conditions are freezing, the refreeze risk and an ice-day estimate — from your figures, not measured road ice.',
            'fields'   => ['ice_mm', 'rain_mm', 'rain_int', 'temp_c', 'refreeze_c', 'wind_kmh', 'gust_kmh', 'vis', 'timing', 'commute'],
            'settings' => ['school_type', 'area', 'tendency', 'commute_sens'],
            'labels' => [
                'primary' => 'Estimated ice day chance',
                'closure' => 'Ice day (closed)',
                'middle'  => 'Delay or buses cancelled',
                'open'    => 'Normal school day',
                'second'  => 'Estimated delay chance',
            ],
            'conditions' => ['freezing_rain', 'ice', 'rain_freezing', 'sleet_mixed', 'snow_ice', 'rain', 'clear'],
            'presets' => ['freezing_rain', 'snow_ice', 'rain_refreeze', 'rain', 'clear'],
            'start'   => 'freezing_rain',
            'refs'    => ['nws_ice', 'nws_home', 'wpc_wssi', 'eccc_home', 'eccc_alert_types'],
            'faqs' => [
                ['q' => 'What is an ice day?',
                 'a' => 'An ice day is a school closure or delay caused by ice rather than snow — usually freezing rain or freezing drizzle glazing roads, sidewalks and bus stops, or rain that freezes when the temperature drops overnight.'],
                ['q' => 'How much ice does it take to close school?',
                 'a' => 'There is no fixed amount, and districts decide locally. A thin glaze can be enough to stop buses because salt and plows work poorly on ice. For reference, the US National Weather Service issues its Ice Storm Warning for about a quarter inch (6 mm) of ice or more in many areas.'],
                ['q' => 'Does this measure ice on the roads?',
                 'a' => 'No. It uses the figures you enter. Ice accretion you type counts in full; plain rain counts as ice only if you choose a freezing condition, or partly when the overnight low is cold enough for it to refreeze.'],
                ['q' => 'What is a flash freeze?',
                 'a' => 'A flash freeze is when wet roads freeze quickly as the temperature drops below 0 °C, often after rain the evening before. The calculator flags it {refreeze}.'],
                ['q' => 'Does snow count on the ice day calculator?',
                 'a' => 'No — this page scores ice, cold and road conditions only, so you can see what the ice alone does. For snow and ice together, use the snow day calculator with the “Snow + ice” condition.'],
                ['q' => 'Does it fetch the forecast?',
                 'a' => 'No. This calculator uses the weather conditions you enter. It does not fetch live weather, alerts or school closure announcements.'],
                ['q' => 'Is freezing rain worse than snow for schools?',
                 'a' => 'Often, yes. Buses cannot stop safely on glaze, sidewalks and parking lots are hard to treat, and ice can bring down branches and power lines. A small amount of freezing rain can close schools that would stay open in several inches of snow.'],
                ['q' => 'Who decides if school closes for ice?',
                 'a' => 'Your school district or board — and in much of Canada, the student transportation consortium for buses. Weather services forecast the ice but do not close schools.'],
            ],
        ],

        'college-snow-day-calculator' => [
            'tool' => [
                'slug'        => 'college-snow-day-calculator',
                'name'        => 'College Snow Day Calculator',
                'h1'          => 'College Snow Day Calculator',
                'title'       => 'College Snow Day Calculator — Manual Winter Weather Estimate',
                'description' => 'Estimate whether your college will close, delay or go online: enter the forecast, campus type and class time to see the disruption chance today.',
                'short'       => 'Campus closure, delay or online chance from your forecast.',
                'category'    => 'weather',
                'primary_kw'  => 'college snow day calculator',
                'keywords'    => ['college snow day calculator', 'snow day calculator college', 'snow day calculator for college',
                                  'snow day calculator for university', 'university snow day calculator', 'do colleges have snow days',
                                  'evening classes cancelled snow'],
                'related'     => ['snow-day-calculator', 'snow-day-calculator-canada', 'ice-day-calculator', 'cold-day-calculator', 'attendance-percentage-calculator'],
                'featured'    => false,
                'added'       => '2026-09-24',
                'status'      => 'live',
            ],
            'kind'   => 'closure',
            'region' => 'US',
            'focus'  => 'all',
            'level'  => 'college',
            'theme'  => 'college',
            'lede'   => 'Will your campus close? Enter the forecast, describe your campus — residential or commuter, whether classes move online — and pick when your classes are, including evening classes. You get the disruption chance, the commute impact and the class-time impact; your college’s official notice is the only answer.',
            'fields'   => ['snow_cm', 'snow_hours', 'snow_rate', 'rain_mm', 'rain_int', 'ice_mm', 'temp_c', 'wind_kmh', 'gust_kmh', 'wc_c', 'vis', 'timing', 'commute'],
            'settings' => ['class_time', 'campus', 'online', 'tendency', 'commute_sens'],
            'labels' => [
                'primary' => 'Estimated campus-closure chance',
                'closure' => 'Campus closed',
                'middle'  => 'Delayed opening or online',
                'open'    => 'Normal classes',
                'second'  => 'Estimated disruption chance',
            ],
            'presets' => ['light_snow', 'moderate_snow', 'heavy_snow', 'snow_ice', 'snow_wind', 'freezing_rain', 'extreme_cold', 'rain', 'clear'],
            'start'   => 'heavy_snow',
            'refs'    => ['nws_home', 'wpc_wssi', 'eccc_home'],
            'faqs' => [
                ['q' => 'Do colleges have snow days?',
                 'a' => 'Yes, but less often than K–12 schools. Many students live on campus, staff are needed for residence halls and dining, and classes can move online, so colleges tend to stay open in weather that closes local schools. When they act, it is often a delayed opening, an early closure or an online day.'],
                ['q' => 'How is the college calculator different from the school one?',
                 'a' => 'It needs more weather pressure before it gives a high closure chance, it lets you describe your campus and whether it moves classes online, and it re-weights the storm timing for your class time — morning, late morning, afternoon or evening.'],
                ['q' => 'Can it check my evening classes?',
                 'a' => 'Yes. Choose “Evening” as your class time. A storm during the day then counts in full, because it hits the evening commute, while overnight snow counts for much less.'],
                ['q' => 'Will my university close if local schools close?',
                 'a' => 'Not necessarily. School districts close for bus safety; universities weigh commuting staff, residence students and online options. The two decisions are separate.'],
                ['q' => 'Does it read my college’s alerts?',
                 'a' => 'No. This calculator uses the weather conditions you enter. It does not fetch live weather or any college’s closure notice. Your college announces closures through its own emergency alerts.'],
                ['q' => 'Is there an accuracy figure?',
                 'a' => 'No. The college model has not been validated against campus decisions, so the page does not claim one. It shows the figures, the assumptions and the working.'],
            ],
        ],

        'cold-day-calculator' => [
            'tool' => [
                'slug'        => 'cold-day-calculator',
                'name'        => 'Cold Day Calculator',
                'h1'          => 'Cold Day Calculator for School',
                'title'       => 'Cold Day Calculator — Wind Chill & Cold Weather Estimate',
                'description' => 'Enter the morning temperature, wind and time outside to see the wind chill, frostbite risk and a cold-day estimate, checked against your district’s own rule.',
                'short'       => 'Morning wind chill against your school’s cold rule.',
                'category'    => 'weather',
                'primary_kw'  => 'cold day calculator',
                'keywords'    => ['cold day calculator', 'cold day calculator for school', 'cold day predictor',
                                  'how cold does it have to be to cancel school', 'what temperature do schools close', 'wind chill school closure'],
                'related'     => ['wind-chill-calculator', 'snow-day-calculator', 'snow-day-calculator-canada', 'ice-day-calculator'],
                'featured'    => false,
                'added'       => '2026-09-24',
                'status'      => 'live',
            ],
            'kind'   => 'cold',
            'region' => 'US',
            'focus'  => 'cold',
            'level'  => 'k12',
            'theme'  => 'cold',
            'lede'   => 'Is it cold enough to close school? Enter the morning temperature, the wind and how long students wait outside. The calculator works out the wind chill, shows the frostbite risk, compares it with your district’s own cold rule if you know it, and gives a cold-day estimate.',
            'fields'   => ['temp_c', 'wind_kmh', 'wc_c', 'wait_min'],
            'settings' => ['school_type', 'area', 'tendency'],
            'labels' => [
                'primary' => 'Morning wind chill',
                'closure' => 'Cold day (closed)',
                'middle'  => 'Late start or buses cancelled',
                'open'    => 'Normal school day',
                'second'  => 'Estimated cold-day chance',
            ],
            'conditions' => ['extreme_cold', 'clear'],
            'presets' => ['extreme_cold', 'bitter_wind', 'clear'],
            'start'   => 'extreme_cold',
            'refs'    => ['nws_wind_chill', 'eccc_wind_chill', 'nws_cold', 'dfe_emergency'],
            'faqs' => [
                ['q' => 'What is a cold day?',
                 'a' => 'A cold day is a school closure (or a delayed start) because of dangerous cold rather than snow. It is usually about the wind chill while students wait at bus stops or walk to school in the morning.'],
                ['q' => 'How cold does it have to be to cancel school?',
                 'a' => 'There is no national rule — each district or board sets its own, and many do not publish a number. If you know your district’s rule, enter it and the calculator compares your figures with it directly. It never invents a closing temperature.'],
                ['q' => 'Is it the temperature or the wind chill that matters?',
                 'a' => 'Usually the wind chill, because it describes how fast exposed skin loses heat in the wind. A calm −15 °F morning can be less dangerous than a windy 0 °F one. The calculator shows both, and lets you set your rule on either.'],
                ['q' => 'Does it use a live forecast?',
                 'a' => 'No. This calculator uses the weather conditions you enter. It does not fetch live weather or school closure announcements. Enter the forecast low and wind for bus-stop time.'],
                ['q' => 'What temperature do schools close in the UK?',
                 'a' => 'There is no set closing temperature. In England, government guidance leaves the decision to close to school leaders, based on their own risk assessment, and the Met Office issues the weather warnings.'],
                ['q' => 'What wind chill is dangerous for children?',
                 'a' => 'Environment Canada rates a wind chill of −28 °C (about −18 °F) or colder as high risk: exposed skin can freeze in 10 to 30 minutes. Dress children in layers, hats, mitts and a face covering well before those levels.'],
                ['q' => 'Does a cold day calculator know if my school is closed?',
                 'a' => 'No. It is an estimate from the conditions you enter. Your district or board announces closures on its website, app, social media and local media.'],
            ],
        ],

        'wind-chill-calculator' => [
            'tool' => [
                'slug'        => 'wind-chill-calculator',
                'name'        => 'Wind Chill Calculator',
                'h1'          => 'Wind Chill Calculator (°C and °F)',
                'title'       => 'Wind Chill Calculator — °F/°C Formula, Chart & Frostbite',
                'description' => 'Calculate wind chill in °C or °F with km/h, mph, m/s or knots using the NWS and Environment Canada formula, with a chart, frostbite risk and the old index.',
                'short'       => 'Wind chill in °C or °F, with the formula and a chart.',
                'category'    => 'weather',
                'primary_kw'  => 'wind chill calculator',
                'keywords'    => ['wind chill calculator', 'wind chill calculator celsius', 'wind chill calculator fahrenheit',
                                  'wind chill formula', 'wind chill calculator chart', 'old wind chill calculator',
                                  'feels like temperature calculator'],
                'related'     => ['cold-day-calculator', 'snow-day-calculator', 'snow-day-calculator-canada', 'ice-day-calculator'],
                'featured'    => false,
                'added'       => '2026-09-24',
                'status'      => 'live',
            ],
            'kind'   => 'formula',
            'region' => 'US',
            'focus'  => 'cold',
            'level'  => 'k12',
            'theme'  => 'wind',
            'lede'   => 'Work out the wind chill from any temperature and wind speed, in Celsius or Fahrenheit, with the wind in km/h, mph, m/s or knots. Uses the formula the US National Weather Service and Environment Canada share, shows the frostbite risk and a full chart, and keeps the old pre-2001 index as a historical comparison.',
            'presets' => [
                ['label' => '0 °F, 20 mph',    'data' => ['t' => '0', 'tu' => 'f', 'v' => '20', 'vu' => 'mph']],
                ['label' => '−10 °F, 15 mph',  'data' => ['t' => '-10', 'tu' => 'f', 'v' => '15', 'vu' => 'mph']],
                ['label' => '−15 °C, 20 km/h', 'data' => ['t' => '-15', 'tu' => 'c', 'v' => '20', 'vu' => 'kmh']],
                ['label' => '−30 °C, 30 km/h', 'data' => ['t' => '-30', 'tu' => 'c', 'v' => '30', 'vu' => 'kmh']],
                ['label' => '−5 °C, 10 m/s',   'data' => ['t' => '-5', 'tu' => 'c', 'v' => '10', 'vu' => 'ms']],
            ],
            'start'   => 2,
            'refs'    => ['nws_wind_chill', 'eccc_wind_chill'],
            'faqs' => [
                ['q' => 'How do you calculate wind chill?',
                 'a' => 'In °F and mph: wind chill = 35.74 + 0.6215T − 35.75V^0.16 + 0.4275TV^0.16. In °C and km/h: wind chill = 13.12 + 0.6215T − 11.37V^0.16 + 0.3965TV^0.16. T is the air temperature and V the wind speed at 10 metres. Both are the same 2001 index used by the US National Weather Service and Environment Canada.'],
                ['q' => 'How do I calculate wind chill in Celsius?',
                 'a' => 'Choose °C and enter the wind in km/h (or pick m/s or knots and the calculator converts). The metric formula is 13.12 + 0.6215T − 11.37V^0.16 + 0.3965TV^0.16. At −15 °C with a 20 km/h wind that gives about −24 °C.'],
                ['q' => 'Is there a wind chill above 50 degrees?',
                 'a' => 'No. The NWS applies the formula at 50 °F (10 °C) or colder with winds above 3 mph (about 4.8 km/h). In warmer or calmer air, wind chill is simply the air temperature, and the calculator says so instead of printing a made-up figure.'],
                ['q' => 'Does humidity change the wind chill?',
                 'a' => 'No. The wind chill index uses only air temperature and wind speed. Humidity matters in hot weather, where “feels like” means the heat index or humidex — a different calculation.'],
                ['q' => 'What was the old wind chill formula?',
                 'a' => 'Before November 2001, the US and Canada used an index based on experiments by Paul Siple and Charles Passel in Antarctica in the 1940s. It made cold feel much colder than the current index: 0 °F with a 20 mph wind was about −39 °F on the old index but −22 °F on the new one. The calculator shows it only as a historical comparison.'],
                ['q' => 'Is wind chill the same as “feels like” temperature?',
                 'a' => 'In cold weather, most forecasts’ “feels like” figure is the wind chill. Some apps and the UK Met Office also blend in humidity and sunshine, so their numbers can differ slightly.'],
                ['q' => 'Can wind chill freeze water or cool a car below the air temperature?',
                 'a' => 'No. Wind chill describes how fast exposed skin loses heat. Wind makes objects cool down faster, but never below the air temperature. Water will not freeze if the air is above 32 °F (0 °C), whatever the wind chill.'],
                ['q' => 'What wind chill causes frostbite?',
                 'a' => 'Environment Canada says exposed skin can freeze in 10 to 30 minutes at wind chills of −28 to −39, in 5 to 10 minutes at −40 to −47, and faster below that. The NWS chart shows frostbite in 30 minutes at a wind chill of −19 °F.'],
                ['q' => 'How do I convert Fahrenheit to Celsius?',
                 'a' => 'Subtract 32, then multiply by 5/9: °C = (°F − 32) × 5 ÷ 9. The other way: °F = °C × 9 ÷ 5 + 32. The calculator shows every result in both.'],
            ],
        ],
    ],
];
