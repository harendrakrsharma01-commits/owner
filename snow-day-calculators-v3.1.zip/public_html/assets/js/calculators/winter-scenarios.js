/* =========================================================================
   EasyCalculatorSmart — Scenario workspace UI (snow day page), v3.1

   Reads the page JSON (#ww-config → scenarios) and talks to the main
   calculator only through ECS.winterCalc (set values, re-render) and the
   'ww:result' event. All maths: assets/js/lib/snowday-scenarios.js on top
   of assets/js/lib/snowday.js. No network, no storage, textContent only.
   ========================================================================= */

(function (window, document) {
  'use strict';
  var ECS = window.ECS || {};
  var root = document.getElementById('scenario-workspace');
  var cfgEl = document.getElementById('ww-config');
  if (!root || !cfgEl || !ECS.snowday || !ECS.snowdayScenarios) return;
  var C; try { C = JSON.parse(cfgEl.textContent); } catch (e) { return; }
  var X = C.scenarios, S = ECS.snowday, SS = ECS.snowdayScenarios;
  var KM_PER_MI = 1.609344;          // unit conversion constant (exact by definition)

  function $(sel) { return root.querySelector(sel); }
  function $$(sel) { return Array.prototype.slice.call(root.querySelectorAll(sel)); }
  function id(x) { return document.getElementById(x); }
  function node(tag, cls, text) { var n = document.createElement(tag); if (cls) n.className = cls; if (text != null) n.textContent = text; return n; }
  function clear(n) { while (n && n.firstChild) n.removeChild(n.firstChild); return n; }
  function out(k) { return root.querySelector('[data-ws-out="' + k + '"]'); }
  function num(v) { return S.num(v); }
  function sign(n) { return String(n).replace(/-/g, '−'); }
  function pts(n) { return (n > 0 ? '+' : '') + sign(S.round(n, 1)) + ' pts'; }
  function panelError(panel, msg) { var e = root.querySelector('[data-ws-panel="' + panel + '"] [data-ws-error]'); if (e) e.textContent = msg || ''; }

  var last = null;  // latest winterState
  function sys() { return last ? last.sys : 'us'; }
  function distIn(v) { var n = num(v); return n == null ? null : (sys() === 'us' ? n * KM_PER_MI : n); }
  function distOut(km) { return sys() === 'us' ? S.round(km / KM_PER_MI, 1) + ' mi' : S.round(km, 1) + ' km'; }
  function unitText(kind) { if (kind === 'dist') return sys() === 'us' ? '(mi)' : '(km)'; var u = C.units[sys()]; return u && u[kind] ? '(' + u[kind] + ')' : ''; }

  /* ---------------- scenario state → main calculator ---------------- */

  function state() {
    var custom = num(id('ws-policy-custom').value);
    var du = id('ws-days').value;
    return {
      treatment: { level: id('ws-treat').value, age_h: num(id('ws-treat-age').value) },
      bus: { enabled: id('ws-bus-on').checked, dependence: id('ws-bus-dep').value, setting: id('ws-bus-set').value, route_km: distIn(id('ws-bus-km').value), route_min: num(id('ws-bus-min').value) },
      policy: id('ws-policy').value, custom: custom == null ? 0 : custom,
      region: id('ws-region').value,
      daysHeuristic: id('ws-days-h').value, daysUsed: du === '6+' ? 6 : +du
    };
  }
  ECS.winterScenarioState = state;

  /* ---------------- tabs ---------------- */

  var tabs = $$('[data-ws-tab]');
  function showTab(k, focus) {
    tabs.forEach(function (t) { var on = t.getAttribute('data-ws-tab') === k; t.setAttribute('aria-selected', on ? 'true' : 'false'); t.tabIndex = on ? 0 : -1; if (on && focus) t.focus(); });
    $$('[data-ws-panel]').forEach(function (p) { p.hidden = p.getAttribute('data-ws-panel') !== k; });
  }
  tabs.forEach(function (t, i) {
    t.addEventListener('click', function () { showTab(t.getAttribute('data-ws-tab')); });
    t.addEventListener('keydown', function (ev) {
      var j = ev.key === 'ArrowRight' ? i + 1 : ev.key === 'ArrowLeft' ? i - 1 : ev.key === 'Home' ? 0 : ev.key === 'End' ? tabs.length - 1 : null;
      if (j === null) return; ev.preventDefault(); j = (j + tabs.length) % tabs.length; showTab(tabs[j].getAttribute('data-ws-tab'), true);
    });
  });

  /* ---------------- panels ---------------- */

  function bars(host, rows) {
    clear(host);
    rows.forEach(function (r) {
      var row = node('div', 'ws-bar-row');
      row.appendChild(node('span', 'ws-bar-k', r[0]));
      var track = node('div', 'ws-bar'), fill = node('span', 'ws-bar-fill ws-' + r[2]);
      fill.style.inlineSize = Math.max(0, Math.min(100, r[1])) + '%';
      track.appendChild(fill); row.appendChild(track);
      row.appendChild(node('span', 'ws-bar-v', r[1] + '%'));
      host.appendChild(row);
    });
  }
  function list(host, items) { var ul = node('ul', 'ws-list'); items.forEach(function (t) { ul.appendChild(node('li', null, t)); }); host.appendChild(ul); }

  function renderDelay(st) {
    var o = st.outcomes || SS.outcomes(st.res), L = X.outcomes.labels, host = out('outcomes');
    clear(host);
    host.appendChild(node('p', 'ws-k', X.outcomes.probability_label));
    var b = node('div'); host.appendChild(b);
    bars(b, [[L.closure, o.closure, 'closure'], [L.delay, o.delay, 'delay'], [L.early, o.early, 'early'], [L.normal, o.normal, 'normal']]);
    var t = st.res.derived.timing, share = X.outcomes.split[t.key];
    var dr = S.drivers(st.res, 3);
    out('delay-why').textContent = 'Storm timing “' + t.short + '”: ' + Math.round((share == null ? 1 : share) * 100) + '% of the in-between outcome counts as a late start and the rest as an early dismissal. '
      + (dr.length ? 'Biggest factors: ' + dr.map(function (f) { return f.label.toLowerCase() + ' (' + pts(f.points) + ')'; }).join(', ') + '.' : 'No factor adds weather pressure.');
  }

  function renderRoads(st) {
    var v = st.vals, r = SS.treatment({ level: id('ws-treat').value, age_h: num(id('ws-treat-age').value), road: v.commute, temp_c: v.temp_c });
    out('road-now').textContent = (C.commute[v.commute] || C.commute.clear).label;
    var host = clear(out('roads'));
    host.appendChild(node('p', 'ws-big', r.points ? pts(r.points) : 'No change'));
    list(host, [
      'Road pressure: ' + r.roadPoints + ' → ' + r.roadAfter + ' points.',
      r.level === X.treatment.default ? 'No treatment selected.' : r.label + ' keeps ' + Math.round(r.tempKeep * 100) + '% of its effect at this temperature and ' + Math.round(r.ageKeep * 100) + '% at this age.',
      'Applied to the estimate above as “' + X.treatment.label + '”.'
    ]);
  }

  function renderBus(st) {
    var s = state().bus, b = SS.bus(s, st.res), host = clear(out('bus'));
    host.appendChild(node('p', 'ws-big', b.level));
    list(host, b.parts.map(function (p) { return p[0].replace(/(\d+(\.\d+)?) km/, function (m, x) { return distOut(+x); }) + ': ' + pts(p[1]); })
      .concat(['Weather and road share: ' + pts(b.weatherPoints), 'Route score: ' + b.score + (s.enabled ? ' · adds ' + pts(b.estimatePoints) + ' to the estimate (cap ' + X.bus.estimate_cap + ')' : ' · not added to the estimate (tick the box)')]));
  }

  function renderCommute(st) {
    var c = SS.commute({ distance_km: distIn(id('ws-cm-km').value), minutes: num(id('ws-cm-min').value), route: id('ws-cm-route').value }, st.res), host = clear(out('commute'));
    host.appendChild(node('p', 'ws-big', c.level));
    list(host, c.parts.map(function (p) { return p[0].replace(/(\d+(\.\d+)?) km/, function (m, x) { return distOut(+x); }) + ': ' + pts(p[1]); })
      .concat([c.timingConflict ? 'Timing conflict: the storm overlaps the morning travel window.' : 'No timing conflict with the morning travel window.', 'Informational only — it does not change the school estimate.']));
  }

  function renderPolicy(st) {
    var host = clear(out('policy')), parts = (st.res.centerParts || []);
    host.appendChild(node('p', 'ws-big', 'Closure curve centre: ' + st.res.center));
    list(host, parts.length ? parts.map(function (p) { return p.label + ': ' + (p.shift > 0 ? '+' : '') + sign(p.shift); }) : ['No adjustments.']);
    var pol = X.policy.profiles[id('ws-policy').value], reg = X.region.profiles[id('ws-region').value];
    host.appendChild(node('p', 'hint', pol.description + ' ' + reg.description + ' Scenario assumptions' + (pol.verified || reg.verified ? '' : ' — not verified district or regional policy') + '.'));
    id('ws-policy-custom').closest('.field').hidden = id('ws-policy').value !== 'custom';
  }

  function renderPlow(st) {
    var host = clear(out('plow'));
    var p = SS.plow({ road_km: distIn(id('ws-pl-km').value), plows: num(id('ws-pl-n').value), snow_cm: S.isNum(st.vals.snow_cm) ? st.vals.snow_cm : 0,
      start: id('ws-pl-start').value, school: id('ws-school').value, treat_delay_min: num(id('ws-pl-delay').value) });
    if (!p.ok) { panelError('plow', X.errors[p.error] || X.errors.number); return; }
    panelError('plow', '');
    host.appendChild(node('p', 'ws-big', p.hours + ' h · done about ' + p.finish));
    list(host, [
      p.passes + ' pass' + (p.passes === 1 ? '' : 'es') + ' at about ' + (sys() === 'us' ? S.round(p.speed / KM_PER_MI, 1) + ' mph' : p.speed + ' km/h') + ' working speed.',
      p.overlapsCommute ? 'Overlaps the morning commute: about ' + p.clearedByCommute + '% cleared when it starts, ' + distOut(p.remainingKm) + ' left.' : 'Finished before the morning commute starts.'
    ]);
  }

  /* ---- timeline ---- */
  var blocksBody = $('[data-ws-blocks]');
  function addBlock(b) {
    if (blocksBody.children.length >= X.timeline.max_blocks) return;
    var tr = node('tr');
    function cell(el) { var td = node('td'); td.appendChild(el); tr.appendChild(td); return el; }
    function inp(cls, val, label) { var i = node('input', 'input ' + cls); i.type = 'text'; i.value = val == null ? '' : val; i.setAttribute('aria-label', label); i.autocomplete = 'off'; return i; }
    cell(inp('ws-b-start', b.start, 'Block start time'));
    cell(inp('ws-b-hours', b.hours, 'Block length in hours'));
    var sel = node('select', 'select ws-b-type'); sel.setAttribute('aria-label', 'Precipitation type');
    Object.keys(X.timeline.block_types).forEach(function (k) { var o = node('option', null, X.timeline.block_types[k].label); o.value = k; if (k === b.type) o.selected = true; sel.appendChild(o); });
    cell(sel);
    cell(inp('ws-b-snow', b.snow, 'Snow in this block'));
    cell(inp('ws-b-ice', b.ice, 'Ice in this block'));
    cell(inp('ws-b-temp', b.temp, 'Temperature in this block'));
    var rm = node('button', 'btn btn-secondary ws-b-rm', '×'); rm.type = 'button'; rm.setAttribute('aria-label', 'Remove this block');
    rm.addEventListener('click', function () { tr.parentNode.removeChild(tr); update(); });
    cell(rm);
    blocksBody.appendChild(tr);
  }
  function readBlocks() {
    return Array.prototype.map.call(blocksBody.children, function (tr) {
      var q = function (c) { return tr.querySelector('.' + c).value; };
      return { start: q('ws-b-start'), hours: num(q('ws-b-hours')), type: q('ws-b-type'),
        snow_cm: S.fromDisplay('snow', num(q('ws-b-snow')), sys()), ice_mm: S.fromDisplay('ice', num(q('ws-b-ice')), sys()), temp_c: S.fromDisplay('temp', num(q('ws-b-temp')), sys()) };
    });
  }
  var tlResult = null;
  function renderTimeline() {
    var mode = root.querySelector('input[name="ws-tl-mode"]:checked').value;
    $$('[data-ws-tl]').forEach(function (x) { x.hidden = x.getAttribute('data-ws-tl') !== mode; });
    var r = mode === 'times' ? SS.fromTimes({ school: id('ws-school').value, start: id('ws-st').value, peak: id('ws-pk').value, end: id('ws-en').value }) : SS.fromBlocks(readBlocks(), id('ws-school').value);
    var msgs = clear(out('timeline')), strip = clear(out('strip'));
    tlResult = r.ok ? { mode: mode, r: r } : null;
    if (!r.ok) { panelError('timeline', X.errors[r.error] || X.errors.number); return; }
    panelError('timeline', '');
    var hitKeys = {};
    if (mode === 'times') (r.spanned || []).forEach(function (w) { hitKeys[w.key] = 1; });
    else r.blocks.forEach(function (b) { if (b.snow_cm > 0 || b.ice_mm > 0) hitKeys[b.window.key] = 1; });
    X.timeline.windows.forEach(function (w) {
      var seg = node('span', 'ws-seg' + (hitKeys[w.key] ? ' is-hit' : '') + ((mode === 'times' ? r.window.key : null) === w.key ? ' is-peak' : ''), w.label);
      strip.appendChild(seg);
    });
    var tm = r.timing && C.timing[r.timing] ? C.timing[r.timing].label : '—';
    r.messages.concat(['Timing used by the estimate: ' + tm + '.']).forEach(function (m) { msgs.appendChild(node('li', null, m)); });
    if (mode === 'blocks') msgs.appendChild(node('li', null, 'Totals: ' + (S.isNum(r.values.snow_cm) ? S.round(S.toDisplay('snow', r.values.snow_cm, sys()), 1) + ' ' + C.units[sys()].snow + ' snow' : '') + (r.values.ice_mm ? ', ' + S.round(S.toDisplay('ice', r.values.ice_mm, sys()), 2) + ' ' + C.units[sys()].ice + ' ice' : '') + (S.isNum(r.values.snow_rate) ? ', peak rate ' + S.round(S.toDisplay('rate', r.values.snow_rate, sys()), 1) + ' ' + C.units[sys()].rate : '') + '.'));
  }
  function applyTimeline() {
    if (!tlResult || !ECS.winterCalc) return;
    var r = tlResult.r, set = {};
    if (r.timing) set.timing = r.timing;
    if (tlResult.mode === 'blocks') { set.snow_cm = r.values.snow_cm; set.ice_mm = r.values.ice_mm; set.snow_rate = r.values.snow_rate; if (S.isNum(r.values.temp_c)) set.temp_c = r.values.temp_c; }
    ECS.winterCalc.setValues(set);
    live('Timing applied to the calculator.');
  }

  /* ---- what-if ---- */
  var cmpHost = $('[data-ws-compare]'), scen = {};
  function cmpField(name, key, v) {
    var def = C.field_defs[key], wrap = node('div', 'field'), lab = node('label', 'label', def.label), elx;
    var fid = 'ws-cmp-' + name + '-' + key; lab.htmlFor = fid;
    if (key === 'timing' || key === 'commute' || key === 'vis') {
      var src = key === 'timing' ? C.timing : key === 'commute' ? C.commute : C.visibility;
      elx = node('select', 'select'); Object.keys(src).forEach(function (k) { var o = node('option', null, src[k].label); o.value = k; if (k === v) o.selected = true; elx.appendChild(o); });
    } else {
      lab.appendChild(document.createTextNode(' (' + C.units[sys()][def.unit] + ')'));
      elx = node('input', 'input'); elx.type = 'text'; elx.inputMode = 'decimal'; elx.autocomplete = 'off';
      elx.value = S.isNum(v) ? S.round(S.toDisplay(def.unit, v, sys()), S.displayDp(def.unit, sys())) : '';
    }
    elx.id = fid; elx.setAttribute('data-k', key);
    wrap.appendChild(lab); wrap.appendChild(elx); return wrap;
  }
  function buildCompare() {
    clear(cmpHost);
    var base = last ? last.vals : {};
    ['B', 'C'].forEach(function (name) {
      if (name === 'C' && !scen.C) return;
      var vals = {}; Object.keys(base).forEach(function (k) { vals[k] = base[k]; });
      var st = (X.compare.starts[name] || {}); Object.keys(st).forEach(function (k) { vals[k] = st[k]; });
      if (scen[name] && scen[name].values) vals = scen[name].values;
      scen[name] = { values: vals };
      var fs = node('fieldset', 'ws-scn'); fs.appendChild(node('legend', null, 'Scenario ' + name));
      var row = node('div', 'field-row');
      X.compare.fields.forEach(function (k) { row.appendChild(cmpField(name, k, vals[k])); });
      fs.appendChild(row); fs.setAttribute('data-scn', name); cmpHost.appendChild(fs);
    });
  }
  function readScenario(name) {
    var fs = cmpHost.querySelector('[data-scn="' + name + '"]'); if (!fs) return null;
    var vals = {}; Object.keys(last.vals).forEach(function (k) { vals[k] = last.vals[k]; });
    Array.prototype.forEach.call(fs.querySelectorAll('[data-k]'), function (el) {
      var k = el.getAttribute('data-k'), def = C.field_defs[k];
      if (el.tagName === 'SELECT') vals[k] = el.value; else { var n = num(el.value); vals[k] = n == null ? null : S.fromDisplay(def.unit, n, sys()); }
    });
    scen[name].values = vals;
    return vals;
  }
  function renderCompare() {
    if (!last) return;
    var list2 = [{ name: 'A (your forecast)', values: last.vals }];
    ['B', 'C'].forEach(function (n) { var v = scen[n] && readScenario(n); if (v) list2.push({ name: n, values: v }); });
    var runs = SS.compare(list2, last.settings, state()), host = clear(out('compare')), L = X.outcomes.labels;
    var tbl = node('table', 'ws-cmp-table'), head = node('tr');
    head.appendChild(node('th', null, ''));
    runs.forEach(function (r) { head.appendChild(node('th', null, r.name)); });
    var thead = node('thead'); thead.appendChild(head); tbl.appendChild(thead);
    var tb = node('tbody');
    [['closure', L.closure], ['delay', L.delay], ['early', L.early], ['normal', L.normal]].forEach(function (rw) {
      var tr = node('tr'); tr.appendChild(node('th', null, rw[1]));
      runs.forEach(function (r, i) {
        var td = node('td'); var bar = node('span', 'ws-mini ws-' + rw[0]); bar.style.inlineSize = r.outcomes[rw[0]] + '%';
        td.appendChild(bar); td.appendChild(node('span', 'ws-mini-v', r.outcomes[rw[0]] + '%' + (i && r.delta && rw[0] !== 'normal' ? ' (' + (r.delta[rw[0]] > 0 ? '+' : '') + sign(r.delta[rw[0]]) + ')' : ''))); tr.appendChild(td);
      });
      tb.appendChild(tr);
    });
    var trp = node('tr'); trp.appendChild(node('th', null, 'Weather pressure')); runs.forEach(function (r) { trp.appendChild(node('td', null, sign(r.res.pressure) + ' / 100')); }); tb.appendChild(trp);
    var trt = node('tr'); trt.appendChild(node('th', null, 'Storm timing')); runs.forEach(function (r) { trt.appendChild(node('td', null, r.res.derived.timing.short)); }); tb.appendChild(trt);
    var trb = node('tr'); trb.appendChild(node('th', null, 'Biggest change vs A')); runs.forEach(function (r, i) { trb.appendChild(node('td', null, !i ? '—' : r.biggest ? r.biggest.label + ' ' + sign(r.biggest.from) + ' → ' + sign(r.biggest.to) + ' pts' : 'no factor moved')); }); tb.appendChild(trb);
    tbl.appendChild(tb);
    var wrap = node('div', 'ws-table-wrap'); wrap.appendChild(tbl); host.appendChild(wrap);
  }

  /* ---------------- wiring ---------------- */

  function live(t) { var l = $('[data-ws-live]'); if (l) l.textContent = t; }
  function renderAll() {
    if (!last) return;
    $$('[data-ws-unit]').forEach(function (u) { u.textContent = unitText(u.getAttribute('data-ws-unit')); });
    renderDelay(last); renderRoads(last); renderBus(last); renderCommute(last); renderPolicy(last); renderPlow(last); renderTimeline(); renderCompare();
  }
  var lastSys = null;
  document.addEventListener('ww:result', function (ev) {
    last = ev.detail;
    if (lastSys !== last.sys || !cmpHost.firstChild) { lastSys = last.sys; buildCompare(); }
    renderAll();
  });
  function update() { if (ECS.winterCalc) ECS.winterCalc.rerender(); else renderAll(); }

  // Inputs that change the estimate → re-run the main calculator; others → just this workspace.
  ['ws-treat', 'ws-treat-age', 'ws-bus-on', 'ws-bus-dep', 'ws-bus-set', 'ws-bus-km', 'ws-bus-min', 'ws-policy', 'ws-policy-custom', 'ws-region', 'ws-days-h', 'ws-days']
    .forEach(function (k) {
      var e = id(k); if (!e) return;
      // one event per edit: typing → 'input', selects / checkboxes → 'change' (so "why did it change" sees one step)
      e.addEventListener(e.tagName === 'INPUT' && e.type === 'text' ? 'input' : 'change', update);
    });
  root.addEventListener('input', function (ev) { if (ev.target.closest('[data-ws-panel="timeline"],[data-ws-panel="commute"],[data-ws-panel="plow"],[data-ws-panel="compare"]')) renderAll(); });
  root.addEventListener('change', function (ev) { if (ev.target.closest('[data-ws-panel="timeline"],[data-ws-panel="compare"]')) renderAll(); });
  $('[data-ws-apply="timeline"]').addEventListener('click', applyTimeline);
  $('[data-ws-add-block]').addEventListener('click', function () {
    // A new block starts where the last one ends.
    var rows = readBlocks(), lastB = rows[rows.length - 1], st = '';
    if (lastB) { var m0 = SS.parseClock(lastB.start || ''); if (m0 != null) st = SS.fmtClock(m0 + (lastB.hours || X.timeline.block_hours_default) * 60, true); }
    addBlock({ start: st, hours: X.timeline.block_hours_default, type: 'snow' }); renderAll();
  });
  $('[data-ws-add-c]').addEventListener('click', function (ev) { scen.C = {}; buildCompare(); renderAll(); ev.target.hidden = true; });

  // Starting blocks: the night before a commute storm (display units filled after the first result).
  [['00:00', 3, 'snow', 2], ['03:00', 3, 'snow', 4], ['06:00', 3, 'snow', 3]].forEach(function (b) { addBlock({ start: b[0], hours: b[1], type: b[2], snow: b[3] }); });

  if (window.ECS.winterState) { last = window.ECS.winterState; buildCompare(); renderAll(); } else if (ECS.winterCalc) ECS.winterCalc.rerender();
})(window, document);
