/* =========================================================================
   EasyCalculatorSmart — Manual winter weather calculators (page script)

   Drives /snow-day-calculator/, /snow-day-calculator-canada/,
   /ice-day-calculator/, /college-snow-day-calculator/ and
   /cold-day-calculator/. What differs between them is in the page's JSON
   config (#ww-config, built from app/config/winter-weather.php): fields,
   conditions, presets, focus (which factors count), level, labels.

   Flow: inputs → metric values → ECS.snowday.calculate() → dashboard,
   and ECS.snowday.visual() → ECS.winterScene (the background).

   MANUAL ONLY. No fetch, no XHR, no geolocation, no storage. The values
   live in one object (`vals`, metric); the boxes show them in the chosen
   units, so switching units converts the boxes and never the result.
   textContent only — the optional city / postal code are shown as typed
   text, never as markup.
   ========================================================================= */

(function (window, document) {
  'use strict';

  var ECS = window.ECS;
  var cfgEl = document.getElementById('ww-config');
  var form = document.getElementById('ww-form');
  if (!ECS || !ECS.snowday || !cfgEl || !form) return;

  var C;
  try { C = JSON.parse(cfgEl.textContent); } catch (e) { return; }
  var S = ECS.snowday.configure(C), U = S.units;
  /* Scenario workspace (snow day page only): same engine, config-driven adjustments. */
  var SS = C.scenarios && ECS.snowdayScenarios ? ECS.snowdayScenarios.configure(C) : null;
  var PG = C.page, L = PG.labels;
  var IS_COLD = PG.kind === 'cold', IS_ICE = PG.focus === 'ice', IS_COLLEGE = PG.level === 'college', IS_CA = PG.region === 'CA';

  function $(id) { return document.getElementById(id); }
  function $$(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
  function node(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined && text !== null) n.textContent = text;
    return n;
  }
  function radio(name, dflt) { var c = form.querySelector('input[name="' + name + '"]:checked'); return c ? c.value : dflt; }
  function setRadio(name, value) { var r = form.querySelector('input[name="' + name + '"][value="' + value + '"]'); if (r) r.checked = true; }
  function val(id, dflt) { var x = $(id); return x ? x.value : dflt; }
  function sign(s) { return String(s).replace(/-/g, '−'); }

  var el = {
    hero: $('ww-hero'), canvas: $('ww-canvas'), condIco: $('ww-cond-ico'), cond: $('ww-cond'), condVals: $('ww-cond-vals'),
    place: $('ww-place'), heroV: $('ww-hero-v'), heroBand: $('ww-hero-band'), hero2: $('ww-hero-2v'), example: $('ww-example'),
    sceneDesc: $('ww-scene-desc'), suggest: $('ww-suggest'), suggestText: $('ww-suggest-text'), suggestBtn: $('ww-suggest-btn'),
    country: $('ww-country'), region: $('ww-region'), city: $('ww-city'), postal: $('ww-postal'), postalLabel: $('ww-postal-label'), tip: $('ww-country-tip'),
    areaSel: $('ww-area-ca'), areaNote: $('ww-area-note'), busrule: $('ww-busrule'), rule: $('ww-rule'), ruleBasis: $('ww-rule-basis'),
    tlNow: $('ww-tl-now'), reset: $('ww-reset'),
    dash: $('ww-dash'), notes: $('ww-notes'), primary: $('ww-primary'), sub: $('ww-sub'), bar: $('ww-bar'), middle: $('ww-middle-label'),
    iceSum: $('ww-ice-sum'), collegeSum: $('ww-college-sum'), ruleOut: $('ww-rule-out'), drivers: $('ww-drivers'),
    why: $('ww-why'), whyList: $('ww-why-list'), chart: $('ww-chart'), factors: $('ww-factors'),
    officialLinks: $('ww-official-links'), steps: $('ww-steps'), share: $('ww-share-text'), live: $('ww-live')
  };
  var formError = form.querySelector('.form-error');

  /* ---------------------------------------------------------------
     STATE
     --------------------------------------------------------------- */

  var FIELD_KEYS = Object.keys(C.fields);
  var NUM_KEYS = FIELD_KEYS.filter(function (k) { return (C.fields[k].type || 'number') !== 'select'; });
  var vals = {};          // metric, the single source of truth
  var cond = 'clear';
  var sys = IS_CA ? 'metric' : 'us';
  var prev = null;        // previous result, for "why did my result change?"
  var example = true;     // still showing a preset the reader has not edited
  var scene = ECS.winterScene && el.hero && el.canvas ? ECS.winterScene.create(el.hero, el.canvas, C.visuals) : null;

  function unitLabel(kind) {
    if (kind === 'hours') return 'h';
    if (kind === 'minutes') return 'min';
    return (C.units[sys] || {})[kind] || '';
  }

  /* ---------------------------------------------------------------
     FORMATTING (display units)
     --------------------------------------------------------------- */

  function fmt(kind, v, dp) {
    if (!S.isNum(v)) return '—';
    var d = S.toDisplay(kind, v, sys);
    var p = dp !== undefined ? dp : S.displayDp(kind, sys);
    return sign(S.round(d, p)) + ' ' + unitLabel(kind);
  }
  function other(kind, v) {
    if (!S.isNum(v)) return '';
    var o = sys === 'us' ? 'metric' : 'us';
    var d = S.toDisplay(kind, v, o);
    return sign(S.round(d, S.displayDp(kind, o))) + ' ' + ((C.units[o] || {})[kind] || '');
  }
  function pts(n) { return (n > 0 ? '+' : '') + sign(S.round(n, 1)) + ' points'; }

  /* ---------------------------------------------------------------
     INPUT BOXES ⇄ VALUES
     --------------------------------------------------------------- */

  function input(key) { return $('ww-' + key); }

  function writeBox(key) {
    var f = C.fields[key], box = input(key);
    if (!box) return;
    if ((f.type || 'number') === 'select') { if (vals[key]) box.value = vals[key]; return; }
    var v = vals[key];
    box.value = S.isNum(v) ? String(S.round(S.toDisplay(f.unit, v, sys), f.unit === 'hours' || f.unit === 'minutes' ? 1 : S.displayDp(f.unit, sys))).replace(/^-/, '-') : '';
    clearError(key);
  }

  function writeAll() {
    FIELD_KEYS.forEach(writeBox);
    setRadio('ww-timing', vals.timing || 'overnight');
    $$('.ww-unit').forEach(function (u) { u.textContent = unitLabel(u.getAttribute('data-unit')); });
    $$('[data-unit-inline]').forEach(function (u) { u.textContent = unitLabel(u.getAttribute('data-unit-inline')); });
  }

  function clearError(key) {
    var box = input(key), err = $('ww-' + key + '-error');
    if (err) err.textContent = '';
    if (box) box.removeAttribute('aria-invalid');
  }

  /* Read one number box into vals; returns false if it is invalid. */
  function readBox(key) {
    var f = C.fields[key], box = input(key), err = $('ww-' + key + '-error');
    if (!box) return true;
    var raw = box.value.trim();
    clearError(key);
    if (raw === '') { vals[key] = null; return true; }
    var n = S.num(raw);
    var lo = S.toDisplay(f.unit, f.min, sys), hi = S.toDisplay(f.unit, f.max, sys);
    var m = n === null ? null : S.fromDisplay(f.unit, n, sys);
    if (m === null || m < f.min - 1e-9 || m > f.max + 1e-9) {
      if (err) err.textContent = f.label + ' must be a number from ' + sign(S.round(lo, 1)) + ' to ' + sign(S.round(hi, 1)) + ' ' + unitLabel(f.unit) + '.';
      box.setAttribute('aria-invalid', 'true');
      return false;
    }
    vals[key] = m;
    return true;
  }

  function step(key, dir) {
    var f = C.fields[key];
    if (!f) return;
    var st = (f.step || {})[sys] || 1;
    var cur = S.isNum(vals[key]) ? S.toDisplay(f.unit, vals[key], sys) : 0;
    var next = S.round(Math.round((cur + dir * st) / st) * st, 3);
    var m = S.fromDisplay(f.unit, next, sys);
    vals[key] = S.clamp(m, f.min, f.max);
    writeBox(key);
    touched();
    render(true);
  }

  /* ---------------------------------------------------------------
     SETTINGS
     --------------------------------------------------------------- */

  function caArea() { return C.ca_areas && el.areaSel ? C.ca_areas[el.areaSel.value] || null : null; }

  function settings() {
    var s = {
      condition: cond, ignore: PG.ignore, level: PG.level,
      tendency: radio('ww-tend', 'typical'), commuteSens: form.querySelector('input[name="ww-csens"]') ? radio('ww-csens', 'typical') : null,
      area: radio('ww-area', 'suburban'), school: val('ww-school', 'public'),
      campus: radio('ww-campus', 'mixed'), online: val('ww-online', 'sometimes'), classTime: val('ww-class', 'morning'),
      busRule: el.busrule ? el.busrule.value : 'delay'
    };
    var middle = L.middle;
    if (IS_COLLEGE) middle = (C.college.online[s.online] || {}).middle || L.middle;
    else if (el.busrule) {
      var a = caArea();
      middle = a && a.middle && a.rule === s.busRule ? a.middle : (C.bus_rules[s.busRule] || {}).middle || L.middle;
    }
    s.middle = middle;
    return s;
  }

  /* ---------------------------------------------------------------
     LOCATION CONTEXT (context only — nothing is looked up)
     --------------------------------------------------------------- */

  function cleanText(s, max) {
    return String(s || '').replace(/[\u0000-\u001f\u007f]/g, '').replace(/\s+/g, ' ').trim().slice(0, max);
  }

  function country() { return el.country && C.countries[el.country.value] ? el.country.value : (IS_CA ? 'CA' : 'US'); }

  function fillRegions(cc) {
    if (!el.region) return;
    var c = C.countries[cc];
    el.region.textContent = '';
    el.region.appendChild(node('option', '', '—')).value = '';
    Object.keys(c.regions || {}).forEach(function (code) {
      var o = node('option', '', c.regions[code]);
      o.value = code;
      el.region.appendChild(o);
    });
    var lab = form.querySelector('label[for="ww-region"]');
    if (lab) lab.textContent = c.region_label;
    if (el.postalLabel) el.postalLabel.textContent = c.postal_label;
    if (el.postal) el.postal.maxLength = c.postal_max;
    if (el.tip) el.tip.textContent = c.tip;
  }

  function place() {
    var cc = country(), c = C.countries[cc];
    var city = el.city ? cleanText(el.city.value, 60) : '';
    var region = el.region && el.region.value ? (c.regions || {})[el.region.value] || '' : '';
    var postal = el.postal ? cleanText(el.postal.value, 10).toUpperCase().replace(/[^A-Z0-9 -]/g, '') : '';
    var parts = [city, region, postal].filter(Boolean);
    return { cc: cc, country: c, city: city, region: el.region ? el.region.value : '', regionName: region, text: parts.join(', ') };
  }

  function stateNote(p) {
    if (p.cc !== 'US' || !p.region) return null;
    var city = p.city.toLowerCase();
    var hit = null;
    (C.state_notes || []).forEach(function (n) {
      if (hit || n.state !== p.region) return;
      if (n.cities && n.cities.length && n.cities.indexOf(city) < 0) return;
      hit = n;
    });
    return hit;
  }

  /* ---------------------------------------------------------------
     WORDS FOR FACTORS
     --------------------------------------------------------------- */

  function factorValue(key, res) {
    var v = res.values, d = res.derived;
    switch (key) {
      case 'snow':
        if (PG.ignore.indexOf('snow') >= 0) return 'not counted on this page';
        if (!(v.snow_cm > 0)) return 'no snow';
        return fmt('snow', v.snow_cm) + ' × ' + S.round(d.share * 100, 0) + '% timing' + (d.melt < 1 ? ' × ' + S.round(d.melt * 100, 0) + '% warm ground' : '') + ' = ' + fmt('snow', d.effSnowCm) + ' effective';
      case 'ice':
        if (PG.ignore.indexOf('ice') >= 0) return 'not counted on this page';
        if (!(d.freezingMm > 0)) return 'none';
        var parts = [];
        if (d.iceMm > 0) parts.push(fmt('ice', d.iceMm) + ' ice');
        if (d.rainIceMm > 0) parts.push(fmt('rain', d.rainIceMm) + ' rain as ice');
        if (d.refreezeMm > 0) parts.push(fmt('rain', d.refreezeMm) + ' refreeze');
        return parts.join(' + ');
      case 'cold':
        if (!S.isNum(d.wcC)) return 'enter a temperature';
        return fmt('temp', d.wcC) + (d.wcSource === 'entered' ? ' (entered)' : d.wcSource === 'formula' ? ' (formula)' : ' (air temperature)');
      case 'rate':
        if (!S.isNum(d.rateCmH)) return 'no snowfall rate';
        return fmt('rate', d.rateCmH) + (d.rateSource === 'derived' ? ' (amount ÷ duration)' : '') + ' × ' + S.round(d.timing.rate * 100, 0) + '% timing';
      case 'wind': return S.isNum(v.wind_kmh) ? fmt('wind', v.wind_kmh) + (d.wintry ? '' : ' (counts with snow or ice)') : '—';
      case 'gust': return S.isNum(v.gust_kmh) ? fmt('wind', v.gust_kmh) + (d.wintry ? '' : ' (counts with snow or ice)') : 'not entered';
      case 'vis': return C.visibility[v.vis].label + (d.wintry || v.vis === 'good' ? '' : ' (counts with snow or ice)');
      case 'timing': return d.timing.label + (d.wintry ? '' : ' (counts with snow or ice)');
      case 'commute': return C.commute[v.commute].label;
      case 'exposure': return S.isNum(v.wait_min) ? S.round(v.wait_min, 0) + ' min' : '—';
    }
    var sf = (res.factors || []).filter(function (x) { return x.key === key && x.group === 'scenario'; })[0];
    return sf ? 'scenario adjustment' : 'not set';
  }

  /* ---------------------------------------------------------------
     RENDER
     --------------------------------------------------------------- */

  function tile(parent, k, v, s, icon) {
    var d = node('div', 'ww-tile');
    var kk = node('span', 'ww-tile-k');
    if (icon) {
      var svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
      svg.setAttribute('class', 'ww-ico ww-tile-i'); svg.setAttribute('aria-hidden', 'true');
      var use = document.createElementNS('http://www.w3.org/2000/svg', 'use');
      use.setAttribute('href', '#wxi-' + icon);
      svg.appendChild(use);
      kk.appendChild(svg);
    }
    kk.appendChild(document.createTextNode(k));
    d.appendChild(kk);
    d.appendChild(node('span', 'ww-tile-v ltr', v));
    if (s) d.appendChild(node('span', 'ww-tile-s', s));
    parent.appendChild(d);
  }

  function setIcon(host, name) {
    if (!host) return;
    var use = host.querySelector('use');
    if (use) use.setAttribute('href', '#wxi-' + name);
  }

  function has(key) { return Object.prototype.hasOwnProperty.call(C.fields, key); }

  function renderDashboard(res) {
    var v = res.values, d = res.derived;
    el.dash.textContent = '';
    var CD = C.all_conditions[cond];
    tile(el.dash, 'Condition', CD.label, null, CD.icon);
    if (has('snow_cm')) tile(el.dash, 'Snow', fmt('snow', v.snow_cm || 0), (v.snow_hours > 0 ? 'over ' + S.round(v.snow_hours, 1) + ' h' : '') + (S.isNum(d.rateCmH) ? (v.snow_hours > 0 ? ' · ' : '') + fmt('rate', d.rateCmH) : ''), 'wx-snow');
    if (has('rain_mm')) tile(el.dash, 'Rain', fmt('rain', v.rain_mm || 0), (v.rain_mm > 0 ? C.rain_intensity[v.rain_int].label.toLowerCase() : '') + (d.rainIceMm > 0 ? ' · counted as ice' : ''), 'wx-rain');
    if (has('ice_mm')) tile(el.dash, 'Ice', fmt('ice', v.ice_mm || 0), d.refreezeMm > 0 ? '+ ' + fmt('rain', d.refreezeMm) + ' refreeze' : '', 'wx-ice');
    tile(el.dash, 'Temperature', S.isNum(v.temp_c) ? fmt('temp', v.temp_c) : '—', other('temp', v.temp_c), 'thermometer');
    tile(el.dash, 'Wind', S.isNum(v.wind_kmh) ? fmt('wind', v.wind_kmh) : '—', S.isNum(v.gust_kmh) ? 'gusts ' + fmt('wind', v.gust_kmh) : '', 'wind');
    tile(el.dash, 'Wind chill', S.isNum(d.wcC) ? fmt('temp', d.wcC) : '—', d.wcSource === 'entered' ? 'as entered' : d.wcSource === 'formula' ? 'feels like (formula)' : d.wcSource === 'air' ? 'no wind chill: air temperature' : '', 'wx-cold');
    if (IS_COLD) {
      var risk = S.ecccRisk(d.wcC);
      tile(el.dash, 'Frostbite risk', risk ? risk.short : '—', risk ? risk.note : '', 'wx-cold');
      tile(el.dash, 'Time outside', S.isNum(v.wait_min) ? S.round(v.wait_min, 0) + ' min' : '—', 'bus stop or walk');
    } else {
      if (has('vis')) tile(el.dash, 'Visibility', C.visibility[v.vis].label.split(' (')[0], null, 'wx-fog');
      if (has('commute')) tile(el.dash, 'Morning conditions', C.commute[v.commute].label, null);
      if (has('timing')) tile(el.dash, 'Storm timing', d.timing.short, d.timing.label);
    }
  }

  function renderOutcomes(res, s) {
    var o = { closure: res.closure, delay: res.delay, open: res.open };
    Object.keys(o).forEach(function (k) {
      var x = form.parentNode.querySelector('[data-o="' + k + '"]');
      if (x) x.textContent = o[k] + '%';
      var seg = el.bar.querySelector('[data-seg="' + k + '"]');
      if (seg) seg.style.inlineSize = o[k] + '%';
    });
    el.middle.textContent = s.middle;
    el.bar.setAttribute('aria-label', L.closure + ' ' + res.closure + '%, ' + s.middle + ' ' + res.delay + '%, ' + L.open + ' ' + res.open + '%');
    el.primary.textContent = res.closure + '%';
    el.sub.textContent = res.band + ' · weather pressure ' + sign(res.pressure) + ' / 100';
  }

  function renderHero(res, vis, p) {
    var d = res.derived;
    var CD = C.all_conditions[cond];
    el.cond.textContent = CD.label;
    setIcon(el.condIco, CD.icon);
    var bits = [];
    var v = res.values;
    if (v.snow_cm > 0 && PG.ignore.indexOf('snow') < 0) bits.push(fmt('snow', v.snow_cm) + ' snow');
    if (v.ice_mm > 0) bits.push(fmt('ice', v.ice_mm) + ' ice');
    if (v.rain_mm > 0) bits.push(fmt('rain', v.rain_mm) + ' rain');
    if (S.isNum(v.temp_c)) bits.push(fmt('temp', v.temp_c));
    if (S.isNum(v.wind_kmh)) bits.push('wind ' + fmt('wind', v.wind_kmh));
    if (S.isNum(d.wcC) && d.wcSource !== 'air') bits.push('feels like ' + fmt('temp', d.wcC));
    el.condVals.textContent = bits.join(' · ');
    el.place.textContent = p.text;
    el.place.hidden = !p.text;
    if (IS_COLD) {
      el.heroV.textContent = S.isNum(d.wcC) ? fmt('temp', d.wcC, 0) : '—';
      var risk = S.ecccRisk(d.wcC);
      el.heroBand.textContent = risk ? risk.risk : '';
      el.hero2.textContent = res.closure + '%';
    } else {
      el.heroV.textContent = res.closure + '%';
      el.heroBand.textContent = res.band;
      el.hero2.textContent = (IS_COLLEGE ? res.disrupt : res.delay) + '%';
    }
    if (el.example) el.example.hidden = !example;

    /* The scene line for screen readers: words, not animation. */
    var layers = [];
    Object.keys(vis.layers).forEach(function (k) {
      if (vis.layers[k] > C.visuals.strength.none_below) layers.push(S.strength(vis.layers[k]) + ' ' + { snow: 'snowfall', rain: 'rain', crystal: 'ice crystals', mist: 'cold mist', streak: 'wind streaks' }[k]);
    });
    el.sceneDesc.textContent = 'Background: ' + CD.label.toLowerCase() + ' scene' + (layers.length ? ' with ' + layers.join(', ') : ', calm') + '. It follows the values you enter.';
  }

  function renderKeyFields() {
    var CD = C.all_conditions[cond] || {};
    var keys = CD.key || [];
    $$('[data-field-wrap]', form).forEach(function (w) {
      var k = w.getAttribute('data-field-wrap').replace(/^ww-/, '');
      w.classList.toggle('is-key', keys.indexOf(k) >= 0);
    });
    $$('input[name="ww-cond"]', form).forEach(function (r) { r.checked = r.value === cond; });
  }

  function renderTimeline(res, vis) {
    var steps = $$('.ww-tl-step', form);
    if (!steps.length) return;
    var order = Object.keys(C.timing), at = order.indexOf(res.values.timing);
    var fall = C.visuals.timeline_falloff;
    var k = Math.max(vis.intensity.snow, vis.intensity.rain, vis.intensity.ice, C.visuals.timeline_min);
    steps.forEach(function (s) {
      var i = order.indexOf(s.getAttribute('data-tl'));
      var dist = Math.abs(i - at);
      var h = dist < fall.length ? fall[dist] * k : 0;
      var fill = s.querySelector('.ww-tl-fill');
      if (fill) fill.style.blockSize = Math.round(h * 100) + '%';
      s.classList.toggle('is-on', dist === 0);
    });
    if (el.tlNow) el.tlNow.textContent = 'Storm placed: ' + res.derived.timing.label + ' — ' + S.round(res.derived.share * 100, 0) + '% of the snow counts' + (res.derived.timing.points ? ', ' + res.derived.timing.points + ' timing points with snow or ice.' : '.');
  }

  function renderNotes(res, p) {
    el.notes.textContent = '';
    function note(text, cls) { el.notes.appendChild(node('p', 'ww-note' + (cls ? ' ' + cls : ''), text)); }
    var v = res.values, d = res.derived;
    var sn = stateNote(p);
    if (sn) note(sn.title + ': ' + sn.text);
    var a = caArea();
    if (a && el.areaNote) el.areaNote.textContent = a.label + ': ' + a.boards + '. Buses: ' + a.buses + '. Decisions usually by ' + a.time + '. ' + a.note;
    if (d.refreezeMm > 0) {
      note('Refreeze: ' + fmt('rain', d.refreezeMm) + ' of the rain is counted as possible ice, because the overnight low (' + fmt('temp', d.refreezeLowC) + ') is cold enough for wet roads to freeze.');
    } else if (cond === 'rain' && S.isNum(v.temp_c) && v.temp_c <= 0 && v.rain_mm > 0) {
      note('Rain at ' + fmt('temp', v.temp_c) + ' could freeze on contact. Plain “Rain” never counts as ice here — choose “Freezing rain” or “Rain + freezing temperature” if your forecast calls for it.', 'ww-warn');
    }
    if (d.melt < 1 && v.snow_cm > 0 && PG.ignore.indexOf('snow') < 0) note('At ' + fmt('temp', v.temp_c) + ' some snow melts on the roads, so ' + S.round(d.melt * 100, 0) + '% of it is counted.');
    if (res.groups.capped) note('The extras (rate, wind, gusts, visibility, timing and roads) add up to ' + res.groups.extrasRaw + ' points and are capped at ' + C.model.extras_cap + '.');
    if (res.busRule === 'closes') note('With this bus rule, a weather bus cancellation closes schools too, so the closure chance equals the chance of any disruption.');
  }

  function renderSuggest() {
    if (!el.suggest) return;
    var d = S.detect(vals);
    /* heavy snow typed as "Snow" (or the reverse) is the same weather: no nudge. */
    var same = (cond === "heavy_snow" && d === "snow") || (cond === "snow" && d === "heavy_snow");
    if (!C.conditions[d] || d === cond || same || example) { el.suggest.hidden = true; return; }
    el.suggest.hidden = false;
    el.suggestText.textContent = 'Your figures look like “' + C.all_conditions[d].label + '”.';
    el.suggestBtn.textContent = 'Show as ' + C.all_conditions[d].label;
    el.suggestBtn.setAttribute('data-to', d);
  }

  function renderChart(res) {
    /* Weather pressure on a 0–100 scale with the two curve centres. */
    el.chart.textContent = '';
    var wrap = node('div', 'ww-gauge');
    var track = node('div', 'ww-gauge-track');
    var fill = node('span', 'ww-gauge-fill');
    fill.style.inlineSize = S.clamp(res.pressure, 0, 100) + '%';
    track.appendChild(fill);
    [[res.center - res.gap, 'delay 50%'], [res.center, 'closure 50%']].forEach(function (m) {
      var mk = node('span', 'ww-gauge-mark');
      mk.style.insetInlineStart = S.clamp(m[0], 0, 100) + '%';
      mk.appendChild(node('span', 'ww-gauge-mk', m[1] + ' at ' + sign(S.round(m[0], 0))));
      track.appendChild(mk);
    });
    wrap.appendChild(node('p', 'ww-gauge-t', 'Weather pressure ' + sign(res.pressure) + ' / 100' + (prev ? ' (was ' + sign(prev.pressure) + ')' : '')));
    wrap.appendChild(track);
    var scale = node('div', 'ww-gauge-scale');
    ['0', '25', '50', '75', '100'].forEach(function (t) { scale.appendChild(node('span', '', t)); });
    wrap.appendChild(scale);
    el.chart.appendChild(wrap);

    /* Factor bars, with the previous value as a ghost bar. */
    el.factors.textContent = '';
    res.factors.forEach(function (f) {
      if (f.ignored) return;
      var li = node('li', 'ww-factor');
      var top = node('div', 'ww-factor-top');
      top.appendChild(node('span', 'ww-factor-name', f.label));
      top.appendChild(node('span', 'ww-factor-pts ltr', sign(S.round(f.points, 1)) + ' pts'));
      li.appendChild(top);
      var bar = node('span', 'ww-fbar');
      var p = prev ? prev.factors.filter(function (x) { return x.key === f.key; })[0] : null;
      if (p && Math.abs(p.points - f.points) >= C.model.chart_change_threshold) {
        var ghost = node('span', 'ww-fbar-ghost');
        ghost.style.inlineSize = S.clamp(p.points, 0, 100) + '%';
        bar.appendChild(ghost);
      }
      var fl = node('span', 'ww-fbar-fill ww-inf-' + f.influence);
      fl.style.inlineSize = S.clamp(f.points, 0, 100) + '%';
      bar.appendChild(fl);
      li.appendChild(bar);
      li.appendChild(node('span', 'ww-factor-val', factorValue(f.key, res) + ' · ' + (f.influence === 'none' ? 'no effect' : f.influence + ' influence') + (p && Math.abs(p.points - f.points) >= 0.5 ? ' · was ' + sign(p.points) : '')));
      el.factors.appendChild(li);
    });
  }

  function renderWhy(res, changed) {
    if (!changed || !prev) { if (!prev) el.why.hidden = true; return; }
    var dd = S.diff(prev, res);
    el.whyList.textContent = '';
    if (!dd || (!dd.factors.length && !dd.center && !dd.closure)) {
      el.whyList.appendChild(node('li', '', 'Nothing that affects the estimate changed.'));
    } else {
      var headK = IS_COLD ? 'Cold-day chance' : L.primary.replace(/^Estimated /, '');
      el.whyList.appendChild(node('li', 'ww-why-head', headK.charAt(0).toUpperCase() + headK.slice(1) + ' ' + (res.closure - dd.closure) + '% → ' + res.closure + '% (' + (dd.closure > 0 ? '+' : '') + sign(dd.closure) + ')'));
      dd.factors.forEach(function (f) {
        el.whyList.appendChild(node('li', '', f.label + ': ' + factorValue(f.key, prev) + ' → ' + factorValue(f.key, res) + ' (' + pts(f.delta) + ')'));
      });
      if (dd.center) el.whyList.appendChild(node('li', '', 'Your school settings moved the closure curve ' + (dd.center > 0 ? 'up' : 'down') + ' by ' + Math.abs(dd.center) + ' points (it now needs ' + (dd.center > 0 ? 'more' : 'less') + ' weather).'));
    }
    el.why.hidden = false;
  }

  function renderIce(res) {
    if (!el.iceSum) return;
    var I = S.iceSummary(res);
    el.iceSum.textContent = '';
    tile(el.iceSum, 'Ice pressure', sign(S.round(I.pressure, 1)) + ' / 100', 'points from ' + fmt('ice', res.derived.freezingMm) + ' of freezing precipitation', 'wx-ice');
    tile(el.iceSum, 'Freezing condition', I.freezing === null ? '—' : I.freezing ? 'Yes — at or below freezing' : 'No — above freezing', S.isNum(res.values.temp_c) ? 'commute temperature ' + fmt('temp', res.values.temp_c) : '', 'thermometer');
    var rr = { none: 'None', low: 'Low', moderate: 'Moderate', high: 'High' }[I.refreezeRisk];
    tile(el.iceSum, 'Refreeze risk (estimate)', rr, S.isNum(I.lowC) ? (S.isNum(res.values.refreeze_c) ? 'overnight low ' : 'no overnight low entered; commute temperature ') + fmt('temp', I.lowC) + (res.derived.refreezeMm > 0 ? ' · ' + fmt('rain', res.derived.refreezeMm) + ' counted' : '') : 'enter an overnight low', 'wx-cold');
  }

  function renderCollege(res) {
    if (!el.collegeSum) return;
    el.collegeSum.textContent = '';
    var f = {};
    res.factors.forEach(function (x) { f[x.key] = x.points; });
    tile(el.collegeSum, 'Disruption chance', res.disrupt + '%', 'closed, delayed or online', 'graduation');
    tile(el.collegeSum, 'Commute impact', sign(S.round((f.commute || 0) + (f.vis || 0) + (f.wind || 0) + (f.gust || 0), 1)) + ' pts', 'roads, visibility and wind', 'wind');
    var ct = C.college.class_times[val('ww-class', 'morning')] || {};
    tile(el.collegeSum, 'Class-time weather impact', sign(S.round((f.timing || 0) + (f.rate || 0), 1)) + ' pts', (ct.label || '') + ': ' + S.round(res.derived.share * 100, 0) + '% of the snow counts', 'wx-snow');
  }

  function renderRule(res) {
    if (!el.ruleOut || !el.rule) return;
    var raw = el.rule.value.trim(), err = $('ww-rule-error');
    err.textContent = ''; el.rule.removeAttribute('aria-invalid');
    if (raw === '') { el.ruleOut.hidden = true; return; }
    var n = S.num(raw);
    if (n === null) { err.textContent = 'Enter the rule as a number, for example ' + (sys === 'us' ? '−25' : '−35') + '.'; el.rule.setAttribute('aria-invalid', 'true'); el.ruleOut.hidden = true; return; }
    var ruleC = S.fromDisplay('temp', n, sys);
    var basis = el.ruleBasis ? el.ruleBasis.value : 'wc';
    var x = basis === 'wc' ? res.derived.wcC : res.values.temp_c;
    el.ruleOut.hidden = false;
    if (!S.isNum(x)) { el.ruleOut.textContent = 'Enter a temperature to compare with your rule.'; return; }
    var gap = x - ruleC;
    el.ruleOut.textContent = gap <= 0
      ? 'Your rule: close at or below ' + fmt('temp', ruleC) + ' ' + (basis === 'wc' ? 'wind chill' : 'air temperature') + '. The figure you entered (' + fmt('temp', x) + ') is at or past it — by your district’s own rule, this morning would qualify. Only the district announces it.'
      : 'Your rule: close at or below ' + fmt('temp', ruleC) + '. The figure you entered (' + fmt('temp', x) + ') is ' + S.round(S.toDisplay('temp', x, sys) - S.toDisplay('temp', ruleC, sys), 0) + ' degrees (' + unitLabel('temp') + ') warmer than the rule.';
  }

  function renderOfficial(p, sn) {
    el.officialLinks.textContent = '';
    var links = [];
    var a = caArea();
    if (a) a.links.forEach(function (l) { links.push([l[0], l[1]]); });
    if (sn) sn.refs.forEach(function (r) { links.push([r[0], r[1]]); });
    (p.country.refs || []).forEach(function (r) { links.push([r[0], r[1]]); });
    var seen = {};
    links.forEach(function (l) {
      if (seen[l[1]]) return;
      seen[l[1]] = 1;
      var li = node('li'), aEl = node('a', '', l[0]);
      aEl.href = l[1]; aEl.rel = 'noopener'; aEl.target = '_blank';
      li.appendChild(aEl);
      el.officialLinks.appendChild(li);
    });
    var who = $('ww-official-who');
    if (who && !IS_COLLEGE) who.textContent = p.country.note + ' ' + C.disclaimers.official;
  }

  function renderSteps(res) {
    var M = C.model, g = res.groups, d = res.derived, v = res.values;
    var steps = [];
    var inp = [];
    if (has('snow_cm')) inp.push('snow ' + fmt('snow', v.snow_cm || 0));
    if (has('rain_mm')) inp.push('rain ' + fmt('rain', v.rain_mm || 0));
    if (has('ice_mm')) inp.push('ice ' + fmt('ice', v.ice_mm || 0));
    inp.push('temperature ' + fmt('temp', v.temp_c), 'wind ' + fmt('wind', v.wind_kmh));
    steps.push('Inputs (' + C.all_conditions[cond].label + '): ' + inp.join(', ') + '. Worked in metric: ' + [S.isNum(v.snow_cm) ? S.round(v.snow_cm, 2) + ' cm' : null, S.isNum(v.temp_c) ? sign(S.round(v.temp_c, 1)) + ' °C' : null, S.isNum(v.wind_kmh) ? S.round(v.wind_kmh, 1) + ' km/h' : null].filter(Boolean).join(', ') + '.');
    if (PG.ignore.indexOf('snow') < 0) steps.push('Snow: ' + factorValue('snow', res) + ' → ' + sign(g.snow) + ' points.');
    if (PG.ignore.indexOf('ice') < 0) steps.push('Ice: ' + (d.freezingMm > 0 ? factorValue('ice', res) + ' = ' + S.round(d.freezingMm, 2) + ' mm' : 'none') + (C.all_conditions[cond].rain_ice ? ' (' + S.round(C.all_conditions[cond].rain_ice * 100, 0) + '% of the rain counts as ice for this condition)' : '') + ' → ' + sign(g.ice) + ' points.');
    if (S.isNum(d.wcC)) {
      steps.push('Wind chill: ' + (d.wcSource === 'formula'
        ? '13.12 + 0.6215 × ' + sign(S.round(v.temp_c, 1)) + ' − 11.37 × ' + S.round(v.wind_kmh, 1) + '^0.16 + 0.3965 × ' + sign(S.round(v.temp_c, 1)) + ' × ' + S.round(v.wind_kmh, 1) + '^0.16 = ' + sign(S.round(d.wcC, 1)) + ' °C'
        : d.wcSource === 'entered' ? sign(S.round(d.wcC, 1)) + ' °C as entered' : 'calm or mild air, so the air temperature, ' + sign(S.round(d.wcC, 1)) + ' °C') + ' → ' + sign(g.cold) + ' points.');
    }
    var ex = res.factors.filter(function (f) { return f.group === 'extras' && !f.ignored && f.points > 0; });
    steps.push('Extras: ' + (ex.length ? ex.map(function (f) { return f.label.toLowerCase() + ' ' + sign(f.points); }).join(' + ') + ' = ' + sign(g.extrasRaw) + (g.capped ? ', capped at ' + M.extras_cap : '') : 'none') + ' → ' + sign(g.extras) + ' points.');
    steps.push('Total weather pressure = 100 × (1 − (1 − ' + g.snow + '/100)(1 − ' + g.ice + '/100)(1 − ' + g.cold + '/100)(1 − ' + g.extras + '/100)) = ' + sign(res.pressure) + '.');
    steps.push('Closure curve centre = ' + M.center + (res.centerParts.length ? res.centerParts.map(function (x) { return (x.shift > 0 ? ' + ' : ' − ') + Math.abs(x.shift) + ' (' + x.label + ')'; }).join('') : '') + ' = ' + res.center + '.');
    steps.push('Probability conversion: closure = 100 ÷ (1 + e^(−(' + sign(res.pressure) + ' − ' + res.center + ') ÷ ' + M.spread + ')) = ' + res.closure + '% (kept between ' + M.min + '% and ' + M.max_closure + '%). Any disruption uses a centre ' + res.gap + ' lower: ' + res.disrupt + '%.');
    steps.push('So: ' + L.closure + ' ' + res.closure + '%, ' + settings().middle + ' ' + res.delay + '%, ' + L.open + ' ' + res.open + '%.');
    el.steps.textContent = '';
    steps.forEach(function (s) { el.steps.appendChild(node('li', '', s)); });
  }

  function renderShare(res, p) {
    var lines = [PG.name + ' — ' + C.disclaimers.badge.toLowerCase() + (p.text ? ' for ' + p.text : '')];
    lines.push(C.all_conditions[cond].label + ': ' + el.condVals.textContent);
    if (IS_COLD) lines.push('Wind chill ' + fmt('temp', res.derived.wcC) + ' · cold-day chance ' + res.closure + '%');
    else lines.push(L.closure + ' ' + res.closure + '% · ' + settings().middle + ' ' + res.delay + '% · ' + L.open + ' ' + res.open + '%');
    lines.push(C.disclaimers.estimate);
    lines.push(window.location.href.split('#')[0].split('?')[0]);
    el.share.textContent = lines.join('\n');
  }

  var liveTimer = 0;
  function announce(res) {
    if (liveTimer) window.clearTimeout(liveTimer);
    liveTimer = window.setTimeout(function () {
      el.live.textContent = IS_COLD
        ? 'Wind chill ' + fmt('temp', res.derived.wcC) + '. Estimated cold-day chance ' + res.closure + '%.'
        : L.primary + ' ' + res.closure + '%. ' + settings().middle + ' ' + res.delay + '%. ' + L.open + ' ' + res.open + '%.';
    }, 600);
  }

  function render(changed) {
    var s = settings();
    var run = SS && ECS.winterScenarioState ? SS.run(vals, s, ECS.winterScenarioState()) : null;
    var res = run ? run.res : S.calculate(vals, s);
    var vis = S.visual(vals, cond);
    var p = place();
    if (scene) scene.set(vis);
    renderHero(res, vis, p);
    renderKeyFields();
    renderTimeline(res, vis);
    renderDashboard(res);
    renderNotes(res, p);
    renderSuggest();
    renderOutcomes(res, s);
    renderIce(res);
    renderCollege(res);
    renderRule(res);
    var dr = S.drivers(res, 3);
    el.drivers.textContent = dr.length ? 'Biggest factors: ' + dr.map(function (f) { return f.label.toLowerCase() + ' (' + sign(f.points) + ' pts)'; }).join(', ') + '.' : 'No factor adds weather pressure with these conditions.';
    renderWhy(res, changed);
    renderChart(res);
    renderOfficial(p, stateNote(p));
    renderSteps(res);
    renderShare(res, p);
    announce(res);
    prev = res;
    /* Read-only handle for testing and debugging. */
    window.ECS.winterState = { res: res, vis: vis, cond: cond, sys: sys, vals: vals, scene: scene, settings: s, outcomes: run ? run.outcomes : null };
    /* Tell the scenario workspace (if present) a new result exists. */
    if (SS) document.dispatchEvent(new CustomEvent('ww:result', { detail: window.ECS.winterState }));
  }

  /* ---------------------------------------------------------------
     ACTIONS
     --------------------------------------------------------------- */

  function touched() { example = false; }

  /* Hooks for assets/js/calculators/winter-scenarios.js — metric values in, same render path. */
  window.ECS.winterCalc = {
    rerender: function () { render(true); },
    setValues: function (obj) {
      Object.keys(obj || {}).forEach(function (k) { if (Object.prototype.hasOwnProperty.call(C.field_defs, k) && obj[k] !== undefined) vals[k] = obj[k]; });
      touched(); writeAll(); render(true);
    },
    values: function () { var o = {}; Object.keys(vals).forEach(function (k) { o[k] = vals[k]; }); return o; },
    sys: function () { return sys; }
  };

  function loadPreset(key) {
    var pr = C.presets[key];
    if (!pr) return;
    vals = {};
    Object.keys(pr.values).forEach(function (k) { vals[k] = pr.values[k]; });
    cond = C.conditions[pr.condition] ? pr.condition : Object.keys(C.conditions)[0];
    writeAll();
  }

  function setCondition(key, keepValues) {
    if (!C.all_conditions[key]) return;
    cond = key;
    if (!keepValues) { vals = S.applyCondition(vals, key); writeAll(); }
    touched();
    render(true);
  }

  function setUnits(next) {
    if (next === sys || !C.units[next]) return;
    sys = next;
    setRadio('ww-units', sys);
    writeAll();
    render(false);
  }

  function reset() {
    form.querySelectorAll('input[type="radio"][checked]').forEach(function (r) { r.checked = true; });
    form.querySelectorAll('select').forEach(function (sel) {
      var def = sel.querySelector('option[selected]') || sel.options[0];
      if (def) sel.value = def.value;
    });
    if (el.city) el.city.value = '';
    if (el.postal) el.postal.value = '';
    if (el.rule) el.rule.value = '';
    if (el.country) { el.country.value = IS_CA ? 'CA' : 'US'; fillRegions(country()); }
    sys = IS_CA ? 'metric' : 'us';
    setRadio('ww-units', sys);
    formError.textContent = '';
    prev = null;
    example = true;
    loadPreset(PG.start || Object.keys(C.presets)[0]);
    if (el.areaSel) syncArea();
    el.why.hidden = true;
    render(false);
  }

  function syncArea() {
    var a = caArea();
    if (!a) return;
    if (el.busrule && C.bus_rules[a.rule]) el.busrule.value = a.rule;
    if (el.region && a.prov) el.region.value = a.prov;
  }

  /* ---------------------------------------------------------------
     EVENTS
     --------------------------------------------------------------- */

  form.addEventListener('submit', function (e) { e.preventDefault(); });

  form.addEventListener('input', function (e) {
    var t = e.target, key = t.getAttribute('data-field');
    if (key) {
      touched();
      var ok = readBox(key);
      formError.textContent = ok ? '' : 'Fix the highlighted box — the result shows the last valid value.';
      render(true);
      return;
    }
    if (t === el.city || t === el.postal || t === el.rule) render(false);
  });

  form.addEventListener('change', function (e) {
    var t = e.target;
    if (t.name === 'ww-cond') { setCondition(t.value, false); return; }
    if (t.name === 'ww-units') { setUnits(t.value); return; }
    if (t.name === 'ww-timing') { vals.timing = t.value; touched(); render(true); return; }
    if (t.getAttribute('data-field')) return; // handled on input
    if (t === el.region || t === el.city || t === el.postal || t === el.rule) { render(false); return; }
    if (t.id && t.id.indexOf('ww-') === 0) {
      var key = t.id.slice(3);
      if (C.fields[key] && C.fields[key].type === 'select') { vals[key] = t.value; touched(); render(true); return; }
    }
    if (t === el.country) {
      fillRegions(country());
      setUnits(C.countries[country()].units);
      render(false);
      return;
    }
    if (t === el.areaSel) syncArea();
    render(true);
  });

  form.addEventListener('keydown', function (e) {
    var key = e.target.getAttribute && e.target.getAttribute('data-field');
    if (!key || (e.key !== 'ArrowUp' && e.key !== 'ArrowDown')) return;
    e.preventDefault();
    step(key, e.key === 'ArrowUp' ? 1 : -1);
  });

  form.addEventListener('click', function (e) {
    var b = e.target.closest ? e.target.closest('button') : null;
    if (!b) return;
    if (b.hasAttribute('data-step')) { step(b.getAttribute('data-for'), +b.getAttribute('data-step')); return; }
    if (b.hasAttribute('data-preset')) {
      loadPreset(b.getAttribute('data-preset'));
      example = false;
      render(true);
      return;
    }
    if (b === el.suggestBtn) { setCondition(b.getAttribute('data-to'), true); return; }
    if (b === el.reset) reset();
  });

  /* ---------------------------------------------------------------
     START — the page's starting preset, clearly marked as an example.
     --------------------------------------------------------------- */

  if (el.country) fillRegions(country());
  if (el.areaSel) syncArea();
  loadPreset(PG.start || Object.keys(C.presets)[0]);
  render(false);
})(window, document);
