/* Node harness for the winter weather family (v3, manual weather input).
 *
 *   node tests/snowday-lib.test.js
 *
 * The engine (assets/js/lib/snowday.js) is configured with the SAME JSON
 * each page embeds, exported by tests/export-winter-config.php, so these
 * tests run on the real settings in app/config/winter-weather.php.
 *
 * Covers: wind chill against published charts; ECCC risk bands; unit
 * conversions and unit-switch invariance; every preset's expected result
 * on every page; every worked example the articles quote; the eleven
 * weather conditions (model + visual state); rain never becoming ice on
 * its own; timing, class time, settings and bus rules; cold and ice page
 * focus; a NaN / Infinity sweep; the scene engine in a stub DOM (particle
 * caps, object reuse, one loop, pause when hidden / off screen, reduced
 * motion); and the promises: no network, no geolocation, no storage, no
 * innerHTML, no randomness in the model, no live-weather or accuracy
 * claims, no API keys.
 */

const fs = require('fs');
const path = require('path');
const cp = require('child_process');

const PROJECT = path.resolve(__dirname, '..');
const ROOT = path.join(PROJECT, 'public_html');
const PHP = path.join(PROJECT, 'php', 'php.exe');

function exportCfg(slug) {
  /* cwd = project root and relative ini paths: the folder name contains
     parentheses, which php -d cannot take. */
  const out = cp.execFileSync(fs.existsSync(PHP) ? PHP : 'php',
    ['-d', 'extension_dir=php/ext', '-d', 'extension=php_mbstring.dll', 'tests/export-winter-config.php', slug],
    { cwd: PROJECT, stdio: ['ignore', 'pipe', 'ignore'] }).toString();
  return JSON.parse(out);
}

const PAGES = ['snow-day-calculator', 'snow-day-calculator-canada', 'ice-day-calculator', 'college-snow-day-calculator', 'cold-day-calculator', 'wind-chill-calculator'];
const ESTIMATE_PAGES = PAGES.filter(p => p !== 'wind-chill-calculator');
const CFG = {};
PAGES.forEach(p => { CFG[p] = exportCfg(p); });

const window = { ECS: {} };
new Function('window', fs.readFileSync(path.join(ROOT, 'assets/js/lib/snowday.js'), 'utf8'))(window);
const S = window.ECS.snowday;

let pass = 0, fail = 0;
function is(label, actual, expected) {
  const a = JSON.stringify(actual), e = JSON.stringify(expected);
  if (a === e) { pass++; console.log('ok   ' + label + '  = ' + a); }
  else { fail++; console.log('FAIL ' + label + '\n     got  ' + a + '\n     want ' + e); }
}
function ok(label, cond, extra) {
  if (cond) { pass++; console.log('ok   ' + label); }
  else { fail++; console.log('FAIL ' + label + (extra !== undefined ? '   got ' + JSON.stringify(extra) : '')); }
}
const R = n => Math.round(n);

/* Default settings exactly as each page starts. */
function defaults(slug, extra) {
  const pg = CFG[slug].page;
  return Object.assign({
    ignore: pg.ignore, level: pg.level, tendency: 'typical',
    commuteSens: pg.settings.includes('commute_sens') ? 'typical' : null,
    area: 'suburban', school: 'public', campus: 'mixed', online: 'sometimes', classTime: 'morning',
    busRule: pg.settings.includes('bus_rule') ? 'separate' : 'delay'
  }, extra || {});
}
const BASE = { snow_cm: 0, snow_hours: 0, rain_mm: 0, ice_mm: 0, temp_c: -5, wind_kmh: 10, vis: 'good', timing: 'overnight', commute: 'clear', wait_min: 10 };
function run(slug, v, s) { S.configure(CFG[slug]); return S.calculate(Object.assign({}, BASE, v), defaults(slug, s)); }

/* ---------------- configuration gate ---------------- */
let threw = false;
try { S.calculate({ snow_cm: 5 }); } catch (e) { threw = true; }
ok('engine refuses to run before configure() (no hidden defaults)', threw);
S.configure(CFG['snow-day-calculator']);
const M = S.config().model;

/* ---------------- wind chill vs published charts ---------------- */
[[40, 5, 36], [30, 10, 21], [0, 20, -22], [-10, 15, -32], [-20, 20, -48], [-45, 60, -98], [5, 25, -17]]
  .forEach(([t, v, want]) => is(`NWS ${t}°F ${v}mph`, R(S.windChillF(t, v).value), want));
[[-15, 20, -24], [-20, 10, -27], [-10, 20, -18], [0, 5, -2], [-40, 50, -63]]
  .forEach(([t, v, want]) => is(`ECCC ${t}°C ${v}km/h`, R(S.windChillC(t, v).value), want));
is('above 50°F → air temp', S.windChillF(55, 20), { value: 55, applied: false });
is('3 mph → air temp', S.windChillF(10, 3), { value: 10, applied: false });
is('above 10°C → air temp', S.windChillC(12, 30), { value: 12, applied: false });
is('calm → air temp', S.windChillC(-10, 4), { value: -10, applied: false });
is('bad input → null', S.windChillC(NaN, 5), null);
is('old 0°F 20mph ≈ −39 (historical)', R(S.oldWindChillF(0, 20).value), -39);
is('old caps wind at 45 mph', S.oldWindChillF(0, 60).value, S.oldWindChillF(0, 45).value);
let agreeMax = 0;
for (let t = -40; t <= 10; t += 5) for (let v = 5; v <= 80; v += 5) {
  const c = S.windChillC(t, v).value, f = S.units.fToC(S.windChillF(S.units.cToF(t), S.units.kmhToMph(v)).value);
  agreeMax = Math.max(agreeMax, Math.abs(c - f));
}
ok('°C and °F formulas agree within 0.5 °C (max ' + agreeMax.toFixed(3) + ')', agreeMax < 0.5);
is('effective wind chill: typed value wins', S.effectiveWindChill({ temp_c: -10, wind_kmh: 30, wc_c: -30 }), { value: -30, source: 'entered', applied: true });
is('effective wind chill: formula', R(S.effectiveWindChill({ temp_c: -15, wind_kmh: 20 }).value), -24);
is('effective wind chill: nothing entered', S.effectiveWindChill({}).value, null);

/* ---------------- ECCC risk bands ---------------- */
is('risk 1 → none', S.ecccRisk(1).band, -1);
is('risk -10', S.ecccRisk(-10).risk, 'Moderate risk');
is('risk -28', S.ecccRisk(-28).risk, 'High risk');
is('risk -40', S.ecccRisk(-40).risk, 'Very high risk');
is('risk -60', S.ecccRisk(-60).risk, 'Extreme risk');

/* ---------------- units ---------------- */
is('32 °F = 0 °C', S.units.fToC(32), 0);
is('−40 °C = −40 °F', S.units.cToF(-40), -40);
is('100 °C = 212 °F', S.units.cToF(100), 212);
is('1 in = 2.54 cm', S.units.inToCm(1), 2.54);
is('0.25 in = 6.35 mm', S.units.inToMm(0.25), 6.35);
is('60 mph = 96.56 km/h', S.round(S.units.mphToKmh(60), 2), 96.56);
is('toDisplay temp us', S.toDisplay('temp', -10, 'us'), 14);
is('toDisplay hours unchanged', S.toDisplay('hours', 6, 'us'), 6);
let rt = 0;
['snow', 'rate', 'rain', 'ice', 'temp', 'wind'].forEach(k => [-30, 0, 2.5, 17, 80].forEach(v => {
  rt = Math.max(rt, Math.abs(S.fromDisplay(k, S.toDisplay(k, v, 'us'), 'us') - v));
}));
ok('unit round trip exact (max error ' + rt + ')', rt < 1e-9);
{
  /* Switching units never changes the result: the page keeps metric
     values and only converts what the boxes show. */
  const v = CFG['snow-day-calculator'].presets.heavy_snow.values;
  const a = run('snow-day-calculator', v, { condition: 'heavy_snow' });
  const typedUS = {};
  Object.keys(v).forEach(k => {
    const f = CFG['snow-day-calculator'].field_defs[k];
    typedUS[k] = f && f.unit && S.isNum(v[k]) ? S.fromDisplay(f.unit, S.toDisplay(f.unit, v[k], 'us'), 'us') : v[k];
  });
  const b = run('snow-day-calculator', typedUS, { condition: 'heavy_snow' });
  is('unit switch: same closure / delay / pressure', [b.closure, b.delay, b.pressure], [a.closure, a.delay, a.pressure]);
}

/* ---------------- presets: expected results on every page ---------------- */
ESTIMATE_PAGES.forEach(slug => {
  const C = CFG[slug];
  ok(slug + ': has presets', Object.keys(C.presets).length >= 3);
  ok(slug + ': start preset exists', !!C.presets[C.page.start]);
  Object.keys(C.presets).forEach(k => {
    const p = C.presets[k];
    ok(slug + ' preset ' + k + ': condition offered on this page', !!C.conditions[p.condition]);
    ok(slug + ' preset ' + k + ': has an expected result', typeof p.expect === 'number', p.expect);
    const r = run(slug, p.values, { condition: p.condition });
    is(slug + ' preset ' + k + ' closure', r.closure, p.expect);
    ok(slug + ' preset ' + k + ': chances sum to 100', r.closure + r.delay + r.open === 100);
  });
});

/* ---------------- worked examples quoted by the articles ---------------- */
const articles = fs.readFileSync(path.join(ROOT, 'app/config/winter-weather-articles.php'), 'utf8');
const flat = articles.replace(/\s+/g, ' ');
function quoted(label, sentence) { ok('article quotes: ' + label, flat.includes(sentence), sentence); }

const e1 = run('snow-day-calculator', { snow_cm: 10, snow_hours: 6, temp_c: -5, wind_kmh: 15, vis: 'reduced', timing: 'commute', commute: 'snowy' }, { condition: 'snow' });
is('main ex1', [e1.pressure, e1.closure, e1.delay, e1.open], [58, 61, 31, 8]);
quoted('main ex1', 'weather pressure 58, and for a typical suburban public school a 61% snow day chance, 31% delay and 8% normal day');
const e2 = run('snow-day-calculator', { snow_cm: 20, snow_hours: 10, temp_c: -6, wind_kmh: 10, commute: 'snowy' }, { condition: 'heavy_snow' });
const e2b = run('snow-day-calculator', { snow_cm: 20, snow_hours: 10, temp_c: -6, wind_kmh: 10, commute: 'snowy' }, { condition: 'heavy_snow', tendency: 'low' });
is('main ex2', [e2.pressure, e2.closure, e2b.closure], [70.3, 90, 68]);
quoted('main ex2', 'pressure 70.3 and a 90% snow day chance. Set “Rarely closes” and the same storm gives 68%');
const i1 = run('ice-day-calculator', { ice_mm: 4, temp_c: -1, wind_kmh: 15, commute: 'icy' }, { condition: 'freezing_rain' });
const i2 = run('ice-day-calculator', { ice_mm: 1, temp_c: -1, wind_kmh: 15, commute: 'wet' }, { condition: 'freezing_rain' });
is('ice ex', [i1.pressure, i1.closure, i1.delay, i2.closure, i2.delay], [52.6, 42, 42, 1, 6]);
quoted('ice ex1', 'weather pressure of 52.6, a 42% ice-day chance and a 42% chance of a delay or cancelled buses');
quoted('ice ex2', 'gives 1% and 6%');
quoted('main → ice', '4 mm of freezing rain overnight with icy roads gives a 42% ice-day chance');
const cv = { snow_cm: 15, snow_hours: 8, temp_c: -4, wind_kmh: 20, vis: 'reduced', timing: 'commute', commute: 'snowy' };
const k12 = run('snow-day-calculator', cv, { condition: 'heavy_snow' });
const cMix = run('college-snow-day-calculator', cv, { condition: 'heavy_snow' });
const cRes = run('college-snow-day-calculator', cv, { condition: 'heavy_snow', campus: 'residential', online: 'often' });
const cEve = run('college-snow-day-calculator', cv, { condition: 'heavy_snow', classTime: 'evening' });
is('college ex', [k12.pressure, k12.closure, cMix.closure, cRes.closure, cEve.closure], [68.5, 87, 55, 23, 21]);
quoted('college ex', 'weather pressure of 68.5 and an 87% snow day chance');
quoted('college ex', 'give a 55% campus-closure chance; for a mostly residential campus that often moves classes online, 23%; and for evening classes on a mixed campus, 21%');
const k1 = run('cold-day-calculator', { temp_c: -30, wind_kmh: 20, wait_min: 15 }, { condition: 'extreme_cold' });
const k2 = run('cold-day-calculator', { temp_c: -20, wind_kmh: 20, wait_min: 15 }, { condition: 'extreme_cold' });
is('cold ex', [R(k1.derived.wcC), k1.closure, k1.delay, R(k2.derived.wcC), k2.closure, k2.delay], [-43, 54, 36, -30, 1, 4]);
quoted('cold ex1', 'wind chill of −43 °C and gives a 54% cold-day chance and a 36% chance of a late start');
quoted('cold ex2', 'wind chill of −30 °C and gives 1% and 4%');
const ca = { snow_cm: 12, snow_hours: 6, temp_c: -5, wind_kmh: 30, gust_kmh: 55, vis: 'poor', timing: 'commute', commute: 'snowy' };
const ca1 = run('snow-day-calculator-canada', ca, { condition: 'snow_wind', busRule: 'separate' });
const ca2 = run('snow-day-calculator-canada', ca, { condition: 'snow_wind', busRule: 'closes' });
is('canada ex', [ca1.closure, ca1.delay, ca2.closure], [74, 21, 95]);
quoted('canada ex', 'gives a 74% closure estimate and 21% for buses cancelled with schools open; with Hamilton’s rule the closure estimate becomes 95%');

/* ---------------- determinism ---------------- */
{
  const v = { snow_cm: 7.3, snow_hours: 5, rain_mm: 2, ice_mm: 0.4, temp_c: -1.5, wind_kmh: 33, gust_kmh: 61, vis: 'poor', timing: 'early', commute: 'slushy' };
  const a = JSON.stringify(run('snow-day-calculator', v, { condition: 'sleet_mixed' }));
  let same = true;
  for (let i = 0; i < 50; i++) same = same && JSON.stringify(run('snow-day-calculator', v, { condition: 'sleet_mixed' })) === a;
  ok('same input → same result (50 runs)', same);
}
is('centre of the curve → 50%', S.calculate({ snow_cm: 0, temp_c: 5, commute: 'clear', timing: 'overnight' }, { condition: 'clear' }).closure, 1);

/* ---------------- the eleven conditions ---------------- */
S.configure(CFG['snow-day-calculator']);
const allConds = Object.keys(CFG['snow-day-calculator'].conditions);
is('all eleven conditions on the main page', allConds.length, 11);
allConds.forEach(k => {
  const C = CFG['snow-day-calculator'].conditions[k];
  const v = S.applyCondition(Object.assign({}, BASE, { temp_c: 10, wind_kmh: 5 }), k);
  if (C.temp) ok(k + ': temperature moved into its range', v.temp_c >= C.temp[0] && v.temp_c <= C.temp[1], v.temp_c);
  if (C.wind_min) ok(k + ': wind raised to its minimum', v.wind_kmh >= C.wind_min, v.wind_kmh);
  const vis = S.visual(v, k);
  const r = S.calculate(v, defaults('snow-day-calculator', { condition: k }));
  ok(k + ': result finite and sums to 100', [r.closure, r.delay, r.open, r.pressure].every(Number.isFinite) && r.closure + r.delay + r.open === 100);
  is(k + ': scene sky', vis.sky, C.sky);
  Object.keys(C.layers).forEach(layer => ok(k + ': layer ' + layer + ' visible', vis.layers[layer] > 0, vis.layers));
  ok(k + ': visual label and icon', vis.label === C.label && vis.icon === C.icon);
});
{
  const V = k => S.visual(S.applyCondition(Object.assign({}, BASE), k), k);
  ok('clear: calm scene, almost no particles', !V('clear').layers.snow && !V('clear').layers.rain && V('clear').layers.crystal <= 0.15);
  ok('rain: no snow layer (no contradictory visuals)', !V('rain').layers.snow && V('rain').layers.rain > 0);
  ok('snow: no rain layer', !V('snow').layers.rain);
  ok('sleet / mixed: snow and rain together', V('sleet_mixed').layers.snow > 0 && V('sleet_mixed').layers.rain > 0);
  ok('snow + ice: snow and ice crystals', V('snow_ice').layers.snow > 0 && V('snow_ice').layers.crystal > 0);
  ok('snow + wind: wind streaks', V('snow_wind').layers.streak > 0 && V('snow_wind').wind > 0.5);
  ok('freezing rain: frost edges', V('freezing_rain').frost >= 0.5);
  ok('rain + freezing: rain with frost', V('rain_freezing').layers.rain > 0 && V('rain_freezing').frost > 0);
  ok('extreme cold: mist and frost', V('extreme_cold').layers.mist > 0 && V('extreme_cold').frost > 0.5);
  ok('heavy snow: denser than snow, with haze', V('heavy_snow').layers.snow > V('snow').layers.snow && V('heavy_snow').haze > 0);
}
{
  const snowK = cm => S.visual(Object.assign({}, BASE, { snow_cm: cm, snow_hours: 0 }), 'snow').layers.snow;
  ok('snow intensity rises with snowfall (1 → 5 → 12 → 30 cm)', snowK(1) <= snowK(5) && snowK(5) < snowK(12) && snowK(12) < snowK(30), [snowK(1), snowK(5), snowK(12), snowK(30)]);
  const rainK = mm => S.visual(Object.assign({}, BASE, { rain_mm: mm, rain_int: 'light', temp_c: 5 }), 'rain').layers.rain;
  ok('rain intensity rises with rain', rainK(1) < rainK(10) && rainK(10) < rainK(40));
  const windK = w => S.visual(Object.assign({}, BASE, { snow_cm: 8, wind_kmh: w }), 'snow').wind;
  ok('wind reaction rises with wind (5 → 30 → 60 → 100 km/h)', windK(5) < windK(30) && windK(30) < windK(60) && windK(60) <= windK(100));
  ok('gusts add to the wind reaction', S.visual(Object.assign({}, BASE, { snow_cm: 8, wind_kmh: 30, gust_kmh: 90 }), 'snow').wind > windK(30));
  ok('strong wind adds streaks to snow', S.visual(Object.assign({}, BASE, { snow_cm: 8, wind_kmh: 70 }), 'snow').layers.streak > 0);
  ok('light wind: no streaks', !S.visual(Object.assign({}, BASE, { snow_cm: 8, wind_kmh: 5 }), 'snow').layers.streak);
  const coldK = t => S.visual(Object.assign({}, BASE, { temp_c: t, wind_kmh: 20 }), 'clear').cold;
  ok('temperature reaction: colder = stronger frost / mist', coldK(-5) < coldK(-20) && coldK(-20) < coldK(-35));
  ok('mild cold: no mist', !S.visual(Object.assign({}, BASE, { temp_c: -2, wind_kmh: 10 }), 'clear').layers.mist);
  ok('severe cold adds mist on any condition', S.visual(Object.assign({}, BASE, { snow_cm: 5, temp_c: -30, wind_kmh: 20 }), 'snow').layers.mist > 0);
  ok('visual unaffected by units (metric only)', JSON.stringify(S.visual(BASE, 'snow')) === JSON.stringify(S.visual(Object.assign({}, BASE), 'snow')));
}

/* ---------------- rain never becomes ice on its own ---------------- */
{
  const warm = run('snow-day-calculator', { rain_mm: 20, temp_c: 4 }, { condition: 'rain' });
  is('plain rain, +4 °C: no ice points', warm.groups.ice, 0);
  const coldRain = run('snow-day-calculator', { rain_mm: 20, temp_c: -2 }, { condition: 'rain' });
  ok('plain rain, −2 °C: only the capped refreeze allowance counts', coldRain.derived.freezingMm === M.refreeze.cap_mm && coldRain.derived.rainIceMm === 0, coldRain.derived);
  const fr = run('snow-day-calculator', { rain_mm: 5, temp_c: -1 }, { condition: 'rain_freezing' });
  is('rain + freezing temperature: all rain is ice', fr.derived.rainIceMm, 5);
  const sl = run('snow-day-calculator', { rain_mm: 6, temp_c: 0 }, { condition: 'sleet_mixed' });
  is('sleet / mixed: half the rain is ice', sl.derived.rainIceMm, 3);
  is('refreeze rule: below threshold rain', S.refreezeFrom(0.5, -5), 0);
  is('refreeze rule: not cold enough', S.refreezeFrom(5, 0), 0);
  is('refreeze rule: capped', S.refreezeFrom(40, -5), M.refreeze.cap_mm);
  const low = run('ice-day-calculator', { rain_mm: 8, temp_c: 1, refreeze_c: -6 }, { condition: 'rain' });
  ok('overnight low drives refreeze even with a mild commute', low.derived.refreezeMm === 2 && low.derived.refreezeLowC === -6);
}

/* ---------------- timing, class time, settings ---------------- */
{
  const at = t => run('snow-day-calculator', { snow_cm: 10, snow_hours: 5, timing: t }, { condition: 'snow' }).closure;
  ok('timing: commute > early > overnight > evening', at('commute') > at('early') && at('early') > at('overnight') && at('overnight') > at('evening'), [at('commute'), at('early'), at('overnight'), at('evening')]);
  ok('timing: school hours count half the snow', run('snow-day-calculator', { snow_cm: 10, timing: 'school' }, { condition: 'snow' }).derived.share === 0.5);
  const ct = c => run('college-snow-day-calculator', { snow_cm: 15, snow_hours: 8, timing: 'overnight' }, { condition: 'heavy_snow', classTime: c }).closure;
  ok('college: overnight snow matters less for evening classes', ct('morning') > ct('evening'), [ct('morning'), ct('evening')]);
  const dt = c => run('college-snow-day-calculator', { snow_cm: 15, snow_hours: 8, timing: 'school' }, { condition: 'heavy_snow', classTime: c }).closure;
  ok('college: daytime storm matters more for evening classes', dt('evening') > dt('morning'), [dt('evening'), dt('morning')]);
  const tend = t => run('snow-day-calculator', { snow_cm: 12, snow_hours: 6 }, { condition: 'snow', tendency: t }).closure;
  ok('sensitivity: closes easily > typical > rarely', tend('high') > tend('typical') && tend('typical') > tend('low'));
  const cs = t => run('snow-day-calculator', { snow_cm: 12, snow_hours: 6, commute: 'snowy' }, { condition: 'snow', commuteSens: t }).closure;
  ok('commute sensitivity moves the estimate', cs('high') > cs('typical') && cs('typical') > cs('low'));
  const area = a => run('snow-day-calculator', { snow_cm: 12, snow_hours: 6 }, { condition: 'snow', area: a }).closure;
  ok('area: rural > suburban > city', area('rural') > area('suburban') && area('suburban') > area('city'));
  ok('boarding school needs more weather', run('snow-day-calculator', { snow_cm: 12 }, { condition: 'snow', school: 'boarding' }).closure < run('snow-day-calculator', { snow_cm: 12 }, { condition: 'snow' }).closure);
  const hr = run('snow-day-calculator-canada', { snow_cm: 12, snow_hours: 6 }, { condition: 'snow', busRule: 'closes' });
  ok('bus rule "closes": closure = any disruption', hr.delay === 0 && hr.closure === hr.disrupt);
  const commuteAlone = run('snow-day-calculator', { commute: 'icy' }, { condition: 'clear' });
  ok('roads always count (icy roads without precipitation)', commuteAlone.groups.extras === 18);
  ok('wind alone never makes a snow day (only with snow or ice)', run('snow-day-calculator', { wind_kmh: 90, gust_kmh: 120 }, { condition: 'clear' }).groups.extras === 0);
  const capped = run('snow-day-calculator', { snow_cm: 20, snow_hours: 4, wind_kmh: 80, gust_kmh: 100, vis: 'verypoor', timing: 'commute', commute: 'whiteout' }, { condition: 'snow_wind' });
  ok('extras capped at ' + M.extras_cap, capped.groups.extras === M.extras_cap && capped.groups.capped);
  ok('closure capped at max_closure', capped.closure <= M.max_closure);
  const rateTyped = run('snow-day-calculator', { snow_cm: 10, snow_hours: 10, snow_rate: 3, timing: 'commute' }, { condition: 'snow' });
  ok('typed snowfall rate overrides amount ÷ duration', rateTyped.derived.rateCmH === 3 && rateTyped.derived.rateSource === 'entered');
  const rateDer = run('snow-day-calculator', { snow_cm: 10, snow_hours: 4, timing: 'commute' }, { condition: 'snow' });
  is('derived snowfall rate', [rateDer.derived.rateCmH, rateDer.derived.rateSource], [2.5, 'derived']);
  const warmSnow = run('snow-day-calculator', { snow_cm: 10, temp_c: 3 }, { condition: 'snow' });
  is('warm ground: +3 °C counts 60% of the snow', warmSnow.derived.melt, 0.6);
}

/* ---------------- page focus ---------------- */
{
  const iceSnow = run('ice-day-calculator', { snow_cm: 30, snow_hours: 5, timing: 'commute' }, { condition: 'snow_ice' });
  ok('ice page ignores snow', iceSnow.groups.snow === 0 && iceSnow.factors.find(f => f.key === 'snow').ignored);
  S.configure(CFG['ice-day-calculator']);
  const sum = S.iceSummary(run('ice-day-calculator', { rain_mm: 8, temp_c: -3, refreeze_c: -6 }, { condition: 'rain' }));
  is('ice summary: refreeze risk high at the cap', sum.refreezeRisk, 'high');
  is('ice summary: freezing condition', sum.freezing, true);
  const sum2 = S.iceSummary(run('ice-day-calculator', { rain_mm: 0.5, temp_c: -0.5, refreeze_c: -0.5 }, { condition: 'rain' }));
  is('ice summary: small rain near freezing = low risk', sum2.refreezeRisk, 'low');
  const coldSnow = run('cold-day-calculator', { snow_cm: 40, ice_mm: 10, temp_c: -5, wind_kmh: 10, commute: 'icy' }, { condition: 'extreme_cold' });
  ok('cold page ignores snow, ice and roads', coldSnow.groups.snow === 0 && coldSnow.groups.ice === 0 && coldSnow.groups.extras === 0);
  const ex = w => run('cold-day-calculator', { temp_c: -30, wind_kmh: 20, wait_min: w }, { condition: 'extreme_cold' }).closure;
  ok('cold page: more time outside, higher estimate', ex(30) > ex(5));
  ok('cold page: no exposure points in mild cold', run('cold-day-calculator', { temp_c: -5, wind_kmh: 10, wait_min: 60 }, { condition: 'clear' }).groups.extras === 0);
  ok('main page ignores the cold-page exposure factor', run('snow-day-calculator', { temp_c: -35, wind_kmh: 30, wait_min: 60 }, { condition: 'extreme_cold' }).factors.find(f => f.key === 'exposure').points === 0);
}

/* ---------------- detection (a suggestion only) ---------------- */
S.configure(CFG['snow-day-calculator']);
[
  [{ snow_cm: 5, ice_mm: 2 }, 'snow_ice'], [{ snow_cm: 5, rain_mm: 4 }, 'sleet_mixed'], [{ snow_cm: 6, wind_kmh: 50 }, 'snow_wind'],
  [{ snow_cm: 20 }, 'heavy_snow'], [{ snow_cm: 4 }, 'snow'], [{ ice_mm: 3 }, 'freezing_rain'], [{ rain_mm: 5, temp_c: -1 }, 'rain_freezing'],
  [{ rain_mm: 5, temp_c: 4 }, 'rain'], [{ temp_c: -30, wind_kmh: 30 }, 'extreme_cold'], [{ temp_c: -2 }, 'clear']
].forEach(([v, want]) => is('detect ' + JSON.stringify(v), S.detect(Object.assign({}, BASE, v)), want));

/* ---------------- NaN / Infinity sweep ---------------- */
{
  const vals = [null, '', 'abc', -5, 0, 0.3, 7, 55, 1e9, '−3', '2,5'];
  let bad = 0, n = 0;
  ESTIMATE_PAGES.forEach(slug => {
    S.configure(CFG[slug]);
    Object.keys(CFG[slug].conditions).forEach(cond => {
      vals.forEach(a => vals.forEach(b => {
        const v = { snow_cm: a, snow_hours: b, snow_rate: a, rain_mm: b, ice_mm: a, temp_c: b, refreeze_c: a, wind_kmh: a, gust_kmh: b, wc_c: a === 55 ? null : b, wait_min: a, vis: 'x', timing: 'y', commute: 'z', rain_int: 'q' };
        const r = S.calculate(v, defaults(slug, { condition: cond, tendency: 'nope', area: 'nope', school: 'nope', campus: 'nope', online: 'nope' }));
        const vis = S.visual(v, cond);
        const nums = [r.pressure, r.closure, r.delay, r.open].concat(r.factors.map(f => f.points), Object.values(vis.layers), [vis.wind, vis.haze, vis.frost, vis.cold]);
        n++;
        if (!nums.every(Number.isFinite) || r.closure + r.delay + r.open !== 100 || JSON.stringify(r).includes('NaN')) bad++;
      }));
    });
  });
  ok('no NaN / Infinity / broken sums across ' + n + ' odd inputs', bad === 0, bad);
}

/* ---------------- scene engine in a stub DOM ---------------- */
{
  const rafQ = [];
  let hidden = false, reduced = false, ioCb = null;
  const noop = () => {};
  const ctx = new Proxy({}, { get: (t, k) => (k in t ? t[k] : noop), set: (t, k, v) => { t[k] = v; return true; } });
  const canvasStub = () => ({ getContext: () => ({ createRadialGradient: () => ({ addColorStop: noop }), fillRect: noop }), width: 0, height: 0, style: {} });
  const docListeners = {};
  const win = {
    ECS: {},
    innerWidth: 1200, devicePixelRatio: 2,
    matchMedia: q => ({ matches: /reduce/.test(q) ? reduced : false, addEventListener: noop }),
    getComputedStyle: () => ({ getPropertyValue: () => '' }),
    requestAnimationFrame: fn => { rafQ.push(fn); return rafQ.length; },
    cancelAnimationFrame: noop, setTimeout: fn => { fn(); return 1; }, clearTimeout: noop,
    IntersectionObserver: function (cb) { ioCb = cb; this.observe = noop; },
    ResizeObserver: function () { this.observe = noop; },
    MutationObserver: function () { this.observe = noop; }
  };
  const doc = {
    get hidden() { return hidden; },
    documentElement: {},
    createElement: canvasStub,
    addEventListener: (ev, fn) => { docListeners[ev] = fn; }
  };
  new Function('window', 'document', 'navigator', fs.readFileSync(path.join(ROOT, 'assets/js/lib/winter-scene.js'), 'utf8'))(win, doc, { hardwareConcurrency: 8 });
  const panel = { getBoundingClientRect: () => ({ width: 900, height: 300 }), setAttribute: noop, style: { setProperty: noop } };
  const canvas = { getContext: () => ctx, width: 0, height: 0, style: {} };
  S.configure(CFG['snow-day-calculator']);
  const VIS = CFG['snow-day-calculator'].visuals;
  const scene = win.ECS.winterScene.create(panel, canvas, VIS);
  ok('scene: created', !!scene);
  is('scene: dpr capped', canvas.width, Math.round(900 * VIS.engine.max_dpr));
  scene.set(S.visual(Object.assign({}, BASE, { snow_cm: 25, wind_kmh: 60 }), 'snow_wind'));
  ok('scene: heavy snow running with one queued frame', scene.state().running && rafQ.length === 1, rafQ.length);
  let maxP = 0, loopsBefore = scene.state().loops;
  const conds = Object.keys(CFG['snow-day-calculator'].conditions);
  for (let i = 0; i < 300; i++) {
    const k = conds[i % conds.length];
    scene.set(S.visual(Object.assign({}, BASE, { snow_cm: i % 40, rain_mm: (i * 7) % 30, ice_mm: i % 9, temp_c: -(i % 45), wind_kmh: (i * 13) % 110, gust_kmh: (i * 17) % 140 }), k));
    maxP = Math.max(maxP, scene.state().particles);
  }
  ok('scene: particles never exceed the cap (' + maxP + ' ≤ ' + VIS.engine.max_particles + ')', maxP <= VIS.engine.max_particles);
  ok('scene: no duplicated loops across 300 changes', scene.state().loops === loopsBefore && rafQ.length === 1, [scene.state().loops, rafQ.length]);
  let t = 0;
  for (let i = 0; i < 200; i++) { const fn = rafQ.shift(); if (fn) { t += 34; fn(t); } }
  ok('scene: frames keep exactly one callback queued', rafQ.length === 1);
  const count = scene.state().particles;
  for (let i = 0; i < 200; i++) { const fn = rafQ.shift(); if (fn) { t += 34; fn(t); } }
  ok('scene: particle arrays do not grow while animating (object reuse)', scene.state().particles === count);
  hidden = true; docListeners.visibilitychange();
  ok('scene: pauses when the tab is hidden', !scene.state().running);
  hidden = false; docListeners.visibilitychange();
  ok('scene: resumes when shown', scene.state().running);
  ioCb([{ isIntersecting: false }]);
  ok('scene: pauses when scrolled off screen', !scene.state().running);
  ioCb([{ isIntersecting: true }]);
  scene.set(S.visual(Object.assign({}, BASE), 'clear'));
  scene.set(S.visual(Object.assign({}, BASE, { snow_cm: 0, wind_kmh: 0, temp_c: 5 }), 'clear'));
  ok('scene: clear is nearly empty', scene.state().particles <= Math.ceil(VIS.layers.crystal.count * 0.15) + 1, scene.state().particles);
  reduced = true;
  const q0 = rafQ.length;
  const scene2 = win.ECS.winterScene.create(panel, canvas, VIS);
  scene2.set(S.visual(Object.assign({}, BASE, { snow_cm: 25 }), 'heavy_snow'));
  ok('scene: reduced motion draws a still frame, no loop', !scene2.state().running && rafQ.length === q0 && scene2.state().particles > 0);
  reduced = false;
  win.innerWidth = 375;
  const scene3 = win.ECS.winterScene.create(panel, canvas, VIS);
  scene3.set(S.visual(Object.assign({}, BASE, { snow_cm: 25 }), 'heavy_snow'));
  scene.set(S.visual(Object.assign({}, BASE, { snow_cm: 25 }), 'heavy_snow'));
  ok('scene: mobile uses fewer particles', scene3.state().lite && scene3.state().particles < 0.6 * VIS.layers.snow.count, scene3.state().particles);
}

/* ---------------- configuration sanity ---------------- */
ESTIMATE_PAGES.forEach(slug => {
  const C = CFG[slug];
  Object.keys(C.fields).forEach(f => ok(slug + ': field ' + f + ' defined centrally', !!C.field_defs[f]));
  Object.keys(C.conditions).forEach(k => ok(slug + ': condition ' + k + ' has sky, icon, label, layers', !!(C.conditions[k].sky && C.conditions[k].icon && C.conditions[k].label && C.conditions[k].layers)));
});
{
  const E = CFG['snow-day-calculator'].visuals.engine;
  ok('visual engine: fps ≤ 60', E.fps > 0 && E.fps <= 60 && E.fps_mobile <= E.fps);
  ok('visual engine: mobile scale < 1', E.mobile_scale > 0 && E.mobile_scale < 1);
  ok('visual engine: hard particle cap set', E.max_particles > 0 && E.max_particles <= 300);
}

/* ---------------- promises: no network, no location, honest words ---------------- */
const files = ['assets/js/lib/snowday.js', 'assets/js/lib/winter-scene.js', 'assets/js/calculators/winter-calc.js', 'assets/js/calculators/wind-chill.js'];
files.forEach(f => {
  /* Code only: comments may say what the file does NOT do. */
  const js = fs.readFileSync(path.join(ROOT, f), 'utf8').replace(/\/\*[\s\S]*?\*\//g, '').replace(/(^|[^:'"])\/\/.*$/gm, '$1');
  ok(f + ': no network (fetch / XHR / beacon / socket / EventSource)', !/\bfetch\s*\(|XMLHttpRequest|sendBeacon|WebSocket|EventSource|importScripts/.test(js));
  ok(f + ': no geolocation', !/geolocation|getCurrentPosition|watchPosition/.test(js));
  ok(f + ': no innerHTML / insertAdjacentHTML', !/innerHTML|insertAdjacentHTML|outerHTML/.test(js));
  ok(f + ': no storage or cookies', !/localStorage|sessionStorage|indexedDB|document\.cookie/.test(js));
});
const engine = fs.readFileSync(path.join(ROOT, 'assets/js/lib/snowday.js'), 'utf8');
ok('engine: no random component', !/Math\.random/.test(engine));
ok('engine: no model numbers of its own (center / spread / tables come from config)', !/\bcenter\s*[:=]\s*\d|spread\s*[:=]\s*\d/.test(engine));
const cfgSrc = fs.readFileSync(path.join(ROOT, 'app/config/winter-weather.php'), 'utf8');
const ui = fs.readFileSync(path.join(ROOT, 'app/includes/winter-ui.php'), 'utf8');
const words = (cfgSrc + articles).replace(/\/\*[\s\S]*?\*\//g, ' ').replace(/\s+/g, ' ');
ok('no accuracy percentage claimed', !/\d+\s*%\s*(accurate|accuracy)/i.test(words) && !/(accuracy|accurate)[^.]{0,20}\d+\s*%/i.test(words));
ok('never "most accurate" / "100% accurate"', !/\b(the|our)\s+most accurate\b|100% accurate/i.test(words));
ok('no AI / machine-learning claim', !/\bAI\b|artificial intelligence|machine learning/i.test(words));
ok('no live-weather claim (only negations)', !/\blive (weather|forecast|data|alerts?|prediction)\b/i.test(words.replace(/(does not|do not|doesn’t|not)( fetch| use| read)? live (weather|forecast|data)/gi, '').replace(/Does it use (a )?live (weather|forecast)\?/g, '')), (words.match(/.{30}\blive (weather|forecast|data|alerts?|prediction)\b.{20}/i) || [])[0]);
ok('no "guaranteed" claim (only negations)', !/\bguarantee(d|s)?\b/i.test(words.replace(/(not|never) a guarantee( of)?|never guarantees/gi, '')));
ok('no "Use my location" anywhere', !/use my location/i.test(words + ui));
ok('no weather API in config (open-meteo / NWS API / ECCC API / keys)', !/open-meteo|api\.weather\.gov|api\.weather\.gc\.ca|getenv\(|_KEY|apikey/i.test(cfgSrc));
ok('disclaimer: manual weather estimate', /'badge'\s*=>\s*'Manual weather estimate'/.test(cfgSrc));
ok('disclaimer: does not fetch live weather', /It does not fetch live weather or school closure announcements\./.test(cfgSrc));
ok('disclaimer: not a guarantee', /It is not a guarantee of a school closure\./.test(cfgSrc));
ok('renderer prints the no-fetch and estimate sentences', /disclaimers'\]\['no_fetch'\]/.test(ui) && /\['estimate'\]/.test(ui));
ok('renderer sends no Permissions-Policy override', !/Permissions-Policy/.test(ui));
const dump = JSON.stringify(CFG);
ok('browser config carries no API endpoint or key', !/open-meteo|api\.weather|apikey|\/api\//i.test(dump));
ok('removed: weather.php, winter-live.js, snow-day.js, cold-day.js', ['app/includes/weather.php', 'assets/js/lib/winter-live.js', 'assets/js/calculators/snow-day.js', 'assets/js/calculators/cold-day.js'].every(f => !fs.existsSync(path.join(ROOT, f))));
ok('index.php has no /api/snow-day/ route', !/snow-day'|weather_api_respond/.test(fs.readFileSync(path.join(ROOT, 'index.php'), 'utf8')));

console.log('\n' + pass + ' passed, ' + fail + ' failed');
process.exit(fail ? 1 : 0);
