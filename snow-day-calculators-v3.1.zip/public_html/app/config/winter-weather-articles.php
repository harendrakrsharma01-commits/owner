<?php
/**
 * EasyCalculatorSmart — Winter weather family: article sections (v3).
 *
 * The long-form content under each weather calculator, one list of
 * sections per page, in order. Loaded only on those pages (see
 * winter_articles() in app/includes/winter-ui.php).
 *
 * Each section: id (the anchor, also used by the Quick links card),
 * h2 (the heading) and html (trusted markup written for this site).
 *
 * PLACEHOLDERS — filled from winter-weather.php when the page renders, so
 * no weight, threshold or area is typed twice:
 *   {tool:slug}         URL of a calculator
 *   {model_table}       the heuristic points table
 *   {conditions_table}  the eleven weather conditions and what they fill in
 *   {ice_table}         ice points by freezing precipitation
 *   {cold_points}       the wind chill → points sentence
 *   {risk_table}        Environment Canada wind chill risk table
 *   {ca_areas}          one sub-section per Canadian area profile
 *   {state_notes}       one sub-section per US state note
 *   {m:key}             a model number (center, spread, delay_gap, extras_cap)
 *   {cfg:path}, {abs:path}, {pct:path}  any config number, its absolute
 *                       value, or a share as a percentage
 *   {college:level_shift}, {college:delay_gap}
 *   {refreeze}          the rain-then-freeze rule in words
 *   {melt}              the warm-ground rule in words
 *
 * Worked examples quote numbers the engine produces; tests/snowday-lib.test.js
 * recomputes each one, so a weight change that makes a sentence wrong
 * fails the tests instead of going live.
 */

declare(strict_types=1);

return [

    /* ================================================================
     * SNOW DAY CALCULATOR
     * ============================================================= */
    'snow-day-calculator' => [
        ['id' => 'guide-heading', 'h2' => 'What is a snow day calculator?', 'html' => <<<'HTML'
<p>
  A snow day calculator estimates how likely it is that school will close
  because of winter weather. It weighs the things a superintendent weighs
  before dawn — how much snow falls, whether it is still coming down at bus
  time, ice on the roads, how cold it is at the bus stop — and turns them
  into a percentage.
</p>
<p>
  People call the same tool a snow day predictor, a school snow day
  calculator or a snow day probability calculator. This one is a
  <strong>manual weather calculator</strong>: you enter the conditions from
  your local forecast, and it calculates from exactly those figures. It
  does not fetch live weather or school closure announcements, and it
  never asks where you are. That makes it transparent — you can see every
  number it used — and it makes “what if the storm is two inches bigger?”
  one tap away.
</p>
HTML],
        ['id' => 'how-to-use', 'h2' => 'How to use it', 'html' => <<<'HTML'
<ol>
  <li><strong>Pick the weather condition</strong> in your forecast — snow, heavy snow, freezing rain, sleet or mixed, extreme cold and so on. It fills typical figures and sets the scene; every figure stays editable.</li>
  <li><strong>Enter your forecast.</strong> Snowfall amount and how long it snows (or the rate), any rain or freezing rain, the temperature at bus time, the wind and gusts, and visibility. Leave the wind chill blank and it is worked out for you.</li>
  <li><strong>Place the storm on the timeline</strong> — evening, overnight, early morning, the school commute or school hours — and describe the roads you expect.</li>
  <li><strong>Describe your school</strong>: how easily it closes, city or rural roads, how sensitive the commute is.</li>
</ol>
<p>
  The result updates as you type. It is a live <em>calculation</em>, not
  live weather: the page recalculates from your figures, it does not look
  anything up. The presets load complete example scenarios if you want to
  see how the model behaves.
</p>
HTML],
        ['id' => 'reading', 'h2' => 'Reading the result', 'html' => <<<'HTML'
<p>
  You get three chances that add up to 100%: <strong>snow day</strong>,
  <strong>delay or early dismissal</strong>, and <strong>normal school
  day</strong>. Above them, the dashboard repeats the conditions you entered,
  so a screenshot always shows what the estimate was based on.
</p>
<p>
  <strong>Factor breakdown</strong> shows each factor’s points as a bar and
  the total weather pressure on a 0–100 scale, with the points where a
  delay and a closure become more likely than not. <strong>Why did my
  result change?</strong> lists every factor that moved when you changed a
  value — for example “Snowfall (12 cm effective): +22 points” — and a
  dashed outline shows where each bar was before. <strong>Show your
  work</strong> gives the whole calculation, step by step.
</p>
<p>
  The panel at the top follows your figures: falling snow for snow, heavier
  and faster for more of it, rain streaks for rain, ice crystals and frosted
  edges for freezing rain, cold mist for a bitter wind chill, and flakes that
  drift sideways as you raise the wind. It is a picture of the conditions you
  entered, not a forecast. With “reduce motion” turned on in your device
  settings it stays still.
</p>
HTML],
        ['id' => 'calculator-vs-predictor', 'h2' => 'Snow day calculator vs snow day predictor', 'html' => <<<'HTML'
<p>
  People search for a <em>snow day calculator</em>, a <em>snow day
  predictor</em> or a <em>snow day prediction calculator</em>, and they
  usually mean the same thing: “given this forecast, how likely is a snow
  day?” Some websites look up a forecast for your ZIP code; this one does
  not. It is a <strong>manual prediction tool</strong>: you enter the
  forecast you already have — from the National Weather Service, a local
  station or an app — and it shows how those conditions could play out as a
  closure, a late start, an early dismissal or a normal day. Because nothing
  is fetched, it works the same in any winter and lets you test “what if”
  forecasts that no live tool can.
</p>
HTML],
        ['id' => 'delay-vs-closure', 'h2' => 'Delay vs closure, early dismissal and late start', 'html' => <<<'HTML'
<p>
  The model gives two curves from the same weather pressure: one for a full
  closure and one, set {m:delay_gap} points lower, for <em>any</em>
  disruption. The space between them is the in-between outcome — a late
  start or an early dismissal. The <strong>Delay vs closure</strong> tool
  splits that space by storm timing:
</p>
<ul>
  <li><strong>Late start (delay):</strong> the storm is over, or ending,
    before school. Roads need a few more hours of plowing and daylight.
    Overnight and pre-dawn storms put almost all of the in-between chance
    here.</li>
  <li><strong>Early dismissal:</strong> snow or ice arrives during school
    hours, so the risk is the trip home. Storms during school hours put most
    of the in-between chance here.</li>
  <li><strong>Closure:</strong> heavy snow or ice is still falling at bus
    time, or the totals are simply too large to clear.</li>
</ul>
<p>
  The four numbers are an <strong>estimated scenario probability</strong>:
  a documented heuristic from your inputs, not a measured historical rate.
</p>
HTML],
        ['id' => 'storm-timing', 'h2' => 'Storm timing and snowfall timing', 'html' => <<<'HTML'
<p>
  The same 6 inches mean very different mornings. Snow that ends at 10 p.m.
  can be plowed before buses run; snow that peaks at 6 a.m. lands on the
  commute. The <strong>Storm &amp; snowfall timing</strong> tool takes
  either clock times (storm start, peak, end and the school start time) or
  up to {cfg:scenarios.timeline.max_blocks} time blocks, each with its own
  snow, ice and temperature. It places them on a timeline — evening,
  overnight, pre-dawn, morning commute, school hours, afternoon dismissal and
  evening return — and tells you, for example, that “peak snowfall overlaps
  the morning commute”. The window holding the peak sets the storm timing
  the estimate uses; press “Use this timing in the calculator” to apply it.
</p>
HTML],
        ['id' => 'road-conditions', 'h2' => 'Road conditions, treatment and visibility', 'html' => <<<'HTML'
<p>
  Roads are scored from your description — dry, wet, slush, snow-covered,
  icy or near-whiteout. The <strong>Roads &amp; treatment</strong> tool adds
  what crews have done: untreated, partially treated, recently treated or
  plowed and salted. Treatment lowers the road pressure, but less in deep
  cold (salt works poorly well below freezing) and less as it ages. It never
  lowers it below zero. Visibility counts separately: blowing snow and fog
  matter most when they coincide with the bus routes.
</p>
HTML],
        ['id' => 'school-bus-risk', 'h2' => 'School bus route risk', 'html' => <<<'HTML'
<p>
  Districts often close because buses cannot run safely, even when cars
  manage. The <strong>School bus risk</strong> tool scores how exposed your
  routes are: how many students ride, city, suburban, rural or hilly roads,
  the longest route and the longest ride, plus a share of the snow, ice,
  visibility and road pressure. Tick the box to let routes add a small,
  capped number of points to the estimate. It is informational — not a
  transportation safety assessment.
</p>
HTML],
        ['id' => 'morning-commute', 'h2' => 'Morning commute risk', 'html' => <<<'HTML'
<p>
  The <strong>Commute risk</strong> tool looks at one trip — a parent’s
  drive, a teacher’s commute or a student driver — from its distance, usual
  travel time and route type, on top of the weather and the storm timing. It
  flags a timing conflict when the storm overlaps the morning travel window.
  It does not change the school estimate and is not a road-safety rating.
</p>
HTML],
        ['id' => 'district-policy', 'h2' => 'District policy, regional thresholds and snow days used', 'html' => <<<'HTML'
<p>
  There is no national rule for how much snow closes schools. Instead of a
  database of districts that would go out of date, the
  <strong>Policy, region &amp; days used</strong> tool offers generic
  profiles that move the closure curve:
</p>
<ul>
  <li><strong>District policy:</strong> lower, typical or higher closure
    threshold, or your own custom adjustment.</li>
  <li><strong>Regional weather tolerance:</strong> lower, typical or higher
    snow tolerance — places where snow is rare close for less.</li>
  <li><strong>Snow days used this school year:</strong> optional and off by
    default. Some districts grow reluctant once their built-in days are
    used; if you pick the heuristic, the effect is small.</li>
</ul>
<p>
  All three are scenario assumptions, not any district’s official policy or
  snow-day budget. Your district’s announcement is always the answer.
</p>
HTML],
        ['id' => 'plowing', 'h2' => 'Plowing scenario', 'html' => <<<'HTML'
<p>
  How long would it take to clear the roads that matter? The
  <strong>Plowing scenario</strong> uses plain arithmetic: passes needed for
  the snow depth (one pass per {cfg:scenarios.plow.depth_per_pass} cm),
  a working speed that drops in deeper snow, the road length and the number
  of plows, plus a treatment delay. It reports the clearing time, when it
  would finish and how much would still be uncleared when the morning
  commute starts. It is theoretical — real crews prioritise main roads,
  refuel and work around traffic — and is not a municipal estimate.
</p>
HTML],
        ['id' => 'what-if', 'h2' => 'What-if comparisons', 'html' => <<<'HTML'
<p>
  Forecasts change. The <strong>What-if comparison</strong> keeps your
  forecast as scenario A and lets you set up B (and C) — for example 4 inches
  overnight at 28 °F against 8 inches during the morning commute at 22 °F.
  It shows the closure, delay, early-dismissal and normal chances side by
  side, the weather pressure, the storm timing and the factor that changed
  the most. Combined with “Why did my result change?”, which lists every
  input that moved and by how many points, it shows exactly what drives the
  estimate.
</p>
HTML],
        ['id' => 'model', 'h2' => 'The model, in the open', 'html' => <<<'HTML'
<p>
  There is no public dataset that pairs forecasts with the closure
  decisions of thousands of districts, so no one can honestly fit a
  “scientific” snow day formula to it. The weights below are
  <strong>heuristic</strong>: reasoned assumptions, written down so you can
  see them, and the ones that matter most are yours to set.
</p>
{model_table}
<p>
  The factors combine like independent risks: pressure = 100 × (1 − (1 −
  snow/100)(1 − ice/100)(1 − cold/100)(1 − extras/100)). Two moderate
  factors therefore add up to more than either alone, but never past 100.
</p>
<p>
  The snow day chance is an S-curve centred on a pressure of {m:center}: at
  {m:center} it is 50%, and the curve’s scale is {m:spread} points. “Rarely
  closes” moves the centre up by {abs:tendency.low.shift}, “closes easily”
  down by {abs:tendency.high.shift}; rural bus routes move it down by
  {abs:area_types.rural.shift} and city schools up by
  {abs:area_types.city.shift}; a sensitive commute moves it down by
  {abs:commute_sensitivity.high.shift}; a boarding school moves it up by
  {abs:school_types.boarding.shift}. The chance of <em>any</em> disruption
  (closure or delay) uses a centre {m:delay_gap} lower. The snow day chance
  is capped at {cfg:model.max_closure}%, because conditions can never make a
  closure certain. There is no random part: the same figures and settings
  always give the same answer.
</p>
HTML],
        ['id' => 'examples', 'h2' => 'Worked examples', 'html' => <<<'HTML'
<ul>
  <li><strong>Snow at bus time.</strong> 10 cm (about 4 in) over 6 hours, still falling during the morning commute, −5 °C, 15 km/h wind, reduced visibility, snow-covered roads: weather pressure 58, and for a typical suburban public school a 61% snow day chance, 31% delay and 8% normal day.</li>
  <li><strong>A big overnight storm.</strong> 20 cm (about 8 in) overnight at −6 °C with snow-covered roads: pressure 70.3 and a 90% snow day chance. Set “Rarely closes” and the same storm gives 68%.</li>
  <li><strong>Freezing rain.</strong> See the <a href="{tool:ice-day-calculator}">ice day calculator</a>: 4 mm of freezing rain overnight with icy roads gives a 42% ice-day chance on its own.</li>
</ul>
HTML],
        ['id' => 'how-much-snow', 'h2' => 'How much snow for a snow day?', 'html' => <<<'HTML'
<p>
  It depends far more on where you live than on any number. Districts in
  places that rarely see snow have fewer plows and less practice, and may
  close for an inch or two. Districts in the snow belt clear roads overnight
  and often open with several inches on the ground. That is why the
  calculator asks how easily <em>your</em> school closes instead of
  pretending one threshold fits everyone.
</p>
<p>
  Timing matters as much as amount. Snow that stops at midnight gives
  crews hours to clear roads; the same snow falling at 6 a.m. lands on the
  morning commute. Snow during school hours counts at
  {pct:timing.school.share}% because it leads to early dismissals rather
  than morning closures, and {melt}
</p>
<p>
  The visual intensity of the animation (light below about 2 cm, moderate to
  10 cm, heavy beyond) is only for the picture — it is not a closure rule.
</p>
HTML],
        ['id' => 'ice', 'h2' => 'Ice, freezing rain and rain', 'html' => <<<'HTML'
<p>
  Freezing rain coats roads, sidewalks and bus steps in a glaze that salt and
  plows handle poorly, so a small amount can close schools that would stay
  open in several inches of snow. Enter it as <strong>freezing rain / ice
  accretion</strong> and it is scored as its own factor.
</p>
<p>
  Ordinary rain is never turned into ice automatically. It counts as ice
  only when you choose a freezing condition — “Freezing rain”, “Ice”, “Snow +
  ice”, “Rain + freezing temperature” (all of it), or “Sleet / mixed” (half of
  it) — or when {refreeze}. If you enter rain with a temperature at or below
  0 °C under plain “Rain”, the page points out that you may want a freezing
  condition, and leaves the choice to you.
</p>
{conditions_table}
HTML],
        ['id' => 'cold', 'h2' => 'Cold, wind and wind chill', 'html' => <<<'HTML'
<p>
  Some closures have no snow at all. When the wind chill is low enough,
  frostbite becomes a risk for children waiting at bus stops.
  {cold_points} The wind chill uses the formula the National Weather
  Service and Environment Canada share; type your own figure instead if your
  forecast gives one. For a closer look — your district’s own cold rule and
  time at the bus stop — use the <a href="{tool:cold-day-calculator}">cold
  day calculator</a>. To work out wind chill on its own, use the
  <a href="{tool:wind-chill-calculator}">wind chill calculator</a>.
</p>
<p>
  Wind also matters on its own when snow or ice is falling: sustained wind
  and gusts mean blowing and drifting snow and poor visibility. They count
  inside the “extras”, which are capped at {m:extras_cap} points so that
  wind can make a storm worse but cannot create a snow day by itself.
</p>
HTML],
        ['id' => 'today-tomorrow', 'h2' => 'Today, tomorrow or any day', 'html' => <<<'HTML'
<p>
  Because you enter the forecast, the calculator works for any day you have
  a forecast for — this morning, tomorrow, Friday or Monday. For
  tomorrow, take the snow expected from the evening before until the end of
  the school day, and the temperature and wind for bus time. For this
  morning, set the storm timing to the commute if it is still snowing, and
  describe the roads as they are.
</p>
<p>
  Forecasts change, especially snowfall totals in the last 24 hours. Check
  your local forecast again the evening before and early in the morning,
  and enter the new figures.
</p>
HTML],
        ['id' => 'settings', 'h2' => 'School type, area and sensitivity', 'html' => <<<'HTML'
<ul>
  <li><strong>How easily does your school close?</strong> — the biggest lever. A district that closes for an inch and one that opens through six are both normal somewhere.</li>
  <li><strong>Area</strong> — long rural bus routes on untreated back roads close sooner than city schools where most students walk.</li>
  <li><strong>Commute sensitivity</strong> — hills, back roads and long routes make bad roads matter more.</li>
  <li><strong>School type</strong> — a private day school often follows the local district but may stay open more often; a boarding school’s students already live on campus.</li>
</ul>
<p>
  These are your judgement about your area, not an official policy.
  Elementary, middle and high schools are not separate settings: a district
  almost always closes all of its schools together, because the buses are
  shared.
</p>
HTML],
        ['id' => 'school-college', 'h2' => 'School vs college', 'html' => <<<'HTML'
<p>
  Colleges and universities decide differently. Their students are adults,
  many live on campus, and classes can move online. The
  <a href="{tool:college-snow-day-calculator}">college snow day calculator</a>
  needs noticeably more weather pressure before it gives a high closure
  chance, lets you describe your campus, and re-weights the storm timing for
  morning, afternoon or evening classes.
</p>
HTML],
        ['id' => 'who-decides', 'h2' => 'Who decides if school is closed?', 'html' => <<<'HTML'
<p>
  In the US it is the school district — usually the superintendent, often
  after staff have driven bus routes before dawn and talked with road crews
  and neighbouring districts. The National Weather Service provides
  forecasts and warnings but does not close schools.
</p>
<p>
  This page has no connection to any closure announcement, so it never says
  a school is closed. The calculator provides an estimate based on the
  conditions you enter; it is not a guarantee of a school closure. Most
  districts announce by early morning through their website, app, text
  alerts, social media and local TV and radio.
</p>
HTML],
        ['id' => 'states', 'h2' => 'Snow days by state', 'html' => <<<'HTML'
<p>
  The weather model is the same everywhere, but some states change what a
  closure means. Choose your state under “Location context” and the result
  shows the note too. The state is context only — it does not fetch
  anything.
</p>
{state_notes}
HTML],
        ['id' => 'us-canada', 'h2' => 'US and Canada', 'html' => <<<'HTML'
<p>
  Choosing a country sets the units — °F, inches and mph for the United
  States; °C, centimetres and km/h for Canada — and the wording about who
  decides. Switching units converts the boxes; the result stays the same.
  Canada has its own page: the
  <a href="{tool:snow-day-calculator-canada}">snow day calculator for Canada</a>
  treats bus cancellations as a separate outcome, because in much of
  Ontario buses are cancelled while schools stay open, and it has the rules
  for Toronto, Ottawa, Barrie, Hamilton, Waterloo, Sudbury, Halifax, PEI and
  more.
</p>
HTML],
        ['id' => 'accuracy', 'h2' => 'How accurate is a snow day calculator?', 'html' => <<<'HTML'
<p>
  Honestly: nobody knows a single number, and you should be wary of any site
  that quotes one without saying how it was measured. To claim an accuracy
  figure you would need a record of estimates made before each storm, the
  real decisions of the districts involved, and a count of hits and misses.
  That study has not been done for this model, so this page does not claim
  an accuracy percentage. It is a transparent estimate.
</p>
<ul>
  <li><strong>The forecast you enter can change.</strong> Totals often shift in the last 24 hours, and a storm arriving two hours early or late changes everything.</li>
  <li><strong>Borderline storms are hard.</strong> Two inches with temperatures near freezing can go either way; twelve inches rarely can.</li>
  <li><strong>Districts differ.</strong> The settings let you describe yours, but they are your judgement.</li>
  <li><strong>Things the weather cannot show:</strong> a district that has used up its snow days, a road-crew shortage, a power cut, or a decision made the night before.</li>
</ul>
HTML],
        ['id' => 'rituals', 'h2' => 'Snow day rituals and superstitions', 'html' => <<<'HTML'
<p>
  Every winter, students across the US and Canada try to “summon” a snow
  day. None of these rituals can change the weather — they are folklore,
  handed down by word of mouth, with no known single origin. They are also
  a fun family tradition on a stormy evening:
</p>
<ul>
  <li><strong>Pajamas inside out</strong> (and sometimes backwards) — the best-known one.</li>
  <li><strong>A spoon under the pillow</strong> — or on the windowsill, or in the freezer first.</li>
  <li><strong>Flushing ice cubes</strong> down the toilet, one for each inch of snow wanted.</li>
  <li><strong>A white crayon in the freezer</strong>, then under the pillow.</li>
  <li><strong>A snow dance</strong> before bed, often around the kitchen table.</li>
</ul>
<p>
  Two sensible rules: do not put anything down the toilet except a few ice
  cubes, and do not skip the homework because of a ritual.
</p>
HTML],
        ['id' => 'limitations', 'h2' => 'Limitations', 'html' => <<<'HTML'
<p>
  The estimate is only as good as the figures you enter, and the model is a
  set of heuristic assumptions, not a statistical fit to closure records. It
  does not know your district’s history, remaining snow days, staffing or
  road treatment, and it cannot see ice on the ground — only the amounts you
  type. Storm timing places the storm on a simple timeline; it is not an
  hourly forecast.
</p>
HTML],
    ],

    /* ================================================================
     * CANADA
     * ============================================================= */
    'snow-day-calculator-canada' => [
        ['id' => 'guide-heading', 'h2' => 'A snow day calculator built for Canada', 'html' => <<<'HTML'
<p>
  Most snow day calculators are written for American districts, where the
  usual answer to a storm is a two-hour delay. Canadian mornings work
  differently. In Ontario, busing is usually run by a transportation
  consortium shared by the public and Catholic boards, and the most common
  snowy-day announcement is not “schools closed” but “buses cancelled” —
  often for one zone, while schools stay open for anyone who can get there.
</p>
<p>
  So this version gives three outcomes: <strong>school closure</strong>,
  <strong>buses cancelled with schools open</strong>, and a <strong>normal
  day</strong>. It works in centimetres, millimetres, °C and km/h. You enter
  the forecast from Environment Canada or your local forecast; the page does
  not fetch live weather, alerts or closure announcements.
</p>
HTML],
        ['id' => 'closure-vs-bus', 'h2' => 'School closure vs bus cancellation', 'html' => <<<'HTML'
<p>
  A bus cancellation is a transportation decision: drivers and consortium
  staff check rural roads before dawn and cancel routes that are unsafe. A
  closure is a board decision to close school buildings. The two are
  announced separately in most of Ontario, often by different
  organisations. The well-known exception among the cities people search for
  is Hamilton, where HWDSB’s published rule is that a weather bus
  cancellation closes its schools and offices too — choose Hamilton and the
  calculator counts the bus-cancellation chance as a closure. PEI works
  differently again: when the Public Schools Branch cannot decide by
  6:30 a.m. it announces a one-hour delay.
</p>
<p>
  Example: 12 cm of snow in 6 hours, still falling at bus time, −5 °C,
  30 km/h wind gusting to 55 km/h, poor visibility and snow-covered roads.
  Where buses are cancelled separately that gives a 74% closure estimate
  and 21% for buses cancelled with schools open; with Hamilton’s rule the
  closure estimate becomes 95%.
</p>
<p>
  On a bus-cancellation day the schools are usually open, so a student who
  stays home is normally marked absent — check your board’s rules. The
  <a href="{tool:attendance-percentage-calculator}">attendance calculator</a>
  shows how missed days change an attendance percentage.
</p>
HTML],
        ['id' => 'areas', 'h2' => 'Snow days by area', 'html' => <<<'HTML'
<p>
  The area selector does not change the weather model. It sets the bus rule,
  the name of the middle outcome and who announces what. It is not a feed of
  today’s cancellations, so always check the links it gives.
</p>
{ca_areas}
HTML],
        ['id' => 'weather-canada', 'h2' => 'What drives a Canadian snow day', 'html' => <<<'HTML'
<ul>
  <li><strong>Snow before and during the bus runs</strong> — place the storm on the timeline; snow still falling at bus time counts most.</li>
  <li><strong>Freezing rain and drizzle</strong> — a thin glaze on rural roads is a classic reason for bus cancellations. The <a href="{tool:ice-day-calculator}">ice day calculator</a> looks at ice on its own.</li>
  <li><strong>Blowing snow and squalls</strong> — wind, gusts and low visibility count when snow or ice is falling.</li>
  <li><strong>Extreme cold</strong> — Environment Canada rates a wind chill of −28 and colder as high risk, when exposed skin can freeze in 10 to 30 minutes. Some consortia cancel buses for extreme cold even without snow; the <a href="{tool:cold-day-calculator}">cold day calculator</a> looks at this on its own.</li>
</ul>
HTML],
        ['id' => 'how-it-works', 'h2' => 'How the estimate is made', 'html' => <<<'HTML'
<p>
  Each factor you enter becomes points; the points combine into a weather
  pressure out of 100; an S-curve turns pressure into chances. Every weight is
  a heuristic assumption — not fitted to board records — and the full table
  is on the <a href="{tool:snow-day-calculator}#model">main snow day
  calculator</a>. The working for your own result is under “Show your work”.
  The postal code and city boxes are context for you only; nothing is looked
  up.
</p>
HTML],
        ['id' => 'accuracy', 'h2' => 'How accurate is it?', 'html' => <<<'HTML'
<p>
  There is no validated accuracy figure for this model, so the page does
  not claim one. Borderline storms near 0 °C are the hardest, and consortia
  decide zone by zone on what drivers find on the roads at 5 a.m. Use your
  board’s and consortium’s announcements for the real answer.
</p>
HTML],
    ],

    /* ================================================================
     * ICE DAY
     * ============================================================= */
    'ice-day-calculator' => [
        ['id' => 'guide-heading', 'h2' => 'What is an ice day?', 'html' => <<<'HTML'
<p>
  An ice day is a school closure, delay or bus cancellation caused by ice
  rather than snow. The roads may carry no snow at all; the danger is a
  glaze on pavement, sidewalks and bus steps that salt and plows handle
  poorly. Ice days are common along the freezing line — the US South and
  Mid-Atlantic, the Ohio Valley, and in Canada across southern Ontario,
  Quebec and the Maritimes.
</p>
<p>
  Enter the freezing rain, any plain rain, the morning temperature and the
  overnight low from your forecast. The calculator shows the <strong>ice
  pressure</strong>, whether conditions are <strong>freezing</strong>, a
  <strong>refreeze risk estimate</strong> and the ice-day chance. Snow is
  deliberately left out, so you can see what the ice alone does. It does not
  fetch live weather or closure announcements.
</p>
HTML],
        ['id' => 'types', 'h2' => 'Kinds of winter ice', 'html' => <<<'HTML'
<ul>
  <li><strong>Freezing rain</strong> — rain that freezes on contact with surfaces at or below 0 °C. The most dangerous kind: it builds a clear glaze.</li>
  <li><strong>Freezing drizzle</strong> — the same process with tiny drops. Amounts are small, but even a light glaze makes untreated roads slippery.</li>
  <li><strong>Ice pellets (sleet)</strong> — drops that freeze before landing. Choose “Sleet / mixed”.</li>
  <li><strong>Refreeze or flash freeze</strong> — plain rain that freezes when the temperature drops after dark. Enter the rain and the overnight low.</li>
  <li><strong>Black ice</strong> — a thin, transparent layer that looks like wet pavement. Describe it under “Morning commute conditions” as icy roads.</li>
</ul>
HTML],
        ['id' => 'how-ice-counts', 'h2' => 'How ice is counted', 'html' => <<<'HTML'
<ol>
  <li><strong>Ice accretion</strong> you enter counts in full.</li>
  <li><strong>Rain</strong> counts as ice only for a freezing condition: all of it for “Freezing rain”, “Ice”, “Snow + ice” and “Rain + freezing temperature”, half for “Sleet / mixed”, none for plain “Rain”.</li>
  <li><strong>Refreeze</strong>: {refreeze}.</li>
</ol>
<p>The ice points in the model, before timing, roads and settings:</p>
{ice_table}
HTML],
        ['id' => 'how-much-ice', 'h2' => 'How much ice closes school?', 'html' => <<<'HTML'
<p>
  There is no fixed amount, and each district or board decides. As a guide
  to how forecasters see it: the US National Weather Service issues its Ice
  Storm Warning in many areas for about a quarter inch (6 mm) of ice or
  more. Schools often react to far less — a thin glaze at bus time can be
  enough to stop buses.
</p>
<p>
  Examples for a typical suburban school: 4 mm of freezing rain overnight at
  −1 °C with icy roads gives a weather pressure of 52.6, a 42% ice-day
  chance and a 42% chance of a delay or cancelled buses. 1 mm with roads that
  are only wet by morning gives 1% and 6%.
</p>
HTML],
        ['id' => 'timing', 'h2' => 'Why the timing of ice matters', 'html' => <<<'HTML'
<p>
  Freezing rain that ends by midnight gives salt trucks the night to work;
  freezing rain at 6 a.m. meets the buses. Temperature is the other clock:
  ice that forms at −1 °C can melt by mid-morning, while ice followed by a
  deep freeze stays for days. Place the storm on the timeline and describe
  the roads, and both count.
</p>
HTML],
        ['id' => 'canada-ice', 'h2' => 'Ice days in Canada', 'html' => <<<'HTML'
<p>
  In Ontario and the Maritimes an ice morning usually means buses
  cancelled, not schools closed. For board rules — Toronto, Ottawa, Hamilton,
  Halifax, PEI and more — use the
  <a href="{tool:snow-day-calculator-canada}">Canadian snow day calculator</a>
  with the “Freezing rain” condition.
</p>
HTML],
        ['id' => 'limitations', 'h2' => 'Limitations', 'html' => <<<'HTML'
<p>
  No calculator knows the temperature of a particular road, whether it was
  pre-treated, or how much of the rain ran off before freezing. Freezing
  rain forecasts are among the hardest in winter weather: a one-degree
  error in the warm layer aloft turns ice into rain or sleet. Treat the
  estimate as a reason to watch the official forecast and wait for your
  district’s announcement.
</p>
HTML],
    ],

    /* ================================================================
     * COLLEGE
     * ============================================================= */
    'college-snow-day-calculator' => [
        ['id' => 'guide-heading', 'h2' => 'Do colleges have snow days?', 'html' => <<<'HTML'
<p>
  They do, but less often than K–12 schools, and not for the same reasons.
  A school district closes because buses cannot run safely and children
  wait at bus stops. A college weighs different things: many students live
  on campus or walk to class, residence halls and dining must keep running,
  staff and commuters still have to drive in, and classes can move online.
  So colleges usually stay open in weather that closes local schools — and
  when they act, it is often a delayed opening, an early closure or an
  online day.
</p>
<p>
  Enter the forecast for your campus and your college’s settings. You get
  the campus-closure chance, the <strong>disruption chance</strong> (closed,
  delayed or online), the <strong>commute impact</strong> and the
  <strong>class-time weather impact</strong>. The page does not fetch live
  weather or any college’s notice.
</p>
HTML],
        ['id' => 'how-colleges-decide', 'h2' => 'How colleges decide', 'html' => <<<'HTML'
<p>
  The call is usually made early in the morning by senior administrators
  with the campus emergency management, facilities and police teams. They
  look at the forecast and official warnings, campus roads, paths and
  parking, whether local transit is running, and whether staff can reach
  campus safely. It is announced through the college’s own channels — the
  emergency alert text or email, the operating-status page and social
  media. A school district closing nearby does not close a college.
</p>
HTML],
        ['id' => 'settings', 'h2' => 'The campus settings', 'html' => <<<'HTML'
<ul>
  <li><strong>Class time.</strong> Morning classes use the same timing as a school day. For later classes the storm timing is re-weighted: for evening classes, a storm during the day counts in full because it hits the evening commute, while overnight snow counts for only {pct:college.class_times.evening.timing.overnight.share}%.</li>
  <li><strong>Campus type.</strong> A mostly residential campus needs more weather to close, because most students do not travel; a commuter campus closes sooner.</li>
  <li><strong>Online classes.</strong> A college that often moves classes online tends to do that instead of closing, so its closure chance is a little lower and the middle outcome reads “classes online or delayed”.</li>
  <li><strong>How easily it closes</strong> and <strong>commute sensitivity</strong> — your own experience of your college.</li>
</ul>
<p>
  Compared with the school calculator, the closure curve is centred
  {college:level_shift} points of weather pressure higher, and the delay
  curve sits {college:delay_gap} points below it instead of {m:delay_gap}.
</p>
HTML],
        ['id' => 'example', 'h2' => 'An example', 'html' => <<<'HTML'
<p>
  15 cm (about 6 in) of snow over 8 hours, still falling during the morning
  commute, −4 °C, 20 km/h wind, reduced visibility and snow-covered roads.
  For a typical suburban school district that is a weather pressure of 68.5
  and an 87% snow day chance. For a mixed campus with morning classes the
  same figures give a 55% campus-closure chance; for a mostly residential
  campus that often moves classes online, 23%; and for evening classes on a
  mixed campus, 21%.
</p>
HTML],
        ['id' => 'us-canada', 'h2' => 'US colleges and Canadian colleges', 'html' => <<<'HTML'
<p>
  In both countries each college or university decides for itself. In
  Ontario, colleges post their own campus closures, separately from the
  school boards and bus consortia in the same city. Switch the units to
  °C · cm · km/h for Canadian forecasts.
</p>
HTML],
        ['id' => 'how-to-use', 'h2' => 'How to use the college snow day calculator', 'html' => <<<'HTML'
<ol>
  <li>Open the forecast for your campus town the evening before — a national weather service page or a trusted weather app.</li>
  <li>Enter the expected snowfall, when it falls, the temperature, the wind and the road conditions for the morning commute.</li>
  <li>Choose your class time (morning, afternoon or evening) and describe your campus: residential, mixed or commuter, and whether it often moves classes online.</li>
  <li>Read the three results: the chance the campus closes, the chance of any disruption (closed, delayed or online), and how hard the commute is likely to be.</li>
  <li>Check again early in the morning with the latest forecast, and always confirm with your college’s own alert.</li>
</ol>
HTML],
        ['id' => 'storm-morning', 'h2' => 'What to do on a storm morning', 'html' => <<<'HTML'
<p>
  A high disruption chance is a reason to prepare, not a reason to skip
  class. Sign up for your college’s emergency text or email alerts if you
  have not already — they are usually the first place a decision appears,
  often before the website or social media. Check the learning platform
  for messages from each instructor, because a class can move online even
  when the campus stays open.
</p>
<p>
  If you commute, plan for a longer journey: leave early, check whether
  buses or trains are running, and do not drive if roads are unsafe. Most
  colleges expect students to use their own judgement about travel and
  have a process for excusing absences in severe weather — read your
  student handbook so you know how it works before the first storm.
</p>
HTML],
        ['id' => 'exams', 'h2' => 'Exams, labs and online days', 'html' => <<<'HTML'
<p>
  Weather decisions can affect assessments differently from ordinary
  classes. An exam may be rescheduled rather than moved online, a lab may
  be cancelled because it cannot run remotely, and a deadline may stay the
  same even when the campus closes. When bad weather is forecast during
  exam week, look for notices from both the college and your department,
  and ask your instructor directly if anything is unclear.
</p>
HTML],
        ['id' => 'limitations', 'h2' => 'Limitations', 'html' => <<<'HTML'
<p>
  Every campus has its own culture, and the settings are only your
  judgement of it. The model has not been validated against college
  decisions, so no accuracy figure is claimed. It does not know about exams,
  staffing, power or heating problems, or whether a campus has already used
  online days. Check your college’s official operating notice.
</p>
HTML],
    ],

    /* ================================================================
     * COLD DAY
     * ============================================================= */
    'cold-day-calculator' => [
        ['id' => 'guide-heading', 'h2' => 'What is a cold day?', 'html' => <<<'HTML'
<p>
  A cold day is a school closure — or a late start — caused by dangerous
  cold instead of snow. The roads can be perfectly clear. The worry is the
  students who wait at bus stops or walk to school at the coldest time of
  the day, just after sunrise, when a strong wind can make exposed skin
  freeze quickly.
</p>
<p>
  Enter the morning temperature, the wind and how long students are
  outside. The calculator works out the wind chill, shows Environment
  Canada’s frostbite risk band, compares it with your district’s rule if you
  know it, and gives a heuristic cold-day estimate. It does not fetch live
  weather.
</p>
HTML],
        ['id' => 'how-cold', 'h2' => 'How cold does it have to be to cancel school?', 'html' => <<<'HTML'
<p>
  There is no single answer, and you should be sceptical of any website
  that gives one. Every district or board sets its own approach. Some
  publish a wind chill figure. Some combine wind chill with bus-stop
  exposure and building heating. Many simply decide on the morning. A number
  that works in Georgia would be meaningless in Minnesota or Manitoba.
</p>
<p>
  That is why this page asks for <em>your</em> rule. If your district says it
  closes when the wind chill reaches −35 °F, enter −35 and choose wind
  chill: the result tells you how far your figures are from that line.
</p>
HTML],
        ['id' => 'estimate', 'h2' => 'How the cold-day estimate works', 'html' => <<<'HTML'
<p>
  Without a rule, the calculator uses the same heuristic as the
  <a href="{tool:snow-day-calculator}">snow day calculator</a>, with snow,
  ice and roads switched off. {cold_points} Time outside adds up to
  {cfg:model.exposure.3.1} more points once the wind chill is
  {cfg:model.exposure_from_c} °C or colder. Those points become a closure
  chance on an S-curve centred on {m:center}, and a late-start (or
  bus-cancellation) chance on one centred {m:delay_gap} lower.
</p>
<p>
  Examples for a typical suburban school, with students outside for 15
  minutes: −30 °C and a 20 km/h wind is a wind chill of −43 °C and gives a
  54% cold-day chance and a 36% chance of a late start. −20 °C in the same
  wind is a wind chill of −30 °C and gives 1% and 4%. These weights are
  assumptions, not a fit to closure records, so treat the percentage as a
  rough guide and the wind chill as the solid fact.
</p>
HTML],
        ['id' => 'wind-chill', 'h2' => 'Wind chill vs air temperature', 'html' => <<<'HTML'
<p>
  Wind chill is a “feels like” temperature for exposed skin. The US National
  Weather Service and Environment Canada use the same formula, introduced in
  2001, based on the air temperature and the wind speed at 10 metres. It
  only applies at 50 °F (10 °C) or below with some wind; in calm air the
  wind chill is simply the temperature. The
  <a href="{tool:wind-chill-calculator}">wind chill calculator</a> shows the
  formula, a full chart and the old pre-2001 index.
</p>
HTML],
        ['id' => 'risk', 'h2' => 'How dangerous is the cold?', 'html' => <<<'HTML'
<p>Environment Canada’s wind chill risk bands:</p>
{risk_table}
<p>
  −28 °C is about −18 °F and −40 °C is −40 °F. Whatever your school decides,
  dress for the wind chill: layers, a hat, mitts, and a scarf or neck warmer
  over the face.
</p>
HTML],
        ['id' => 'uk', 'h2' => 'Cold closures outside North America', 'html' => <<<'HTML'
<p>
  People in the UK and Australia ask what temperature closes schools there
  too. There is no set figure: in England, government guidance leaves the
  decision to close to school leaders, based on their own risk assessment,
  and the Met Office issues the weather warnings. The calculator works in
  °C for any place, but it cannot know a school’s decision.
</p>
HTML],
        ['id' => 'limitations', 'h2' => 'Limitations', 'html' => <<<'HTML'
<p>
  A forecast wind is measured at 10 metres; a sheltered bus stop can feel
  milder and an open field colder. The calculator does not know about
  school heating problems, which close schools on cold days too. The
  decision is always your district’s or board’s.
</p>
HTML],
    ],

    /* ================================================================
     * WIND CHILL
     * ============================================================= */
    'wind-chill-calculator' => [
        ['id' => 'guide-heading', 'h2' => 'What is wind chill?', 'html' => <<<'HTML'
<p>
  Wind chill is how cold it feels on exposed skin when the wind is blowing.
  Your body warms a thin layer of air next to your skin; wind strips that
  layer away, so you lose heat faster. The wind chill index turns that
  faster heat loss into a temperature: “it feels like −24 °C” means your
  face loses heat about as fast as it would at −24 °C in light wind.
</p>
<p>
  It is a measure of heat loss from people, not of the air. The thermometer
  does not change, and objects — a car radiator, a pipe, a puddle — never
  cool below the air temperature, however strong the wind. The background
  above follows your figures: stronger wind streaks for more wind, cold mist
  and frost as the wind chill drops.
</p>
HTML],
        ['id' => 'formula', 'h2' => 'Wind chill formula', 'html' => <<<'HTML'
<p>
  Since November 2001, the US National Weather Service and Environment
  Canada have used the same index. With the air temperature T and the wind
  speed V measured at 10 metres:
</p>
<ul>
  <li><strong>°F and mph:</strong> wind chill = 35.74 + 0.6215T − 35.75V<sup>0.16</sup> + 0.4275TV<sup>0.16</sup></li>
  <li><strong>°C and km/h:</strong> wind chill = 13.12 + 0.6215T − 11.37V<sup>0.16</sup> + 0.3965TV<sup>0.16</sup></li>
</ul>
<p>
  The NWS uses it at 50 °F (10 °C) and below with winds above 3 mph
  (4.8 km/h). Environment Canada reports wind chill at 0 °C and below with
  winds of 5 km/h or more. Outside that range the calculator returns the air
  temperature and tells you why.
</p>
<p>
  Worked example: −15 °C and 20 km/h. 20<sup>0.16</sup> = 1.615, so 13.12 +
  0.6215 × (−15) − 11.37 × 1.615 + 0.3965 × (−15) × 1.615 = −24.2, which
  rounds to −24 °C — the same figure Environment Canada gives for those
  conditions.
</p>
HTML],
        ['id' => 'celsius', 'h2' => 'Wind chill calculator in Celsius', 'html' => <<<'HTML'
<p>
  Choose °C and enter the wind in km/h — the way Canadian and most other
  forecasts give it. If your forecast gives the wind in metres per second or
  knots, pick that unit; the calculator converts it to km/h (1 m/s =
  3.6 km/h, 1 knot = 1.852 km/h) before using the metric formula. Every
  result is shown in both °C and °F.
</p>
HTML],
        ['id' => 'old', 'h2' => 'The old wind chill index (before 2001) — historical only', 'html' => <<<'HTML'
<p>
  The first wind chill index came from experiments by the Antarctic
  explorers Paul Siple and Charles Passel in the 1940s, who timed how fast
  water froze in a plastic cylinder in different winds. Its US version was
  in use until 2001. It was criticised for exaggerating the cold — a
  cylinder of water is not a face — and for using wind measured high above
  the ground.
</p>
<p>
  The old values were much colder: at 0 °F and 20 mph, the old index gave
  about −39 °F and the current one gives −22 °F. The calculator shows the
  old figure only as a comparison — for example if you are reading an older
  book or chart. Use the current index for anything safety-related.
</p>
HTML],
        ['id' => 'chart', 'h2' => 'How to read the wind chill chart', 'html' => <<<'HTML'
<p>
  The curve under your result shows how the wind chill falls as the wind
  rises, at your air temperature, with your wind marked. In the table, find
  the air temperature on the left and the wind speed across the top; the
  cell where they meet is the wind chill. It switches between °C/km/h and
  °F/mph with your temperature unit and outlines the cell closest to your
  figures. Shading follows Environment Canada’s risk bands:
</p>
{risk_table}
HTML],
        ['id' => 'convert', 'h2' => 'Fahrenheit to Celsius (and back)', 'html' => <<<'HTML'
<p>
  °C = (°F − 32) × 5 ÷ 9 and °F = °C × 9 ÷ 5 + 32. Handy anchors: 32 °F =
  0 °C, 0 °F ≈ −17.8 °C, −40 °F = −40 °C (the one temperature that is the
  same in both). For wind, 1 mph = 1.609 km/h.
</p>
HTML],
        ['id' => 'school', 'h2' => 'Wind chill and school', 'html' => <<<'HTML'
<p>
  Many school districts and boards look at the morning wind chill when
  deciding on cold closures, late starts or bus cancellations — but every
  district has its own rule, and wind chill alone never guarantees a
  closure. To compare a morning with your district’s rule, use the
  <a href="{tool:cold-day-calculator}">cold day calculator</a>. For snow
  and ice, use the <a href="{tool:snow-day-calculator}">snow day
  calculator</a>, the <a href="{tool:ice-day-calculator}">ice day
  calculator</a> or the
  <a href="{tool:snow-day-calculator-canada}">Canadian version</a>.
</p>
HTML],
    ],
];
