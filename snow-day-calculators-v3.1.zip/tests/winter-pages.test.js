/* Rendered-page checks for the six winter weather pages (v3, manual input).
 *
 *   node tests/winter-pages.test.js [http://127.0.0.1:8321]
 *
 * Needs the dev server (see tests/publish-check.ps1). Fetches each page as
 * a crawler would and checks: status, one H1, title / meta description /
 * canonical / robots, breadcrumb and FAQ structured data, the manual-input
 * disclaimers, NO live-weather wording, NO geolocation, NO weather API or
 * /api/ reference, only this site's scripts, internal links across the
 * family (no orphans), the sitemap, unique titles / descriptions / H1s,
 * and that the old /api/snow-day/ endpoint is gone.
 */

const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const cp = require('child_process');

const BASE = (process.argv[2] || 'http://127.0.0.1:8321').replace(/\/$/, '');
const PROJECT = path.resolve(__dirname, '..');
const PHP = path.join(PROJECT, 'php', 'php.exe');
const PAGES = ['snow-day-calculator', 'snow-day-calculator-canada', 'ice-day-calculator', 'college-snow-day-calculator', 'cold-day-calculator', 'wind-chill-calculator'];

let pass = 0, fail = 0;
function ok(label, cond, extra) {
  if (cond) { pass++; console.log('ok   ' + label); }
  else { fail++; console.log('FAIL ' + label + (extra !== undefined ? '   got ' + JSON.stringify(extra) : '')); }
}

function get(url) {
  return new Promise(resolve => {
    (url.startsWith('https') ? https : http).get(url, res => {
      let b = '';
      res.setEncoding('utf8');
      res.on('data', c => { b += c; });
      res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body: b }));
    }).on('error', e => resolve({ status: 0, body: '', error: e.message }));
  });
}

function cfg(slug) {
  const out = cp.execFileSync(fs.existsSync(PHP) ? PHP : 'php',
    ['-d', 'extension_dir=php/ext', '-d', 'extension=php_mbstring.dll', 'tests/export-winter-config.php', slug],
    { cwd: PROJECT, stdio: ['ignore', 'pipe', 'ignore'] }).toString();
  return JSON.parse(out);
}

function decode(s) {
  return s.replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#0?39;|&apos;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>');
}
function visibleText(html) {
  return decode(html.replace(/<script[\s\S]*?<\/script>/gi, ' ').replace(/<style[\s\S]*?<\/style>/gi, ' ').replace(/<[^>]+>/g, ' ')).replace(/\s+/g, ' ');
}

(async () => {
  const seen = { title: {}, desc: {}, h1: {} };
  const inbound = {};
  PAGES.forEach(p => { inbound[p] = 0; });
  const ph = fs.readFileSync(path.join(PROJECT, 'public_html/app/config/winter-weather.php'), 'utf8');

  for (const slug of PAGES) {
    const C = cfg(slug);
    const tool = require('child_process').execFileSync(fs.existsSync(PHP) ? PHP : 'php',
      ['-d', 'extension_dir=php/ext', '-d', 'extension=php_mbstring.dll', '-r',
       '$_SERVER["REQUEST_URI"]="/";$_SERVER["HTTP_HOST"]="easycalculatorsmart.com";require "public_html/app/config/config.php";$t=(require "public_html/app/config/winter-weather.php")["pages"][$argv[1]]["tool"];echo json_encode($t);', slug],
      { cwd: PROJECT, stdio: ['ignore', 'pipe', 'ignore'] }).toString();
    const T = JSON.parse(tool);
    const r = await get(BASE + '/' + slug + '/');
    const h = r.body;
    ok(slug + ': 200', r.status === 200, r.status);
    if (r.status !== 200) continue;

    const h1s = h.match(/<h1[^>]*>([\s\S]*?)<\/h1>/g) || [];
    ok(slug + ': exactly one H1', h1s.length === 1, h1s.length);
    const h1 = decode((h1s[0] || '').replace(/<[^>]+>/g, '').trim());
    ok(slug + ': H1 from config', h1 === T.h1, h1);
    const title = decode(((h.match(/<title>([\s\S]*?)<\/title>/) || [])[1] || '').trim());
    ok(slug + ': title from config', title === T.title, title);
    ok(slug + ': title ≤ 65 characters', title.length <= 65, title.length);
    const desc = decode((h.match(/<meta name="description" content="([^"]*)"/) || [])[1] || '');
    ok(slug + ': meta description from config', desc === T.description, desc);
    ok(slug + ': meta description 70–170 characters', desc.length >= 70 && desc.length <= 170, desc.length);
    const canon = (h.match(/<link rel="canonical" href="([^"]+)"/) || [])[1] || '';
    ok(slug + ': canonical self URL', canon.endsWith('/' + slug + '/'), canon);
    ok(slug + ': not noindex', !/<meta name="robots" content="[^"]*noindex/.test(h) && !/noindex/i.test(r.headers['x-robots-tag'] || ''));
    ok(slug + ': BreadcrumbList schema', /"@type":\s*"BreadcrumbList"/.test(h));
    ok(slug + ': FAQPage schema', /"@type":\s*"FAQPage"/.test(h));
    const faqN = (h.match(/"@type":\s*"Question"/g) || []).length;
    ok(slug + ': every FAQ in schema (' + faqN + ')', faqN >= 5);
    ok(slug + ': FAQ rendered on page', (h.match(/<details class="disclosure">/g) || []).length === faqN);

    const text = visibleText(h);
    if (C.page.kind !== 'formula') {
      ok(slug + ': says "Manual weather estimate"', text.includes('Manual weather estimate'));
      ok(slug + ': says it uses the conditions you enter', text.includes('This calculator uses the weather conditions you enter. It does not fetch live weather or school closure announcements.'));
      ok(slug + ': says it is not a guarantee', text.includes('It is not a guarantee of a school closure.'));
      ok(slug + ': says "Based on the conditions you enter."', text.includes('Based on the conditions you enter.'));
      ok(slug + ': one condition card per configured condition', (h.match(/name="ww-cond"/g) || []).length === Object.keys(C.conditions).length);
      ok(slug + ': one preset button per configured preset', (h.match(/data-preset="/g) || []).length === Object.keys(C.presets).length);
      ok(slug + ': every configured field rendered', Object.keys(C.fields).every(f => h.includes('id="ww-' + f + '"') || (f === 'timing' && h.includes('name="ww-timing"'))));
    }
    const liveClaim = text.replace(/(does not|do not|doesn’t|not)( fetch| use| read)? live (weather|forecast|data)/gi, '').replace(/Does it use (a )?live (weather|forecast)\?/g, '');
    ok(slug + ': no live-weather claim', !/\blive (weather|forecast|data|alerts?|prediction)\b/i.test(liveClaim), (liveClaim.match(/.{40}\blive (weather|forecast|data|alerts?|prediction).{20}/i) || [])[0]);
    ok(slug + ': no "Use my location" / geolocation', !/use my location|geolocation/i.test(h));
    ok(slug + ': no weather API reference', !/open-meteo|api\.weather\.gov|api\.weather\.gc\.ca|\/api\/snow-day|zippopotam|geocod/i.test(h));
    ok(slug + ': no accuracy percentage', !/\d+\s*%\s*accura/i.test(text) && !/most accurate/i.test(text));
    const scripts = [...h.matchAll(/<script[^>]+src="([^"]+)"/g)].map(m => m[1]);
    ok(slug + ': only this site\'s scripts', scripts.every(s => s.startsWith('/') && !s.startsWith('//')), scripts);
    ok(slug + ': loads the scene and engine', scripts.some(s => s.includes('/lib/snowday.js')) && scripts.some(s => s.includes('/lib/winter-scene.js')));
    ok(slug + ': Permissions-Policy keeps geolocation off', /geolocation=\(\)/.test(r.headers['permissions-policy'] || ''), r.headers['permissions-policy']);
    ok(slug + ': no inline event handlers', !/\son(click|load|error|input|change)=/i.test(h));

    [...h.matchAll(/href="([^"]+)"/g)].map(m => m[1]).forEach(u => {
      PAGES.forEach(p => { if (p !== slug && new RegExp('/' + p + '/?(#.*)?$').test(u)) inbound[p]++; });
    });
    ['title', 'desc', 'h1'].forEach(k => {
      const v = k === 'title' ? title : k === 'desc' ? desc : h1;
      ok(slug + ': unique ' + k, !seen[k][v], seen[k][v]);
      seen[k][v] = slug;
    });
  }

  PAGES.forEach(p => ok(p + ': linked from the rest of the family (' + inbound[p] + ')', inbound[p] >= 2, inbound[p]));

  const sm = await get(BASE + '/sitemap-calculators.xml');
  const smAll = sm.status === 200 ? sm.body : (await get(BASE + '/sitemap.xml')).body;
  let smText = smAll;
  for (const m of smAll.matchAll(/<loc>([^<]+sitemap[^<]*\.xml)<\/loc>/g)) {
    const u = m[1].replace(/^https?:\/\/[^/]+/, BASE);
    smText += (await get(u)).body;
  }
  PAGES.forEach(p => ok(p + ': in the sitemap', smText.includes('/' + p + '/')));

  const cat = await get(BASE + '/category/weather/');
  if (cat.status === 200) PAGES.forEach(p => ok(p + ': listed on the weather category page', cat.body.includes('/' + p + '/')));

  for (const a of ['geocode', 'forecast', 'alerts', 'reverse']) {
    const r = await get(BASE + '/api/snow-day/' + a + '/?q=48201');
    ok('/api/snow-day/' + a + '/ removed (' + r.status + ')', r.status === 404);
  }
  const robots = await get(BASE + '/robots.txt');
  ok('robots.txt: no stale /api/ rule', !/Disallow: \/api\//.test(robots.body));
  ok('config: no live switches left', !/'api'\s*=>\s*\[/.test(ph));

  console.log('\n' + pass + ' passed, ' + fail + ' failed');
  process.exit(fail ? 1 : 0);
})();
