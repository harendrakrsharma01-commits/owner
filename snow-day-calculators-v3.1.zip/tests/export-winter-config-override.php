<?php
/**
 * Like export-winter-config.php, but first applies a JSON patch to the
 * CENTRAL configuration arrays (winter-weather.php / winter-weather-
 * scenarios.php) — exactly as if the site owner had edited those files.
 * Used by tests/winter-scenarios.test.js to prove "edit data, not code".
 *
 *   php tests/export-winter-config-override.php snow-day-calculator '{"winter":{"model":{"center":40}}}'
 */

declare(strict_types=1);

$_SERVER['REQUEST_URI'] = '/';
$_SERVER['HTTP_HOST'] = $_SERVER['HTTP_HOST'] ?? 'easycalculatorsmart.com';
require dirname(__DIR__) . '/public_html/app/config/config.php';
require_once ECS_INCLUDES . '/functions.php';
foreach (['i18n.php', 'icons.php', 'calc-ui.php'] as $inc) {
    if (is_file(ECS_INCLUDES . '/' . $inc)) {
        require_once ECS_INCLUDES . '/' . $inc;
    }
}
require_once ECS_INCLUDES . '/winter-ui.php';

/** Replace leaves of $base with those of $patch (lists replaced whole). */
function patch_merge(array $base, array $patch): array
{
    foreach ($patch as $k => $v) {
        $base[$k] = is_array($v) && isset($base[$k]) && is_array($base[$k]) && !array_is_list($v) ? patch_merge($base[$k], $v) : $v;
    }
    return $base;
}

$slug = $argv[1] ?? 'snow-day-calculator';
$p = json_decode($argv[2] ?? '{}', true) ?: [];
$GLOBALS['ecs_winter'] = patch_merge(require ECS_CONFIG . '/winter-weather.php', $p['winter'] ?? []);
$GLOBALS['ecs_winter_scenarios'] = patch_merge(require ECS_CONFIG . '/winter-weather-scenarios.php', $p['scenarios'] ?? []);
echo json_encode(winter_client_config($slug), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
