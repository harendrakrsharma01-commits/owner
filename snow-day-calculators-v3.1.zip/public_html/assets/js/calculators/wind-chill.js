/* =========================================================================
   EasyCalculatorSmart — Wind Chill Calculator (page script)

   Formulas in lib/snowday.js; the risk bands and the scene settings come
   from the page's JSON config (app/config/winter-weather.php). The
   background scene follows the temperature and wind entered: wind streaks
   for wind, cold mist and frost for cold. Nothing is fetched, stored or
   sent.
   ========================================================================= */

(function (window, document) {
  'use strict';

  var ECS = window.ECS;
  var form = document.getElementById('wc-form');
  var cfgEl = document.getElementById('ww-config');
  if (!ECS || !ECS.snowday || !form || !cfgEl) return;
  var C;
  try { C = JSON.parse(cfgEl.textContent); } catch (e) { return; }
  var S = ECS.snowday.configure(C), U = S.units;

  function $(id) { return document.getElementById(id); }
  function node(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined && text !== null) n.textContent = text;
    return n;
  }
  function sign(n) { return String(n).replace('-', '−'); }
  function r1(n) { return sign(S.round(n, 1)); }
  function tu() { var c = form.querySelector('input[name="wc-tu"]:checked'); return c ? c.value : 'c'; }

  var el = {
    t: $('wc-t'), v: $('wc-v'), vu: $('wc-vu'), empty: $('result-empty'), result: $('result'),
    primary: $('wc-primary'), sub: $('wc-sub'), live: $('wc-live'), note: $('wc-note'),
    stats: $('wc-stats'), steps: $('wc-steps'), grid: $('wc-grid'), share: $('wc-share-text')
  };
  var formError = form.querySelector('.form-error');

  var TO_KMH = { kmh: function (x) { return x; }, mph: U.mphToKmh, ms: U.msToKmh, kt: U.ktToKmh };
  var VU_NAME = { kmh: 'km/h', mph: 'mph', ms: 'm/s', kt: 'knots' };

  function field(input, errId, lo, hi, name) {
    var raw = input.value.trim(), err = $(errId);
    err.textContent = ''; input.removeAttribute('aria-invalid');
    if (raw === '') return { missing: true };
    var v = S.num(raw);
    if (v === null || v < lo || v > hi) {
      err.textContent = name + ' must be a number from ' + sign(lo) + ' to ' + hi + '.';
      input.setAttribute('aria-invalid', 'true');
      return { bad: true };
    }
    return { v: v };
  }

  function calc(show) {
    formError.textContent = '';
    var f = tu() === 'f';
    var tt = field(el.t, 'wc-t-error', f ? -100 : -73, f ? 120 : 49, 'Temperature');
    var vv = field(el.v, 'wc-v-error', 0, el.vu.value === 'ms' ? 90 : 320, 'Wind speed');
    if (tt.bad || vv.bad) { if (show) formError.textContent = 'Fix the highlighted boxes.'; return; }
    if (tt.missing || vv.missing) { if (show) formError.textContent = 'Enter both a temperature and a wind speed.'; return; }

    var tC = f ? U.fToC(tt.v) : tt.v;
    var tF = f ? tt.v : U.cToF(tt.v);
    var vK = TO_KMH[el.vu.value](vv.v);
    var vM = U.kmhToMph(vK);

    /* The unit system the reader typed in decides which published form
       of the formula is "the" answer; the other is shown alongside and
       agrees to within rounding. */
    var mC = S.windChillC(tC, vK), mF = S.windChillF(tF, vM), old = S.oldWindChillF(tF, vM);
    var main = f ? { c: U.fToC(mF.value), f: mF.value, applied: mF.applied } : { c: mC.value, f: U.cToF(mC.value), applied: mC.applied };
    var risk = S.ecccRisk(main.c);

    el.empty.hidden = true; el.result.hidden = false;
    el.primary.textContent = f ? sign(Math.round(main.f)) + ' °F' : sign(Math.round(main.c)) + ' °C';
    el.sub.textContent = (f ? sign(Math.round(main.c)) + ' °C' : sign(Math.round(main.f)) + ' °F') + ' · ' + (risk ? risk.risk : '');

    if (!main.applied) {
      el.note.hidden = false;
      el.note.textContent = f
        ? 'The NWS formula applies at 50 °F or colder with wind above 3 mph, so the wind chill here is the air temperature.'
        : 'The formula applies at 10 °C or colder with wind of at least 4.8 km/h, so the wind chill here is the air temperature.';
    } else {
      el.note.hidden = true;
    }

    el.stats.textContent = '';
    [
      ['Wind chill (°C)', r1(main.c) + ' °C', 'metric index'],
      ['Wind chill (°F)', r1(main.f) + ' °F', 'US index'],
      ['Air temperature', r1(tC) + ' °C / ' + r1(tF) + ' °F', ''],
      ['Wind', S.round(vK, 1) + ' km/h / ' + S.round(vM, 1) + ' mph', vv.v + ' ' + VU_NAME[el.vu.value] + ' entered'],
      ['Feels colder by', r1(tC - main.c) + ' °C / ' + r1(tF - main.f) + ' °F', 'than the air'],
      ['Risk (Environment Canada)', risk ? risk.risk : '—', risk ? risk.note : ''],
      ['Old pre-2001 index', old.applied ? r1(old.value) + ' °F / ' + r1(U.fToC(old.value)) + ' °C' : 'same as air', 'historical comparison only']
    ].forEach(function (s) {
      var d = node('div', 'stat');
      d.appendChild(node('span', 'stat-label', s[0]));
      d.appendChild(node('span', 'stat-value ltr', s[1]));
      if (s[2]) d.appendChild(node('span', 'stat-sub', s[2]));
      el.stats.appendChild(d);
    });

    el.steps.textContent = '';
    var steps = [];
    if (el.vu.value !== (f ? 'mph' : 'kmh')) steps.push('Wind: ' + vv.v + ' ' + VU_NAME[el.vu.value] + ' = ' + S.round(f ? vM : vK, 2) + (f ? ' mph' : ' km/h') + '.');
    if (f) {
      var p = Math.pow(vM, 0.16);
      steps.push('V^0.16 = ' + S.round(vM, 2) + '^0.16 = ' + S.round(p, 4) + '.');
      steps.push('35.74 + 0.6215 × ' + r1(tF) + ' − 35.75 × ' + S.round(p, 4) + ' + 0.4275 × ' + r1(tF) + ' × ' + S.round(p, 4) + ' = ' + r1(mF.value) + ' °F' + (mF.applied ? '' : ' (not applied: air temperature used)') + '.');
    } else {
      var q = Math.pow(vK, 0.16);
      steps.push('V^0.16 = ' + S.round(vK, 2) + '^0.16 = ' + S.round(q, 4) + '.');
      steps.push('13.12 + 0.6215 × ' + r1(tC) + ' − 11.37 × ' + S.round(q, 4) + ' + 0.3965 × ' + r1(tC) + ' × ' + S.round(q, 4) + ' = ' + r1(mC.value) + ' °C' + (mC.applied ? '' : ' (not applied: air temperature used)') + '.');
    }
    steps.push('Old index: 0.0817 × (3.71√V + 5.81 − 0.25V) × (T − 91.4) + 91.4 in °F and mph' + (old.applied ? ' = ' + r1(old.value) + ' °F.' : ' — not applied above 50 °F or below 4 mph.'));
    steps.forEach(function (s) { el.steps.appendChild(node('li', '', s)); });

    drawGrid(f, tC, vK);
    drawCurve(f, tC, vK);
    paintScene(tC, vK, risk);

    var share = 'Wind chill: ' + el.primary.textContent + ' (' + el.sub.textContent + ') at ' + el.t.value + (f ? ' °F' : ' °C') + ', wind ' + vv.v + ' ' + VU_NAME[el.vu.value] + '.';
    el.share.textContent = share + '\n' + window.location.href.split('#')[0].split('?')[0];
    el.live.textContent = share;
  }

  /* ---- Scene: wind streaks from the wind, mist and frost from the cold. */
  var hero = $('ww-hero'), canvas = $('ww-canvas');
  var scene = ECS.winterScene && hero && canvas ? ECS.winterScene.create(hero, canvas, C.visuals) : null;

  function paintScene(tC, vK, risk) {
    var vis = S.visual({ temp_c: tC, wind_kmh: vK }, 'clear');
    vis.layers.streak = S.round(Math.max(vis.wind, 0.08), 3);
    if (vis.cold >= C.visuals.cold_mist_from) vis.layers.mist = vis.cold;
    vis.sky = vis.cold >= 0.6 ? 'cold' : 'clear';
    if (scene) scene.set(vis);
    window.ECS.winterState = { vis: vis, scene: scene };
    $('ww-hero-v').textContent = el.primary.textContent;
    $('ww-hero-band').textContent = risk ? risk.risk : '';
    $('ww-cond-vals').textContent = 'Air ' + (tu() === 'f' ? r1(U.cToF(tC)) + ' °F' : r1(tC) + ' °C') + ' · wind ' + S.round(vK, 0) + ' km/h (' + S.round(U.kmhToMph(vK), 0) + ' mph)';
    $('ww-scene-desc').textContent = 'Background: ' + S.strength(vis.wind) + ' wind streaks' + (vis.layers.mist ? ', ' + S.strength(vis.cold) + ' cold mist' : '') + ', following the temperature and wind you entered.';
  }

  /* ---- Curve: wind chill against wind speed at the entered temperature. */
  var SVGNS = 'http://www.w3.org/2000/svg';
  function svg(tag, attrs, text) {
    var n = document.createElementNS(SVGNS, tag);
    Object.keys(attrs || {}).forEach(function (k) { n.setAttribute(k, attrs[k]); });
    if (text !== undefined) n.textContent = text;
    return n;
  }

  function drawCurve(f, tC, vK) {
    var host = $('wc-curve');
    if (!host) return;
    host.textContent = '';
    var W = 600, H = 220, pl = 46, pr = 14, pt = 14, pb = 34;
    var vMax = f ? 60 : 100;
    var tIn = f ? U.cToF(tC) : tC, vIn = f ? U.kmhToMph(vK) : vK;
    var pts = [];
    for (var v = 0; v <= vMax; v += vMax / 60) {
      var w = f ? S.windChillF(tIn, v) : S.windChillC(tIn, v);
      pts.push([v, w.value]);
    }
    var ys = pts.map(function (p) { return p[1]; });
    var yMax = Math.ceil((Math.max.apply(null, ys) + 2) / 5) * 5, yMin = Math.floor((Math.min.apply(null, ys) - 2) / 5) * 5;
    function X(v) { return pl + (v / vMax) * (W - pl - pr); }
    function Y(y) { return pt + (yMax - y) / (yMax - yMin || 1) * (H - pt - pb); }
    var s = svg('svg', { viewBox: '0 0 ' + W + ' ' + H, class: 'ww-svg', role: 'img', 'aria-label': 'Wind chill from 0 to ' + vMax + (f ? ' mph' : ' km/h') + ' at ' + r1(tIn) + (f ? ' °F' : ' °C') + '; at your wind, ' + el.primary.textContent });
    s.appendChild(svg('line', { x1: pl, y1: H - pb, x2: W - pr, y2: H - pb, class: 'ww-c-axis' }));
    s.appendChild(svg('line', { x1: pl, y1: pt, x2: pl, y2: H - pb, class: 'ww-c-axis' }));
    var step = (yMax - yMin) / 4;
    for (var i = 0; i <= 4; i++) {
      var yy = yMin + step * i;
      s.appendChild(svg('text', { x: pl - 6, y: Y(yy) + 4, 'text-anchor': 'end', class: 'ww-c-lbl' }, sign(Math.round(yy))));
    }
    for (var j = 0; j <= 4; j++) {
      var vv = vMax / 4 * j;
      s.appendChild(svg('text', { x: X(vv), y: H - pb + 16, 'text-anchor': 'middle', class: 'ww-c-lbl' }, String(Math.round(vv))));
    }
    s.appendChild(svg('text', { x: W - pr, y: H - 4, 'text-anchor': 'end', class: 'ww-c-lbl' }, f ? 'wind, mph' : 'wind, km/h'));
    s.appendChild(svg('path', { d: pts.map(function (p, k) { return (k ? 'L' : 'M') + X(p[0]).toFixed(1) + ' ' + Y(p[1]).toFixed(1); }).join(' '), class: 'ww-c-temp' }));
    var cv = Math.min(vIn, vMax), cw = f ? S.windChillF(tIn, cv).value : S.windChillC(tIn, cv).value;
    s.appendChild(svg('line', { x1: X(cv), y1: pt, x2: X(cv), y2: H - pb, class: 'ww-c-zero' }));
    s.appendChild(svg('circle', { cx: X(cv), cy: Y(cw), r: 5, class: 'ww-c-dot' }));
    host.appendChild(s);
  }

  function drawGrid(f, tC, vK) {
    var temps = [], winds = [];
    var i;
    if (f) { for (i = 40; i >= -45; i -= 5) temps.push(i); for (i = 5; i <= 60; i += 5) winds.push(i); }
    else { for (i = 5; i >= -50; i -= 5) temps.push(i); for (i = 5; i <= 80; i += 5) winds.push(i); }
    var tIn = f ? U.cToF(tC) : tC, vIn = f ? U.kmhToMph(vK) : vK;
    var nt = temps.reduce(function (a, b) { return Math.abs(b - tIn) < Math.abs(a - tIn) ? b : a; });
    var nv = winds.reduce(function (a, b) { return Math.abs(b - vIn) < Math.abs(a - vIn) ? b : a; });

    el.grid.textContent = '';
    var cap = node('caption', 'visually-hidden', 'Wind chill by air temperature (rows) and wind speed (columns), ' + (f ? '°F and mph' : '°C and km/h'));
    el.grid.appendChild(cap);
    var thead = node('thead'), hr = node('tr');
    hr.appendChild(node('th', '', f ? '°F \\ mph' : '°C \\ km/h'));
    winds.forEach(function (v) { var th = node('th', 'ltr', String(v)); th.scope = 'col'; hr.appendChild(th); });
    thead.appendChild(hr);
    el.grid.appendChild(thead);
    var tb = node('tbody');
    temps.forEach(function (tt) {
      var tr = node('tr');
      var th = node('th', 'ltr', sign(tt)); th.scope = 'row';
      tr.appendChild(th);
      winds.forEach(function (v) {
        var wc = f ? S.windChillF(tt, v).value : S.windChillC(tt, v).value;
        var band = S.ecccRisk(f ? U.fToC(wc) : wc);
        var td = node('td', 'ltr wc-b' + (band && band.band >= 0 ? band.band : 0), sign(Math.round(wc)));
        if (tt === nt && v === nv) td.className += ' is-hit';
        tr.appendChild(td);
      });
      tb.appendChild(tr);
    });
    el.grid.appendChild(tb);
  }

  form.addEventListener('submit', function (e) { e.preventDefault(); calc(true); });
  form.addEventListener('input', function () { if (!el.result.hidden) calc(false); });
  form.addEventListener('change', function (e) {
    if (e.target.name === 'wc-tu') {
      var v = S.num(el.t.value);
      if (v !== null) el.t.value = String(S.round(tu() === 'f' ? U.cToF(v) : U.fToC(v), 1));
    }
    if (!el.result.hidden) calc(false);
  });
  Array.prototype.forEach.call(document.querySelectorAll('[data-wc-preset]'), function (b) {
    b.addEventListener('click', function () {
      var d; try { d = JSON.parse(b.getAttribute('data-wc-preset')); } catch (e) { return; }
      $(d.tu === 'f' ? 'wc-tu-f' : 'wc-tu-c').checked = true;
      el.t.value = d.t; el.v.value = d.v; el.vu.value = d.vu;
      calc(true);
    });
  });
  $('reset-btn').addEventListener('click', function () {
    el.t.value = ''; el.v.value = '';
    formError.textContent = '';
    ['wc-t-error', 'wc-v-error'].forEach(function (id) { $(id).textContent = ''; });
    el.result.hidden = true; el.empty.hidden = false;
    $('ww-hero-v').textContent = '—'; $('ww-hero-band').textContent = ''; $('ww-cond-vals').textContent = '';
    if (scene) scene.set(S.visual({}, 'clear'));
  });

  /* Start from one example so the page shows a working result; it is
     labelled by the example button's own text. */
  var starters = document.querySelectorAll('[data-wc-preset]');
  var first = starters[C.page.start || 0];
  if (first) first.click();
})(window, document);
