<?php
/**
 * EasyCalculatorSmart — Winter weather family: the page renderer (v3).
 *
 * Every weather page template is one line — winter_render($tool) — and
 * this file builds the page from app/config/winter-weather.php (fields,
 * conditions, presets, SEO, FAQ, sources) and winter-weather-articles.php
 * (prose):
 *
 *   header → H1 + lede → weather panel (scene + result) → condition
 *   selector → presets → location context → manual inputs → timeline →
 *   settings → result dashboard → article → FAQ → sources → related
 *
 * MANUAL ONLY: nothing on these pages fetches weather, alerts, places or
 * closures, and nothing asks for the reader's location.
 *
 * Workspaces by page kind:
 *   closure  snow day, Canada, ice day, college  (winter-calc.js)
 *   cold     cold day                             (winter-calc.js)
 *   formula  wind chill                           (wind-chill.js)
 *
 * The browser receives the settings it needs as one JSON block
 * (winter_client_config) — the scripts carry no weights of their own.
 * The family is published in English only.
 */

declare(strict_types=1);

if (!defined('ECS_BOOTSTRAPPED')) {
    exit;
}

/* =====================================================================
 * CONFIG ACCESS
 * ================================================================== */

/** The whole winter-weather config (parsed once per request). */
function winter_cfg(): array
{
    if (!isset($GLOBALS['ecs_winter']) || !is_array($GLOBALS['ecs_winter'])) {
        $GLOBALS['ecs_winter'] = require ECS_CONFIG . '/winter-weather.php';
    }
    return $GLOBALS['ecs_winter'];
}

/** Scenario rules (app/config/winter-weather-scenarios.php), parsed once per request. */
function winter_scenarios(): array
{
    if (!isset($GLOBALS['ecs_winter_scenarios']) || !is_array($GLOBALS['ecs_winter_scenarios'])) {
        $GLOBALS['ecs_winter_scenarios'] = require ECS_CONFIG . '/winter-weather-scenarios.php';
    }
    return $GLOBALS['ecs_winter_scenarios'];
}

function winter_page(string $slug): array
{
    $p = winter_cfg()['pages'][$slug] ?? null;
    if (!is_array($p)) {
        throw new RuntimeException('No winter page config for ' . $slug);
    }
    return $p + ['slug' => $slug];
}

function winter_articles(string $slug): array
{
    static $all = null;
    if ($all === null) {
        $all = require ECS_CONFIG . '/winter-weather-articles.php';
    }
    return (array) ($all[$slug] ?? []);
}

/** A reference [label, url, note] by key, or null. */
function winter_ref(string $key): ?array
{
    $r = winter_cfg()['references'][$key] ?? null;
    return is_array($r) ? $r : null;
}

/** Condition keys offered on a page. */
function winter_page_conditions(array $pc): array
{
    $all = array_keys(winter_cfg()['conditions']);
    $want = (array) ($pc['conditions'] ?? $all);
    return array_values(array_filter($want, static fn ($k): bool => in_array($k, $all, true)));
}

/** Signed number with a real minus sign and no trailing ".0". */
function winter_n(float $v, int $dp = 1): string
{
    $s = number_format(round($v, $dp), $dp, '.', '');
    if (str_contains($s, '.')) {
        $s = rtrim(rtrim($s, '0'), '.');
    }
    if ($s === '-0') {
        $s = '0';
    }
    return str_replace('-', '−', $s);
}

function winter_c_to_f(float $c): float
{
    return $c * 9 / 5 + 32;
}

/* =====================================================================
 * GENERATED ARTICLE BLOCKS — built from the config so no number in the
 * prose is typed twice.
 * ================================================================== */

function winter_pairs(array $pts, callable $fmt): string
{
    $out = [];
    foreach ($pts as [$x, $p]) {
        if ((float) $p === 0.0 && count($out) === 0) {
            continue;
        }
        $out[] = $fmt((float) $x) . ' = ' . winter_n((float) $p);
    }
    return implode(' · ', $out);
}

function winter_model_table(): string
{
    $c = winter_cfg();
    $M = $c['model'];

    $snow = winter_pairs($M['snow'], static fn (float $x): string => winter_n($x) . ' cm (' . winter_n($x / 2.54) . ' in)');
    $ice  = winter_pairs($M['ice'], static fn (float $x): string => winter_n($x) . ' mm');
    $cold = winter_pairs($M['cold'], static fn (float $x): string => winter_n(-$x, 0) . ' °C (' . winter_n(winter_c_to_f(-$x), 0) . ' °F)');
    $rate = winter_pairs($M['rate'], static fn (float $x): string => winter_n($x) . ' cm/h');
    $wind = winter_pairs($M['wind'], static fn (float $x): string => winter_n($x, 0) . ' km/h');
    $gust = winter_pairs($M['gust'], static fn (float $x): string => winter_n($x, 0) . ' km/h');
    $melt = [];
    foreach ($M['melt'] as [$x, $share]) {
        $melt[] = ((float) $x <= 0 ? '0 °C or colder' : '+' . winter_n((float) $x) . ' °C') . ': ' . winter_n($share * 100, 0) . '%';
    }
    $timing = [];
    foreach ($c['timing'] as $t) {
        $timing[] = $t['short'] . ': ' . winter_n($t['share'] * 100, 0) . '% of the snow, ' . winter_n((float) $t['points']) . ' pts';
    }
    $commute = [];
    foreach ($c['commute'] as $cm) {
        $commute[] = $cm['label'] . ' ' . winter_n((float) $cm['points']);
    }
    $vis = [];
    foreach ($c['visibility'] as $v) {
        $vis[] = strtok($v['label'], ' (') . ' ' . winter_n((float) $v['points']);
    }

    $rows = [
        ['Snow', $snow, 'Effective snow = amount × storm-timing share × warm-ground share.'],
        ['Storm timing', implode(' · ', $timing), 'Snow still falling at bus time matters most; snow during school hours leads to early dismissals.'],
        ['Warm ground', implode(' · ', $melt), 'Share of the snow counted when the commute temperature is above freezing.'],
        ['Ice', $ice, 'Ice accretion + rain counted as ice for a freezing condition + refreeze allowance.'],
        ['Refreeze', winter_refreeze_text(), 'Wet roads that freeze before the buses run.'],
        ['Wind chill', $cold, 'Children waiting at bus stops; milder than ' . winter_n(-(float) $M['cold'][0][0], 0) . ' °C adds nothing.'],
        ['Extras', 'Snow rate ' . $rate . ' · wind ' . $wind . ' · gusts ' . $gust . ' · visibility ' . implode(', ', $vis) . ' · capped at ' . winter_n((float) $M['extras_cap']),
         'Rate, wind, gusts, visibility and timing count only with at least ' . winter_n((float) $M['wintry_snow_cm']) . ' cm of snow or any ice.'],
        ['Morning commute', implode(' · ', $commute), 'Your description of the roads; always counted, inside the extras cap.'],
    ];

    $h = '<div class="table-wrap"><table class="data ww-model-table"><caption>Points per factor (heuristic model ' . e($M['version']) . ')</caption>'
       . '<thead><tr><th scope="col">Factor</th><th scope="col">Scale</th><th scope="col">Why</th></tr></thead><tbody>';
    foreach ($rows as [$k, $scale, $why]) {
        $h .= '<tr><th scope="row">' . e($k) . '</th><td>' . e($scale) . '</td><td>' . e($why) . '</td></tr>';
    }
    return $h . '</tbody></table></div>';
}

function winter_ice_table(): string
{
    $M = winter_cfg()['model'];
    $h = '<div class="table-wrap"><table class="data"><caption class="visually-hidden">Ice points by freezing precipitation</caption>'
       . '<thead><tr><th scope="col">Freezing precipitation</th><th scope="col" class="num">Ice points</th></tr></thead><tbody>';
    foreach ($M['ice'] as [$x, $p]) {
        if ((float) $x === 0.0) {
            continue;
        }
        $h .= '<tr><td class="ltr">' . e(winter_n((float) $x) . ' mm (' . winter_n($x / 25.4, 2) . ' in)') . '</td><td class="num">' . e(winter_n((float) $p)) . '</td></tr>';
    }
    return $h . '</tbody></table></div>';
}

function winter_risk_table(): string
{
    $h = '<div class="table-wrap"><table class="data"><caption class="visually-hidden">Environment Canada wind chill risk bands</caption>'
       . '<thead><tr><th scope="col">Wind chill</th><th scope="col">Risk</th><th scope="col">What it means</th></tr></thead><tbody>';
    foreach (winter_cfg()['risk_bands'] as $b) {
        $range = $b['min'] <= -999
            ? winter_n((float) $b['max'], 0) . ' °C and colder'
            : winter_n((float) $b['max'], 0) . ' to ' . winter_n((float) $b['min'], 0) . ' °C';
        $h .= '<tr><td class="ltr">' . e($range) . '</td><td>' . e($b['short']) . '</td><td>' . e($b['note']) . '</td></tr>';
    }
    return $h . '</tbody></table></div>';
}

function winter_conditions_table(): string
{
    $c = winter_cfg();
    $h = '<div class="table-wrap"><table class="data"><caption class="visually-hidden">Weather conditions and how each one is treated</caption>'
       . '<thead><tr><th scope="col">Condition</th><th scope="col">Typical figures filled in</th><th scope="col" class="num">Rain counted as ice</th></tr></thead><tbody>';
    foreach ($c['conditions'] as $k => $cd) {
        $parts = [];
        foreach ($cd['set'] as $f => $v) {
            if ((float) $v > 0) {
                $parts[] = strtolower($c['fields'][$f]['label']) . ' ' . winter_n((float) $v) . ' ' . ['snow_cm' => 'cm', 'snow_hours' => 'h', 'rain_mm' => 'mm', 'ice_mm' => 'mm'][$f];
            }
        }
        if (isset($cd['temp'])) {
            $parts[] = 'temperature ' . winter_n((float) $cd['temp'][0], 0) . ' to ' . winter_n((float) $cd['temp'][1], 0) . ' °C';
        }
        if (isset($cd['wind_min'])) {
            $parts[] = 'wind at least ' . winter_n((float) $cd['wind_min'], 0) . ' km/h';
        }
        $h .= '<tr><th scope="row">' . e($cd['label']) . '</th><td>' . e($parts === [] ? 'no precipitation' : implode(', ', $parts)) . '</td><td class="num">' . e(winter_n($cd['rain_ice'] * 100, 0)) . '%</td></tr>';
    }
    return $h . '</tbody></table></div>';
}

function winter_cold_points(): string
{
    $pts = winter_cfg()['model']['cold'];
    $parts = [];
    foreach ($pts as $i => [$x, $p]) {
        $t = winter_n(-(float) $x, 0) . ' °C (' . winter_n(winter_c_to_f(-(float) $x), 0) . ' °F)';
        $parts[] = $i === 0 ? 'A wind chill of ' . $t . ' or milder adds nothing' : $t . ' adds ' . winter_n((float) $p);
    }
    return implode(', ', $parts) . ' points.';
}

function winter_refreeze_text(): string
{
    $R = winter_cfg()['model']['refreeze'];
    return 'when at least ' . winter_n((float) $R['rain_min_mm']) . ' mm of rain (not already counted as ice) is followed by an overnight low of '
        . winter_n((float) $R['temp_max_c']) . ' °C or colder, ' . winter_n($R['share'] * 100, 0) . '% of that rain (at most '
        . winter_n((float) $R['cap_mm']) . ' mm) is counted as possible ice';
}

function winter_melt_text(): string
{
    $m = winter_cfg()['model']['melt'];
    $last = end($m);
    return 'snow at a commute temperature above freezing is counted at a reduced share — down to ' . winter_n($last[1] * 100, 0)
        . '% at +' . winter_n((float) $last[0]) . ' °C — because some of it melts on the roads.';
}

function winter_links_html(array $links): string
{
    if ($links === []) {
        return '';
    }
    $out = [];
    foreach ($links as $l) {
        $out[] = '<a href="' . e($l[1]) . '" rel="noopener" target="_blank">' . e($l[0]) . '</a>';
    }
    return '<p class="ww-src-links">' . implode(' · ', $out) . '</p>';
}

function winter_ca_areas_html(): string
{
    $h = '';
    foreach (winter_cfg()['ca_areas'] as $a) {
        if (!empty($a['generic'])) {
            continue; // the two "elsewhere" entries have no local facts
        }
        $h .= '<h3>' . e($a['label']) . '</h3><p><strong>' . e($a['boards']) . '.</strong> Buses: ' . e($a['buses']) . '. ' . e($a['note']) . '</p>'
            . winter_links_html($a['links']);
    }
    return $h;
}

function winter_state_notes_html(): string
{
    $h = '';
    foreach (winter_cfg()['us_state_notes'] as $n) {
        $links = [];
        foreach ($n['refs'] as $rk) {
            if (($r = winter_ref($rk)) !== null) {
                $links[] = [$r[0], $r[1]];
            }
        }
        $h .= '<h3>' . e($n['title']) . '</h3><p>' . e($n['text']) . '</p>' . winter_links_html($links);
    }
    return $h;
}

/** A config value by dot path ("model.center"), or null. */
function winter_cfg_path(string $path): mixed
{
    $v = winter_cfg();
    if (str_starts_with($path, 'scenarios.')) {      // scenario rules live in their own file
        $v = ['scenarios' => winter_scenarios()];
    }
    foreach (explode('.', $path) as $k) {
        if (!is_array($v) || !array_key_exists($k, $v)) {
            return null;
        }
        $v = $v[$k];
    }
    return $v;
}

/**
 * Replace the {placeholders} in article HTML ($html = true) or in a plain
 * string such as a lede or an FAQ answer ($html = false, where the table
 * placeholders are not allowed and nothing is escaped — the caller does).
 */
function winter_fill(string $text, bool $html = true): string
{
    $cfg = winter_cfg();
    $esc = static fn (string $v): string => $html ? e($v) : $v;
    return (string) preg_replace_callback('/{([a-z_]+)(?::([a-z0-9_.-]+))?}/', static function (array $m) use ($cfg, $html, $esc): string {
        $k = $m[1];
        $a = $m[2] ?? '';
        switch ($k) {
            case 'tool':
                return $esc(tool_url($a));
            case 'm':
                return isset($cfg['model'][$a]) && is_numeric($cfg['model'][$a]) ? $esc(winter_n((float) $cfg['model'][$a])) : $m[0];
            case 'college':
                return isset($cfg['college'][$a]) && is_numeric($cfg['college'][$a]) ? $esc(winter_n((float) $cfg['college'][$a])) : $m[0];
            case 'cfg':
                $v = winter_cfg_path($a);
                return is_numeric($v) ? $esc(winter_n((float) $v)) : (is_string($v) ? $esc($v) : $m[0]);
            case 'abs':
                $v = winter_cfg_path($a);
                return is_numeric($v) ? $esc(winter_n(abs((float) $v))) : $m[0];
            case 'pct':
                $v = winter_cfg_path($a);
                return is_numeric($v) ? $esc(winter_n((float) $v * 100, 0)) : $m[0];
            case 'cold_points': return $esc(winter_cold_points());
            case 'refreeze':    return $esc(winter_refreeze_text());
            case 'melt':        return $esc(winter_melt_text());
        }
        if (!$html) {
            return $m[0];
        }
        switch ($k) {
            case 'model_table':      return winter_model_table();
            case 'ice_table':        return winter_ice_table();
            case 'risk_table':       return winter_risk_table();
            case 'conditions_table': return winter_conditions_table();
            case 'ca_areas':         return winter_ca_areas_html();
            case 'state_notes':      return winter_state_notes_html();
        }
        return $m[0];
    }, $text);
}

/* =====================================================================
 * BROWSER CONFIG — the only settings the scripts receive.
 * ================================================================== */

function winter_client_config(string $slug): array
{
    $cfg = winter_cfg();
    $pc  = winter_page($slug);

    $refs = static function (array $keys): array {
        $out = [];
        foreach ($keys as $k) {
            if (($r = winter_ref($k)) !== null) {
                $out[] = $r;
            }
        }
        return $out;
    };

    $countries = [];
    foreach ($cfg['countries'] as $cc => $c) {
        $countries[$cc] = [
            'name' => $c['name'], 'units' => $c['units'], 'region_label' => $c['region_label'], 'postal_label' => $c['postal_label'],
            'postal_max' => $c['postal_max'], 'authority' => $c['weather_authority'], 'decider' => $c['decider'], 'note' => $c['note'],
            'tip' => $c['forecast_tip'], 'refs' => $refs($c['refs']), 'regions' => $cfg['region_codes'][$cc] ?? [],
        ];
    }

    $notes = [];
    foreach ($cfg['us_state_notes'] as $n) {
        $notes[] = ['state' => $n['state'], 'cities' => $n['cities'], 'title' => $n['title'], 'text' => $n['text'], 'refs' => $refs($n['refs'])];
    }

    $presets = [];
    foreach ((array) ($pc['presets'] ?? []) as $k) {
        if (is_string($k) && isset($cfg['presets'][$k])) {
            $p = $cfg['presets'][$k];
            $presets[$k] = ['label' => $p['label'], 'condition' => $p['condition'], 'values' => $p['values'], 'expect' => $p['expect'][$slug] ?? null];
        }
    }

    $fields = [];
    foreach ((array) ($pc['fields'] ?? []) as $f) {
        $fields[$f] = $cfg['fields'][$f];
    }

    $conditions = [];
    foreach (winter_page_conditions($pc) as $k) {
        $conditions[$k] = $cfg['conditions'][$k];
    }

    $out = [
        'page' => [
            'slug'     => $slug,
            'kind'     => $pc['kind'],
            'region'   => $pc['region'],
            'focus'    => $pc['focus'],
            'level'    => $pc['level'],
            'theme'    => $pc['theme'] ?? 'snow',
            'labels'   => $pc['labels'] ?? [],
            'settings' => $pc['settings'] ?? [],
            'ignore'   => $cfg['model']['focus_ignore'][$pc['focus']] ?? [],
            'start'    => $pc['start'] ?? null,
            'name'     => $pc['tool']['name'],
            'url'      => tool_url($slug),
        ],
        'fields'              => $fields,
        'field_defs'          => $cfg['fields'],
        'conditions'          => $conditions ?: $cfg['conditions'],
        'all_conditions'      => $cfg['conditions'],
        'detect'              => $cfg['detect'],
        'timing'              => $cfg['timing'],
        'commute'             => $cfg['commute'],
        'visibility'          => $cfg['visibility'],
        'rain_intensity'      => $cfg['rain_intensity'],
        'model'               => $cfg['model'],
        'visuals'             => $cfg['visuals'],
        'risk_bands'          => $cfg['risk_bands'],
        'units'               => $cfg['units'],
        'tendency'            => $cfg['tendency'],
        'commute_sensitivity' => $cfg['commute_sensitivity'],
        'area_types'          => $cfg['area_types'],
        'school_types'        => $cfg['school_types'],
        'college'             => $cfg['college'],
        'bus_rules'           => $cfg['bus_rules'],
        'countries'           => $countries,
        'state_notes'         => $notes,
        'presets'             => $presets,
        'disclaimers'         => $cfg['disclaimers'],
        'links'               => [
            'snow' => tool_url('snow-day-calculator'),
            'ca'   => tool_url('snow-day-calculator-canada'),
            'ice'  => tool_url('ice-day-calculator'),
            'cold' => tool_url('cold-day-calculator'),
            'wc'   => tool_url('wind-chill-calculator'),
        ],
    ];

    if (!empty($pc['scenarios'])) {
        $out['scenarios'] = winter_scenarios();
    }

    if (in_array('ca_area', (array) ($pc['settings'] ?? []), true)) {
        $out['ca_areas'] = $cfg['ca_areas'];
    }

    return $out;
}

function winter_config_script(string $slug): void
{
    echo '<script type="application/json" id="ww-config">'
        . json_encode(winter_client_config($slug), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
        . '</script>';
}

/* =====================================================================
 * SMALL PIECES OF MARKUP
 * ================================================================== */

/** The weather glyphs once, as symbols the page <use>s. */
function winter_icon_sprite(): void
{
    $names = ['wx-cloud', 'wx-clear', 'wx-snow', 'wx-heavy-snow', 'wx-rain', 'wx-ice', 'wx-mixed', 'wx-cold', 'wx-wind-snow', 'wx-fog', 'wind', 'thermometer', 'graduation'];
    echo '<svg class="ww-sprite" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">';
    foreach ($names as $n) {
        echo '<symbol id="wxi-' . e($n) . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round">'
            . icon_paths($n) . '</symbol>';
    }
    echo '</svg>';
}

function winter_use(string $name, string $class = 'ww-ico'): string
{
    return '<svg class="' . e($class) . '" aria-hidden="true" focusable="false"><use href="#wxi-' . e($name) . '"/></svg>';
}

/** Native radio "segmented" control. */
function winter_segmented(string $name, string $label, array $options, string $checked, string $hint = ''): void
{
    $lid = $name . '-label';
    echo '<div class="field"><span class="label" id="' . e($lid) . '">' . e($label) . '</span>';
    echo '<div class="segmented ww-segc" role="radiogroup" aria-labelledby="' . e($lid) . '">';
    foreach ($options as $value => $opt) {
        $id = $name . '-' . $value;
        echo '<input type="radio" name="' . e($name) . '" id="' . e($id) . '" value="' . e((string) $value) . '"' . ((string) $value === $checked ? ' checked' : '') . '>';
        echo '<label for="' . e($id) . '"' . (!empty($opt['hint']) ? ' title="' . e($opt['hint']) . '"' : '') . '>' . e($opt['label']) . '</label>';
    }
    echo '</div>';
    if ($hint !== '') {
        echo '<span class="hint">' . e($hint) . '</span>';
    }
    echo '</div>';
}

/** A <select> of config options. */
function winter_select(string $id, string $label, array $options, string $selected, string $hint = '', string $extraClass = ''): void
{
    echo '<div class="field' . ($extraClass !== '' ? ' ' . e($extraClass) : '') . '" data-field-wrap="' . e($id) . '"><label class="label" for="' . e($id) . '">' . e($label) . '</label>';
    echo '<select class="select" id="' . e($id) . '"' . ($hint !== '' ? ' aria-describedby="' . e($id) . '-hint"' : '') . '>';
    foreach ($options as $value => $opt) {
        $text = is_array($opt) ? (string) $opt['label'] : (string) $opt;
        echo '<option value="' . e((string) $value) . '"' . ((string) $value === $selected ? ' selected' : '') . '>' . e($text) . '</option>';
    }
    echo '</select>';
    if ($hint !== '') {
        echo '<span class="hint" id="' . e($id) . '-hint">' . e($hint) . '</span>';
    }
    echo '</div>';
}

/** One manual number field with − / + steppers. Units are filled by JS. */
function winter_number_field(string $key, array $f, bool $metric): void
{
    $id = 'ww-' . $key;
    $unitLabel = match ($f['unit']) {
        'hours' => 'h', 'minutes' => 'min',
        default => (string) winter_cfg()['units'][$metric ? 'metric' : 'us'][$f['unit']],
    };
    $desc = [];
    if (!empty($f['hint'])) {
        $desc[] = $id . '-hint';
    }
    $desc[] = $id . '-error';
    ?>
          <div class="field ww-f" data-field-wrap="<?= e($key) ?>">
            <label class="label" for="<?= e($id) ?>"><?= e($f['label']) ?><?php if (!empty($f['optional'])): ?> <span class="ww-opt">optional</span><?php endif; ?></label>
            <div class="ww-num">
              <button type="button" class="ww-step" data-step="-1" data-for="<?= e($key) ?>" aria-label="Decrease <?= e(strtolower($f['label'])) ?>" tabindex="-1">−</button>
              <input class="input" type="text" inputmode="decimal" id="<?= e($id) ?>" data-field="<?= e($key) ?>" maxlength="9" autocomplete="off" spellcheck="false" aria-describedby="<?= e(implode(' ', $desc)) ?>">
              <span class="ww-unit" data-unit="<?= e($f['unit']) ?>" aria-hidden="true"><?= e($unitLabel) ?></span>
              <button type="button" class="ww-step" data-step="1" data-for="<?= e($key) ?>" aria-label="Increase <?= e(strtolower($f['label'])) ?>" tabindex="-1">+</button>
            </div>
            <?php if (!empty($f['hint'])): ?><span class="hint" id="<?= e($id) ?>-hint"><?= e($f['hint']) ?></span><?php endif; ?>
            <p class="error-msg" id="<?= e($id) ?>-error" role="alert"></p>
          </div>
    <?php
}

/* =====================================================================
 * THE WEATHER PANEL — the scene behind the result. It follows the
 * values the reader enters; it is never a forecast.
 * ================================================================== */

/** Decorative page silhouette at the bottom of the panel (local SVG). */
function winter_silhouette(string $theme): string
{
    $paths = match ($theme) {
        'canada' => '<path d="M0 150 L0 118 Q120 104 240 112 T480 108 T720 114 T960 106 T1200 112 L1200 150Z" opacity=".55"/>'
            . '<path d="M40 150 l14-44 14 44z M70 150 l11-34 11 34z M96 150 l16-52 16 52z M600 150 l12-40 12 40z M626 150 l15-50 15 50z M655 150 l10-30 10 30z M1040 150 l14-46 14 46z M1068 150 l11-36 11 36z M1094 150 l16-54 16 54z M1124 150 l12-38 12 38z"/>'
            . '<path d="M300 140 H560" stroke="currentColor" stroke-width="2" opacity=".35"/>',
        'ice' => '<path d="M0 150 L0 126 Q300 116 600 124 T1200 120 L1200 150Z" opacity=".5"/>'
            . '<g fill="none" stroke="currentColor" stroke-width="1.4" opacity=".55"><path d="M0 20 L60 40 L50 70 M60 40 L110 30 M30 30 L40 55"/><path d="M1200 30 L1140 50 L1150 85 M1140 50 L1090 38 M1170 42 L1160 64"/><path d="M1200 150 L1150 120 L1165 95 M1150 120 L1110 128"/></g>',
        'college' => '<path d="M0 150 L0 124 Q300 112 600 122 T1200 118 L1200 150Z" opacity=".5"/>'
            . '<path d="M140 150 V96 H250 V150Z M168 96 V78 H222 V96Z M195 78 L180 64 H210Z M880 150 V104 H1010 V150Z M920 104 L945 84 L970 104Z M1040 150 V112 H1100 V150Z"/>'
            . '<g opacity=".45"><rect x="160" y="108" width="12" height="14"/><rect x="190" y="108" width="12" height="14"/><rect x="220" y="108" width="12" height="14"/><rect x="900" y="116" width="12" height="14"/><rect x="930" y="116" width="12" height="14"/><rect x="960" y="116" width="12" height="14"/></g>',
        'cold' => '<path d="M0 150 L0 120 L120 86 L200 108 L320 70 L430 104 L540 82 L660 110 L780 76 L900 104 L1020 88 L1200 112 L1200 150Z" opacity=".55"/>'
            . '<path d="M320 70 L300 80 L312 82 L296 92 M780 76 L764 88 L776 88" fill="none" stroke="currentColor" stroke-width="1.5" opacity=".5"/>',
        'wind' => '<path d="M0 150 L0 124 Q200 108 400 120 T800 116 T1200 120 L1200 150Z" opacity=".55"/>'
            . '<g fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" opacity=".3"><path d="M80 60 H300 a14 14 0 1 0 -14 -14"/><path d="M160 88 H520"/><path d="M700 50 H940 a14 14 0 1 1 -14 14"/></g>',
        default => '<path d="M0 150 L0 116 Q150 96 300 110 T600 104 T900 112 T1200 102 L1200 150Z" opacity=".55"/>'
            . '<path d="M80 150 l16-50 16 50z M108 150 l12-36 12 36z M1010 150 l15-48 15 48z M1036 150 l12-34 12 34z M1062 150 l17-56 17 56z"/>'
            . '<path d="M520 150 V120 L548 100 L576 120 V150Z" opacity=".8"/>',
    };
    return '<svg class="ww-sil" viewBox="0 0 1200 150" preserveAspectRatio="none" aria-hidden="true" focusable="false"><g fill="currentColor">' . $paths . '</g></svg>';
}

function winter_panel(array $pc): void
{
    $d = winter_cfg()['disclaimers'];
    $labels = $pc['labels'] ?? [];
    ?>
  <div class="ww-hero" id="ww-hero" data-sky="clear" data-theme-page="<?= e($pc['theme'] ?? 'snow') ?>">
    <canvas class="ww-canvas" id="ww-canvas" aria-hidden="true"></canvas>
    <div class="ww-haze" aria-hidden="true"></div>
    <?= winter_silhouette((string) ($pc['theme'] ?? 'snow')) ?>
    <div class="ww-hero-inner">
      <div class="ww-hero-top">
        <span class="ww-badge"><span class="ww-dot" aria-hidden="true"></span><?= e($d['badge']) ?></span>
        <span class="ww-badge ww-badge-soft" id="ww-example" hidden><?= e($d['example']) ?></span>
      </div>
      <div class="ww-hero-main">
        <div class="ww-hero-wx">
          <p class="ww-cond"><span class="ww-cond-ico" id="ww-cond-ico"><?= winter_use('wx-clear') ?></span><span><strong id="ww-cond">Clear</strong><span class="ww-cond-vals" id="ww-cond-vals"></span></span></p>
          <p class="ww-place" id="ww-place"></p>
          <p class="ww-basis"><?= e($d['basis']) ?> <?= e('Not a forecast, and not a closure announcement.') ?></p>
        </div>
        <div class="ww-hero-res" aria-live="off">
          <p class="ww-hero-k"><?= e($labels['primary'] ?? '') ?></p>
          <p class="ww-hero-v ltr" id="ww-hero-v">—</p>
          <p class="ww-hero-band" id="ww-hero-band"></p>
          <p class="ww-hero-2"><span><?= e($labels['second'] ?? '') ?></span> <strong class="ltr" id="ww-hero-2v">—</strong></p>
        </div>
      </div>
    </div>
    <p class="visually-hidden" id="ww-scene-desc"></p>
  </div>
    <?php
}

/** The condition selector: radio cards with icons. */
function winter_condition_picker(array $pc): void
{
    $cfg = winter_cfg();
    $keys = winter_page_conditions($pc);
    ?>
      <fieldset class="ww-fs ww-conds-fs">
        <legend>Weather condition</legend>
        <p class="hint" id="ww-cond-hint">Pick the weather in your forecast. It fills typical figures and sets the scene — every value below stays editable.</p>
        <div class="ww-conds" role="radiogroup" aria-describedby="ww-cond-hint">
          <?php foreach ($keys as $k): $cd = $cfg['conditions'][$k]; ?>
            <input type="radio" name="ww-cond" id="ww-cond-<?= e($k) ?>" value="<?= e($k) ?>">
            <label for="ww-cond-<?= e($k) ?>" class="ww-cond-card"><?= winter_use($cd['icon'], 'ww-ico ww-cond-card-i') ?><span><?= e($cd['label']) ?></span></label>
          <?php endforeach; ?>
        </div>
        <p class="ww-note ww-suggest" id="ww-suggest" hidden><span id="ww-suggest-text"></span> <button type="button" class="btn btn-secondary btn-sm" id="ww-suggest-btn">Switch condition</button></p>
      </fieldset>
    <?php
}

function winter_presets(array $pc): void
{
    $cfg = winter_cfg();
    ?>
      <div class="cs-presets ww-presets" role="group" aria-label="Example scenarios">
        <span class="cs-presets-k">Presets</span>
        <?php foreach ((array) $pc['presets'] as $k): if (!isset($cfg['presets'][$k])) { continue; } $p = $cfg['presets'][$k]; ?>
          <button type="button" class="cs-preset" data-preset="<?= e($k) ?>"><?= winter_use($cfg['conditions'][$p['condition']]['icon'], 'ww-ico ww-preset-i') ?><?= e($p['label']) ?></button>
        <?php endforeach; ?>
      </div>
    <?php
}

/** Location context: contextual only, nothing is looked up. */
function winter_location(array $pc): void
{
    $cfg = winter_cfg();
    $cc = in_array($pc['region'], ['US', 'CA'], true) ? $pc['region'] : 'US';
    $country = $cfg['countries'][$cc];
    $countryOpts = [];
    foreach ($cfg['countries'] as $k => $c) {
        $countryOpts[$k] = $c['name'];
    }
    $regionOpts = ['' => '—'] + $cfg['region_codes'][$cc];
    ?>
      <details class="ww-fs ww-loc" id="ww-loc"<?= $pc['region'] === 'CA' ? ' open' : '' ?>>
        <summary><span class="ww-loc-t">Location context</span> <span class="ww-loc-s">optional — for your notes and local rules only, never used to fetch weather</span></summary>
        <div class="ww-grid">
          <?php winter_select('ww-country', 'Country', $countryOpts, $cc); ?>
          <?php winter_select('ww-region', $country['region_label'], $regionOpts, ''); ?>
          <div class="field">
            <label class="label" for="ww-city">City or town</label>
            <input class="input" type="text" id="ww-city" maxlength="60" autocomplete="off" spellcheck="false">
          </div>
          <div class="field">
            <label class="label" for="ww-postal" id="ww-postal-label"><?= e($country['postal_label']) ?></label>
            <input class="input" type="text" id="ww-postal" maxlength="<?= (int) $country['postal_max'] ?>" autocomplete="off" spellcheck="false" aria-describedby="ww-postal-hint">
            <span class="hint" id="ww-postal-hint"><?= e($country['postal_hint']) ?></span>
          </div>
        </div>
        <p class="hint" id="ww-country-tip"><?= e($country['forecast_tip']) ?></p>
      </details>
    <?php
}

function winter_units_toggle(bool $metric): void
{
    $u = winter_cfg()['units'];
    ?>
        <fieldset class="ww-units">
          <legend class="label">Units</legend>
          <div class="segmented" role="radiogroup" aria-label="Units">
            <input type="radio" name="ww-units" id="ww-u-us" value="us"<?= $metric ? '' : ' checked' ?>>
            <label for="ww-u-us"><?= e($u['us']['label']) ?></label>
            <input type="radio" name="ww-units" id="ww-u-metric" value="metric"<?= $metric ? ' checked' : '' ?>>
            <label for="ww-u-metric"><?= e($u['metric']['label']) ?></label>
          </div>
          <span class="hint">Switching units converts the boxes; the result does not change.</span>
        </fieldset>
    <?php
}

/** The storm-timing timeline: the timing input itself. */
function winter_timeline(bool $college): void
{
    $cfg = winter_cfg();
    ?>
        <fieldset class="ww-fs ww-tl-fs" data-field-wrap="timing">
          <legend>Storm timing</legend>
          <p class="hint" id="ww-tl-hint">When does the storm hit? This places your storm on the timeline — it is not an hourly forecast.</p>
          <div class="ww-tl" role="radiogroup" aria-describedby="ww-tl-hint">
            <?php foreach ($cfg['timing'] as $k => $t): ?>
              <input type="radio" name="ww-timing" id="ww-t-<?= e($k) ?>" value="<?= e($k) ?>"<?= $k === 'overnight' ? ' checked' : '' ?>>
              <label for="ww-t-<?= e($k) ?>" class="ww-tl-step" data-tl="<?= e($k) ?>">
                <span class="ww-tl-bar" aria-hidden="true"><span class="ww-tl-fill"></span></span>
                <span class="ww-tl-k"><?= e($college && $k === 'school' ? 'Class hours' : ($college && $k === 'commute' ? 'Travel to campus' : $t['short'])) ?></span>
              </label>
            <?php endforeach; ?>
          </div>
          <p class="ww-tl-now" id="ww-tl-now" aria-live="polite"></p>
        </fieldset>
    <?php
}

/* =====================================================================
 * WORKSPACE: closure and cold pages
 * ================================================================== */

function winter_workspace(array $pc): void
{
    $cfg = winter_cfg();
    $slug = $pc['slug'];
    $settings = (array) ($pc['settings'] ?? []);
    $fields = (array) ($pc['fields'] ?? []);
    $metric = $pc['region'] === 'CA';
    $isCollege = $pc['level'] === 'college';
    $isCold = $pc['kind'] === 'cold';
    $groups = [
        'precip' => $isCold ? '' : 'Precipitation',
        'temp'   => 'Temperature',
        'wind'   => $isCold ? 'Wind' : 'Wind and visibility',
        'timing' => 'Roads',
    ];
    ?>
  <section aria-labelledby="calc-heading" class="ww-work" data-ww-page="<?= e($slug) ?>" data-ww-kind="<?= e($pc['kind']) ?>">
    <h2 id="calc-heading" class="visually-hidden"><?= e($pc['tool']['name']) ?></h2>
    <?php winter_icon_sprite(); ?>
    <?php winter_config_script($slug); ?>

    <?php winter_panel($pc); ?>

    <form id="ww-form" class="ww-form" novalidate>
      <div class="form-error" role="alert"></div>

      <?php winter_condition_picker($pc); ?>
      <?php winter_presets($pc); ?>

      <div class="ww-row">
        <?php winter_location($pc); ?>
        <?php winter_units_toggle($metric); ?>
      </div>

      <fieldset class="ww-fs ww-inputs">
        <legend><?= $isCold ? 'Morning conditions (your forecast)' : ($isCollege ? 'Your forecast for the class day' : 'Your forecast for the school day') ?></legend>
        <p class="hint"><?= e($cfg['disclaimers']['no_fetch']) ?> Enter your local forecast; the result updates as you type.</p>
        <?php foreach ($groups as $g => $title): ?>
          <?php
            $inGroup = array_values(array_filter($fields, static fn (string $f): bool => ($cfg['fields'][$f]['group'] ?? '') === $g && $f !== 'timing'));
            if ($inGroup === []) {
                continue;
            }
          ?>
          <div class="ww-group" data-group="<?= e($g) ?>">
            <?php if ($title !== ''): ?><h3 class="ww-group-h"><?= e($title) ?></h3><?php endif; ?>
            <div class="ww-grid">
              <?php foreach ($inGroup as $f):
                  $fd = $cfg['fields'][$f];
                  if (($fd['type'] ?? 'number') === 'select') {
                      $opts = $cfg[$fd['options']];
                      winter_select('ww-' . $f, $fd['label'], $opts, (string) array_key_first($opts), '', 'ww-f');
                  } else {
                      winter_number_field($f, $fd, $metric);
                  }
              endforeach; ?>
            </div>
          </div>
        <?php endforeach; ?>
      </fieldset>

      <?php if (in_array('timing', $fields, true)) { winter_timeline($isCollege); } ?>

      <fieldset class="ww-fs ww-settings">
        <legend><?= $isCollege ? 'Your campus (assumptions you control)' : 'Your school (assumptions you control)' ?></legend>
        <?php if (in_array('ca_area', $settings, true)): ?>
          <?php
            $areaOpts = [];
            foreach ($cfg['ca_areas'] as $k => $a) {
                $areaOpts[$k] = $a['label'];
            }
            winter_select('ww-area-ca', 'Area and board', $areaOpts, (string) array_key_first($areaOpts), 'Sets who announces what and the local bus rule. It is not a feed of today’s cancellations.');
          ?>
          <p class="ww-area-note" id="ww-area-note" aria-live="polite"></p>
        <?php endif; ?>
        <div class="ww-grid">
          <?php if (in_array('bus_rule', $settings, true)) { winter_select('ww-busrule', 'When buses are cancelled…', $cfg['bus_rules'], 'separate'); } ?>
          <?php if (in_array('school_type', $settings, true)) { winter_select('ww-school', 'School type', $cfg['school_types'], 'public', 'Elementary, middle and high schools in one district almost always close together.'); } ?>
          <?php if (in_array('class_time', $settings, true)) { winter_select('ww-class', 'When are your classes?', $cfg['college']['class_times'], 'morning', 'Re-weights the storm timing for your classes.'); } ?>
          <?php if (in_array('online', $settings, true)) { winter_select('ww-online', 'Does it move classes online for storms?', $cfg['college']['online'], 'sometimes'); } ?>
        </div>
        <?php if (in_array('campus', $settings, true)) { winter_segmented('ww-campus', 'Campus', $cfg['college']['campus_types'], 'mixed'); } ?>
        <?php if (in_array('area', $settings, true)) { winter_segmented('ww-area', 'Area', $cfg['area_types'], 'suburban'); } ?>
        <?php winter_segmented('ww-tend', $isCollege ? 'How easily does your college close?' : 'How easily does your school close?', $cfg['tendency'], 'typical'); ?>
        <?php if (in_array('commute_sens', $settings, true)) { winter_segmented('ww-csens', 'How sensitive is the commute?', $cfg['commute_sensitivity'], 'typical'); } ?>
        <p class="hint">These shift the estimate; they are your judgement about your area, not an official policy.</p>
        <?php if ($isCold): ?>
          <h3 class="ww-group-h">Your district’s cold rule (optional)</h3>
          <p class="hint">If your district or board publishes a cold-weather rule, enter it. Leave it blank if you do not know — the page will not guess one.</p>
          <div class="ww-grid">
            <?php winter_select('ww-rule-basis', 'Rule is based on', ['wc' => 'Wind chill', 'air' => 'Air temperature'], 'wc'); ?>
            <div class="field">
              <label class="label" for="ww-rule">Close at or below (<span data-unit-inline="temp"><?= $metric ? '°C' : '°F' ?></span>)</label>
              <input class="input" type="text" inputmode="decimal" id="ww-rule" maxlength="8" autocomplete="off" aria-describedby="ww-rule-error">
              <p class="error-msg" id="ww-rule-error" role="alert"></p>
            </div>
          </div>
        <?php endif; ?>
      </fieldset>

      <div class="btn-row">
        <button class="btn btn-secondary" type="button" id="ww-reset"><?php icon('refresh'); ?> Reset</button>
      </div>
    </form>

    <?php winter_result($pc); ?>
  </section>
    <?php
}

function winter_result(array $pc): void
{
    $cfg = winter_cfg();
    $labels = $pc['labels'];
    $d = $cfg['disclaimers'];
    $country = $cfg['countries'][$pc['region']] ?? $cfg['countries']['OTHER'];
    $isIce = $pc['focus'] === 'ice';
    $isCold = $pc['kind'] === 'cold';
    $isCollege = $pc['level'] === 'college';
    ?>
    <div class="result ww-result" id="result">
      <h2 id="result-heading" class="visually-hidden">Result</h2>
      <p class="visually-hidden" id="ww-live" aria-live="polite"></p>

      <section class="ww-block" aria-labelledby="ww-dash-h">
        <h3 class="ww-h" id="ww-dash-h">Current input conditions</h3>
        <p class="ww-sub"><?= e($d['basis']) ?></p>
        <div class="ww-tiles" id="ww-dash"></div>
      </section>

      <div class="ww-notes" id="ww-notes"></div>

      <section class="ww-block ww-outcome" aria-labelledby="ww-out-h">
        <h3 class="ww-h" id="ww-out-h"><?= $isCold ? 'Cold-day estimate' : 'Estimate' ?></h3>
        <div class="result-primary ww-primary">
          <span class="result-label"><?= e($isCold ? $labels['second'] : $labels['primary']) ?></span>
          <span class="result-value ltr" id="ww-primary">—</span>
          <p class="result-sub" id="ww-sub"></p>
          <span class="ww-estimate-tag"><?= e($d['badge']) ?> — not an official closure</span>
        </div>
        <div class="ww-outcomes">
          <div class="ww-o ww-o-close"><span class="ww-o-k"><?= e($labels['closure']) ?></span><span class="ww-o-v ltr" data-o="closure">—</span></div>
          <div class="ww-o ww-o-delay"><span class="ww-o-k" id="ww-middle-label"><?= e($labels['middle']) ?></span><span class="ww-o-v ltr" data-o="delay">—</span></div>
          <div class="ww-o ww-o-open"><span class="ww-o-k"><?= e($labels['open']) ?></span><span class="ww-o-v ltr" data-o="open">—</span></div>
        </div>
        <div class="ww-bar" id="ww-bar" role="img" aria-label="">
          <span class="ww-bar-seg ww-o-close" data-seg="closure"></span>
          <span class="ww-bar-seg ww-o-delay" data-seg="delay"></span>
          <span class="ww-bar-seg ww-o-open" data-seg="open"></span>
        </div>
        <?php if ($isIce): ?>
          <div class="ww-tiles ww-ice-sum" id="ww-ice-sum"></div>
        <?php endif; ?>
        <?php if ($isCollege): ?>
          <div class="ww-tiles ww-college-sum" id="ww-college-sum"></div>
        <?php endif; ?>
        <?php if ($isCold): ?>
          <p class="ww-note" id="ww-rule-out" hidden></p>
        <?php endif; ?>
        <p class="ww-drivers" id="ww-drivers"></p>
        <div class="ww-why" id="ww-why" hidden>
          <h4 class="ww-h4">Why did my result change?</h4>
          <ul class="ww-why-list" id="ww-why-list"></ul>
        </div>
      </section>

      <section class="ww-block" aria-labelledby="ww-factors-h">
        <h3 class="ww-h" id="ww-factors-h">Factor breakdown</h3>
        <figure class="ww-chart-fig">
          <div class="ww-chart" id="ww-chart"></div>
          <figcaption class="hint">Each bar is that factor’s points out of 100 before they combine. The list below gives the same figures in words.</figcaption>
        </figure>
        <ul class="ww-factors" id="ww-factors"></ul>
      </section>

      <aside class="ww-official" aria-labelledby="ww-official-h">
        <h3 id="ww-official-h" class="ww-official-h"><?php icon('info'); ?> Estimate, not an announcement</h3>
        <p><?= e($d['estimate']) ?> <?= e($d['no_fetch']) ?></p>
        <p id="ww-official-who"><?= e($isCollege ? $d['college'] : $country['note'] . ' ' . $d['official']) ?></p>
        <ul class="ww-official-links" id="ww-official-links"></ul>
      </aside>

      <section class="ww-block" aria-labelledby="ww-work-h">
        <h3 class="ww-h" id="ww-work-h">Show your work</h3>
        <ol class="step-list" id="ww-steps"></ol>
      </section>

      <div class="btn-row no-print">
        <button class="btn btn-secondary btn-sm" type="button" data-copy="ww-share-text"><?php icon('copy'); ?> Copy result</button>
        <button class="btn btn-secondary btn-sm" type="button" data-print><?php icon('print'); ?> Print</button>
      </div>
      <pre id="ww-share-text" class="visually-hidden"></pre>
    </div>
    <?php
}

/* =====================================================================
 * WORKSPACE: wind chill (formula only)
 * ================================================================== */

function winter_workspace_formula(array $pc): void
{
    $slug = $pc['slug'];
    ?>
  <section aria-labelledby="calc-heading" class="ww-work ww-work-formula" data-ww-page="<?= e($slug) ?>" data-ww-kind="formula">
    <h2 id="calc-heading" class="visually-hidden"><?= e($pc['tool']['name']) ?></h2>
    <?php winter_icon_sprite(); ?>
    <?php winter_config_script($slug); ?>

    <div class="ww-hero ww-hero-wc" id="ww-hero" data-sky="clear" data-theme-page="wind">
      <canvas class="ww-canvas" id="ww-canvas" aria-hidden="true"></canvas>
      <div class="ww-haze" aria-hidden="true"></div>
      <?= winter_silhouette('wind') ?>
      <div class="ww-hero-inner">
        <div class="ww-hero-top"><span class="ww-badge"><span class="ww-dot" aria-hidden="true"></span>Formula result</span></div>
        <div class="ww-hero-main">
          <div class="ww-hero-wx">
            <p class="ww-cond"><span class="ww-cond-ico"><?= winter_use('wind') ?></span><span><strong id="ww-cond">Wind chill</strong><span class="ww-cond-vals" id="ww-cond-vals"></span></span></p>
            <p class="ww-basis">Calculated from the temperature and wind you enter.</p>
          </div>
          <div class="ww-hero-res">
            <p class="ww-hero-k">Feels like</p>
            <p class="ww-hero-v ltr" id="ww-hero-v">—</p>
            <p class="ww-hero-band" id="ww-hero-band"></p>
          </div>
        </div>
      </div>
      <p class="visually-hidden" id="ww-scene-desc"></p>
    </div>

    <form id="wc-form" novalidate>
      <div class="form-error" role="alert"></div>

      <div class="cs-presets" role="group" aria-label="Examples">
        <span class="cs-presets-k">Examples</span>
        <?php foreach ($pc['presets'] as $p): ?>
          <button type="button" class="cs-preset" data-wc-preset="<?= e(e_json($p['data'])) ?>"><?= e($p['label']) ?></button>
        <?php endforeach; ?>
      </div>

      <div class="field-row">
        <div class="field">
          <label class="label" for="wc-t">Air temperature</label>
          <input class="input" type="text" inputmode="decimal" id="wc-t" maxlength="8" autocomplete="off" placeholder="-15" aria-describedby="wc-t-error">
          <p class="error-msg" id="wc-t-error" role="alert"></p>
        </div>
        <div class="field">
          <span class="label" id="wc-tu-label">Temperature unit</span>
          <div class="segmented" role="radiogroup" aria-labelledby="wc-tu-label">
            <input type="radio" name="wc-tu" id="wc-tu-c" value="c" checked><label for="wc-tu-c">°C</label>
            <input type="radio" name="wc-tu" id="wc-tu-f" value="f"><label for="wc-tu-f">°F</label>
          </div>
        </div>
      </div>
      <div class="field-row">
        <div class="field">
          <label class="label" for="wc-v">Wind speed</label>
          <input class="input" type="text" inputmode="decimal" id="wc-v" maxlength="8" autocomplete="off" placeholder="20" aria-describedby="wc-v-hint wc-v-error">
          <span class="hint" id="wc-v-hint">Sustained wind at 10 m, as in a forecast — not gusts.</span>
          <p class="error-msg" id="wc-v-error" role="alert"></p>
        </div>
        <div class="field">
          <label class="label" for="wc-vu">Wind unit</label>
          <select class="select" id="wc-vu">
            <option value="kmh">km/h</option>
            <option value="mph">mph</option>
            <option value="ms">m/s</option>
            <option value="kt">knots</option>
          </select>
        </div>
      </div>
      <div class="btn-row">
        <button class="btn btn-primary" type="submit">Calculate</button>
        <button class="btn btn-secondary" type="button" id="reset-btn">Reset</button>
      </div>
    </form>

    <div class="result-empty" id="result-empty">
      <?php icon('wind'); ?>
      <p>Enter a temperature and a wind speed, or tap an example. Results update as you type.</p>
    </div>

    <div class="result" id="result" hidden>
      <h2 class="visually-hidden">Result</h2>
      <div class="result-primary">
        <span class="result-label">Wind chill</span>
        <span class="result-value ltr" id="wc-primary">—</span>
        <p class="result-sub" id="wc-sub"></p>
      </div>
      <p class="visually-hidden" id="wc-live" aria-live="polite"></p>
      <div class="result-body">
        <p class="ww-note" id="wc-note" hidden></p>
        <div class="stats" id="wc-stats"></div>

        <section aria-labelledby="wc-work-h">
          <h3 class="result-section-title" id="wc-work-h">Show your work</h3>
          <ol class="step-list" id="wc-steps"></ol>
        </section>

        <section aria-labelledby="wc-curve-h">
          <h3 class="result-section-title" id="wc-curve-h">Wind chill at your temperature</h3>
          <figure class="ww-chart-fig">
            <div class="ww-chart" id="wc-curve"></div>
            <figcaption class="hint" id="wc-curve-cap">How the wind chill falls as the wind rises, at your air temperature. Your wind is marked. The chart below gives the figures.</figcaption>
          </figure>
        </section>

        <section aria-labelledby="wc-grid-h">
          <h3 class="result-section-title" id="wc-grid-h">Wind chill chart</h3>
          <p class="hint">Rows: air temperature. Columns: wind speed. Your result is outlined (nearest cell). Shading follows Environment Canada’s risk bands, and every cell carries its number.</p>
          <div class="table-wrap" tabindex="0" role="region" aria-labelledby="wc-grid-h">
            <table class="data wc-grid" id="wc-grid"></table>
          </div>
        </section>

        <div class="btn-row no-print">
          <button class="btn btn-secondary btn-sm" type="button" data-copy="wc-share-text"><?php icon('copy'); ?> Copy result</button>
          <button class="btn btn-secondary btn-sm" type="button" data-print><?php icon('print'); ?> Print</button>
        </div>
        <pre id="wc-share-text" class="visually-hidden"></pre>
      </div>
    </div>
  </section>
    <?php
}

/* =====================================================================
 * SOURCES SECTION
 * ================================================================== */

/* =====================================================================
 * SCENARIO WORKSPACE (snow day page) — tabs, inputs and empty result
 * slots. Every option list, label and default comes from
 * app/config/winter-weather-scenarios.php; assets/js/calculators/
 * winter-scenarios.js fills the results. No logic lives here.
 * ================================================================== */

/** <select> from a keyed list whose items have `label` (or `name`). */
function winter_ws_select(string $id, string $label, array $opts, ?string $selected, string $attr = ''): void
{
    echo '<div class="field"><label class="label" for="' . e($id) . '">' . e($label) . '</label><select class="select" id="' . e($id) . '" ' . $attr . '>';
    foreach ($opts as $k => $o) {
        $text = is_array($o) ? ($o['label'] ?? $o['name'] ?? (string) $k) : (string) $o;
        echo '<option value="' . e((string) $k) . '"' . ((string) $k === (string) $selected ? ' selected' : '') . '>' . e($text) . '</option>';
    }
    echo '</select></div>';
}

function winter_ws_input(string $id, string $label, string $value = '', string $hint = '', string $mode = 'decimal', string $unit = ''): void
{
    echo '<div class="field"><label class="label" for="' . e($id) . '">' . e($label)
        . ($unit !== '' ? ' <span class="ws-unit" data-ws-unit="' . e($unit) . '"></span>' : '') . '</label>'
        . '<input class="input" type="text" inputmode="' . e($mode) . '" autocomplete="off" id="' . e($id) . '" value="' . e($value) . '"'
        . ($hint !== '' ? ' aria-describedby="' . e($id) . '-hint"' : '') . '>'
        . ($hint !== '' ? '<span class="hint" id="' . e($id) . '-hint">' . e($hint) . '</span>' : '') . '</div>';
}

function winter_scenario_workspace(array $pc): void
{
    $X = winter_scenarios();
    $cfg = winter_cfg();
    $modes = $X['modes'];
    $first = array_key_first($modes);
    $T = $X['timeline'];
    ?>
  <section class="ws" id="scenario-workspace" aria-labelledby="ws-h">
    <h2 id="ws-h">Scenario workspace</h2>
    <p class="ws-lede">Every tool below uses the forecast you entered above and the same model. <?= e($X['outcomes']['probability_note']) ?></p>

    <div class="ws-tabs" role="tablist" aria-label="Scenario tools">
      <?php foreach ($modes as $k => $m): ?>
      <button type="button" role="tab" id="ws-tab-<?= e($k) ?>" aria-controls="ws-panel-<?= e($k) ?>" aria-selected="<?= $k === $first ? 'true' : 'false' ?>" tabindex="<?= $k === $first ? '0' : '-1' ?>" data-ws-tab="<?= e($k) ?>"><?= e($m['label']) ?></button>
      <?php endforeach; ?>
    </div>

    <?php foreach ($modes as $k => $m): ?>
    <div class="ws-panel" role="tabpanel" id="ws-panel-<?= e($k) ?>" aria-labelledby="ws-tab-<?= e($k) ?>" data-ws-panel="<?= e($k) ?>"<?= $k === $first ? '' : ' hidden' ?>>
      <p class="ws-intro"><?= e($m['intro']) ?> <a href="#<?= e($m['section']) ?>">How it works</a></p>
      <div class="form-error" role="alert" data-ws-error></div>
<?php if ($k === 'delay'): ?>
      <div class="ws-outcomes" data-ws-out="outcomes"></div>
      <p class="ws-note" data-ws-out="delay-why"></p>
<?php elseif ($k === 'timeline'): ?>
      <div class="segmented" role="radiogroup" aria-label="Timeline input">
        <input type="radio" name="ws-tl-mode" id="ws-tl-times" value="times" checked><label for="ws-tl-times">Clock times</label>
        <input type="radio" name="ws-tl-mode" id="ws-tl-blocks" value="blocks"><label for="ws-tl-blocks">Time blocks</label>
      </div>
      <div class="field-row">
        <?php winter_ws_input('ws-school', 'School starts', $T['default_school_start'], 'For example 8:00 AM or 08:00.', 'text'); ?>
      </div>
      <div data-ws-tl="times" class="field-row">
        <?php winter_ws_input('ws-st', 'Storm starts', '02:00', '', 'text'); ?>
        <?php winter_ws_input('ws-pk', 'Heaviest snow (peak)', '05:00', 'Optional.', 'text'); ?>
        <?php winter_ws_input('ws-en', 'Storm ends', '07:00', '', 'text'); ?>
      </div>
      <div data-ws-tl="blocks" hidden>
        <div class="ws-table-wrap"><table class="ws-blocks">
          <caption class="visually-hidden">Snowfall time blocks</caption>
          <thead><tr><th scope="col">Starts</th><th scope="col">Hours</th><th scope="col">Type</th><th scope="col">Snow <span data-ws-unit="snow"></span></th><th scope="col">Ice <span data-ws-unit="ice"></span></th><th scope="col">Temp <span data-ws-unit="temp"></span></th><th scope="col"><span class="visually-hidden">Remove</span></th></tr></thead>
          <tbody data-ws-blocks></tbody>
        </table></div>
        <button type="button" class="btn btn-secondary" data-ws-add-block>Add time block</button>
      </div>
      <div class="ws-strip" data-ws-out="strip" aria-hidden="true"></div>
      <ul class="ws-msgs" data-ws-out="timeline"></ul>
      <button type="button" class="btn btn-primary" data-ws-apply="timeline">Use this timing in the calculator</button>
<?php elseif ($k === 'roads'): ?>
      <p class="ws-note">Road condition: <strong data-ws-out="road-now"></strong> (set in “Morning commute conditions” above).</p>
      <div class="field-row">
        <?php winter_ws_select('ws-treat', $X['treatment']['label'], $X['treatment']['levels'], $X['treatment']['default']); ?>
        <?php winter_ws_input('ws-treat-age', 'Hours since treatment', '2', 'Optional. Treatment wears off with time and traffic.'); ?>
      </div>
      <div class="ws-result" data-ws-out="roads"></div>
<?php elseif ($k === 'bus'): ?>
      <label class="ws-check"><input type="checkbox" id="ws-bus-on"> Include bus routes in the estimate</label>
      <div class="field-row">
        <?php winter_ws_select('ws-bus-dep', 'Bus dependence', $X['bus']['dependence'], $X['bus']['defaults']['dependence']); ?>
        <?php winter_ws_select('ws-bus-set', 'Route setting', $X['bus']['setting'], $X['bus']['defaults']['setting']); ?>
      </div>
      <div class="field-row">
        <?php winter_ws_input('ws-bus-km', 'Longest route', (string) $X['bus']['defaults']['route_km'], '', 'decimal', 'dist'); ?>
        <?php winter_ws_input('ws-bus-min', 'Longest ride (minutes)', (string) $X['bus']['defaults']['route_min'], '', 'numeric'); ?>
      </div>
      <div class="ws-result" data-ws-out="bus"></div>
<?php elseif ($k === 'commute'): ?>
      <div class="field-row">
        <?php winter_ws_input('ws-cm-km', 'Trip distance', (string) $X['commute_risk']['defaults']['distance_km'], '', 'decimal', 'dist'); ?>
        <?php winter_ws_input('ws-cm-min', 'Usual travel time (minutes)', (string) $X['commute_risk']['defaults']['minutes'], '', 'numeric'); ?>
        <?php winter_ws_select('ws-cm-route', 'Route type', $X['commute_risk']['route_types'], $X['commute_risk']['defaults']['route']); ?>
      </div>
      <div class="ws-result" data-ws-out="commute"></div>
<?php elseif ($k === 'policy'): ?>
      <div class="field-row">
        <?php winter_ws_select('ws-policy', $X['policy']['label'], $X['policy']['profiles'], $X['policy']['default']); ?>
        <?php winter_ws_input('ws-policy-custom', 'Custom adjustment (points)', '0', 'Positive = needs more weather to close. Between ' . $X['policy']['custom_min'] . ' and ' . $X['policy']['custom_max'] . '.', 'text'); ?>
      </div>
      <div class="field-row">
        <?php winter_ws_select('ws-region', $X['region']['label'], $X['region']['profiles'], $X['region']['default']); ?>
      </div>
      <div class="field-row">
        <?php winter_ws_select('ws-days-h', 'Snow-days-used adjustment', $X['days_used']['heuristics'], $X['days_used']['default']); ?>
        <?php winter_ws_select('ws-days', $X['days_used']['label'], array_combine($X['days_used']['options'], $X['days_used']['options']), '0'); ?>
      </div>
      <p class="ws-note"><?= e($X['days_used']['note']) ?></p>
      <div class="ws-result" data-ws-out="policy"></div>
<?php elseif ($k === 'plow'): ?>
      <div class="field-row">
        <?php winter_ws_input('ws-pl-km', 'Road length to clear', (string) $X['plow']['defaults']['road_km'], 'Total length of the routes that matter for the morning.', 'decimal', 'dist'); ?>
        <?php winter_ws_input('ws-pl-n', 'Number of plows', (string) $X['plow']['defaults']['plows'], '', 'numeric'); ?>
      </div>
      <div class="field-row">
        <?php winter_ws_input('ws-pl-start', 'Plowing starts', $X['plow']['defaults']['start'], '', 'text'); ?>
        <?php winter_ws_input('ws-pl-delay', 'Treatment delay (minutes)', (string) $X['plow']['defaults']['treat_delay_min'], 'Time before plows are working.', 'numeric'); ?>
      </div>
      <p class="ws-note">Snow depth and school start come from the calculator and the timing tool.</p>
      <div class="ws-result" data-ws-out="plow"></div>
      <p class="hint"><?= e($X['plow']['note']) ?></p>
<?php elseif ($k === 'compare'): ?>
      <div class="ws-compare" data-ws-compare></div>
      <div class="btn-row"><button type="button" class="btn btn-secondary" data-ws-add-c>Add scenario C</button></div>
      <div class="ws-result" data-ws-out="compare"></div>
<?php endif; ?>
    </div>
    <?php endforeach; ?>
    <p class="visually-hidden" aria-live="polite" data-ws-live></p>
  </section>
    <?php
}

function winter_sources_html(array $pc): string
{
    $cfg = winter_cfg();
    $h = '';
    $refs = [];
    foreach ((array) ($pc['refs'] ?? []) as $k) {
        if (($r = winter_ref($k)) !== null) {
            $refs[] = $r;
        }
    }
    if ($refs !== []) {
        $h .= '<h3>Official and reference sources</h3><p>Read these for the weather itself and for official decisions — none of them is read automatically by this page.</p><ul>';
        foreach ($refs as $r) {
            $h .= '<li><a href="' . e($r[1]) . '" rel="noopener" target="_blank">' . e($r[0]) . '</a> — ' . e($r[2]) . '.</li>';
        }
        $h .= '</ul>';
    }
    if (in_array('ca_area', (array) ($pc['settings'] ?? []), true)) {
        $h .= '<h3>Boards and transportation consortia</h3><ul>';
        foreach ($cfg['ca_areas'] as $a) {
            foreach ($a['links'] as $l) {
                $h .= '<li><a href="' . e($l[1]) . '" rel="noopener" target="_blank">' . e($l[0]) . '</a> (' . e($a['label']) . ')</li>';
            }
        }
        $h .= '</ul>';
    }
    return $h;
}

/* =====================================================================
 * THE PAGE
 * ================================================================== */

function winter_render(array $tool): void
{
    $slug = (string) $tool['slug'];
    $pc = winter_page($slug);
    $cfg = winter_cfg();
    $estimate = in_array($pc['kind'], ['closure', 'cold'], true);

    $faqs = array_map(static fn (array $f): array => ['q' => winter_fill($f['q'], false), 'a' => winter_fill($f['a'], false)], $pc['faqs']);

    $breadcrumbCategory = get_category($tool['category']);
    $crumbs = [];
    foreach ([['page', 'home', '/', 'crumb.home'], ['page', 'calculators', '/calculators/', 'crumb.calculators']] as [$cT, $cK, $cP, $cL]) {
        if (($cHref = locale_link($cT, $cK, $cP)) !== null) {
            $crumbs[] = ['name' => t($cL), 'url' => url($cHref)];
        }
    }
    if ($breadcrumbCategory !== null) {
        $catHref = locale_link('calccat', $breadcrumbCategory['slug'], '/category/{slug}/');
        if ($catHref !== null) {
            $crumbs[] = ['name' => $breadcrumbCategory['name'], 'url' => url($catHref)];
        }
    }
    $crumbs[] = ['name' => $tool['name'], 'url' => null];

    $js = ['/assets/js/lib/snowday.js', '/assets/js/lib/winter-scene.js'];
    if (!empty($pc['scenarios'])) {
        $js[] = '/assets/js/lib/snowday-scenarios.js';
    }
    $js[] = $estimate ? '/assets/js/calculators/winter-calc.js' : '/assets/js/calculators/wind-chill.js';
    if (!empty($pc['scenarios'])) {
        $js[] = '/assets/js/calculators/winter-scenarios.js';
    }

    $GLOBALS['page'] = $page = [
        'title'       => $tool['title'],
        'description' => $tool['description'],
        'canonical'   => tool_url($slug),
        'breadcrumbs' => $crumbs,
        'faqs'        => $faqs,
        'tool'        => $tool,
        'body_class'  => 'ww-page ww-wide',
        'page_css'    => ['/assets/css/snow-day.css'],
        'page_js'     => $js,
    ];

    require ECS_INCLUDES . '/header.php';
    partial('breadcrumb', ['crumbs' => $crumbs]);
    ?>
<div class="container">

  <header class="calc-head">
    <span class="calc-head-icon" aria-hidden="true"><?php icon(tool_icon($slug)); ?></span>
    <div class="calc-head-text">
      <h1><?= e($tool['h1']) ?></h1>
      <p class="lede"><?= e(winter_fill($pc['lede'], false)) ?></p>
      <?php partial('post-meta'); ?>
    </div>
  </header>
<?php partial('calc-shell-top', ['tool' => $tool]); ?>

<?php
    if ($estimate) {
        winter_workspace($pc);
        if (!empty($pc['scenarios'])) {
            winter_scenario_workspace($pc);
        }
    } else {
        winter_workspace_formula($pc);
    }
?>

  <article class="section" aria-labelledby="guide-heading">
    <div class="prose">
      <?php foreach (winter_articles($slug) as $sec): ?>
      <h2 id="<?= e($sec['id']) ?>"><?= e($sec['h2']) ?></h2>
      <?= winter_fill($sec['html']) ?>
      <?php endforeach; ?>

      <h2 id="faq">Frequently asked questions</h2>
      <div class="faq-list">
        <?php foreach ($faqs as $faq): ?>
          <details class="disclosure">
            <summary><?= e($faq['q']) ?></summary>
            <div class="disclosure-body"><p class="mb-0"><?= e($faq['a']) ?></p></div>
          </details>
        <?php endforeach; ?>
      </div>

      <h2 id="sources">Sources &amp; methodology</h2>
      <p>Checked <?= e(date('F Y', (int) strtotime($cfg['checked']))) ?>. <?= $estimate ? e($cfg['disclaimers']['no_fetch']) . ' ' . e($cfg['disclaimers']['accuracy']) . ' ' : '' ?>This page is not affiliated with any of these organisations and shows no school’s announcements.</p>
      <?= winter_sources_html($pc) ?>

    </div>
  </article>

  <?php partial('related-tools', ['tool' => $tool]); ?>

</div>
<?php
    require ECS_INCLUDES . '/footer.php';
}
