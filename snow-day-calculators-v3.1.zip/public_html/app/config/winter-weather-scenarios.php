<?php
/**
 * EasyCalculatorSmart — Winter weather family: SCENARIO RULES (v3.1).
 *
 * Everything the Scenario Workspace on the snow day page uses: modes,
 * the storm timeline, road treatment, school bus and commute scoring,
 * district-policy and regional profiles, the optional "snow days used"
 * adjustment, the plowing scenario, the delay / early-dismissal split and
 * the what-if comparison. assets/js/lib/snowday-scenarios.js reads ONLY
 * this (embedded as JSON under `scenarios`); no number here is repeated
 * in JavaScript.
 *
 * WHAT IS PHYSICS AND WHAT IS A HEURISTIC
 *   Physics / arithmetic (engine code): wind chill formulas, unit
 *   conversions, clock arithmetic, plow distance ÷ speed.
 *   Heuristic school-decision model (this file + winter-weather.php
 *   `model`): every points value, shift, band and split below. They are
 *   documented scenario assumptions, not measured probabilities, not any
 *   district's policy and not fitted to closure records.
 *
 * EVERGREEN RULES
 *   - Nothing here depends on a year, a school year or a live service.
 *   - Profiles are generic. `verified` stays false unless a profile is
 *     tied to a published, cited policy; `effective` is informational.
 *   - Units: minutes are minutes after/before the school start time;
 *     distances are km, depths cm, speeds km/h (the page converts for
 *     US display).
 */

declare(strict_types=1);

return [

    'version' => '3.1',

    /* =================================================================
     * MODES — one calculator, many scenario tools. Order = tab order.
     * `section` is the article anchor that explains the mode.
     * ============================================================== */
    'modes' => [
        'delay'    => ['label' => 'Delay vs closure',         'section' => 'delay-vs-closure', 'intro' => 'How the four outcomes split for the forecast you entered: closed, late start, early dismissal or a normal day.'],
        'timeline' => ['label' => 'Storm & snowfall timing',  'section' => 'storm-timing',     'intro' => 'Enter clock times or time blocks. The timeline works out which part of the school day the storm hits and feeds that timing into the estimate.'],
        'roads'    => ['label' => 'Roads & treatment',        'section' => 'road-conditions',  'intro' => 'Road condition plus salting / brine treatment. Treatment can lower road pressure — less so in deep cold or when it is many hours old.'],
        'bus'      => ['label' => 'School bus risk',          'section' => 'school-bus-risk',  'intro' => 'How exposed your bus routes are: how many students ride, how long the routes are, and the setting.'],
        'commute'  => ['label' => 'Commute risk',             'section' => 'morning-commute',  'intro' => 'A disruption level for one trip: distance, travel time and route type on top of the weather and road conditions.'],
        'policy'   => ['label' => 'Policy, region & days used','section' => 'district-policy',  'intro' => 'Generic district-policy and regional-tolerance profiles and an optional snow-days-used adjustment. All are scenario assumptions.'],
        'plow'     => ['label' => 'Plowing scenario',         'section' => 'plowing',          'intro' => 'A theoretical clearing time from road length, snow depth and plows. Not a municipal estimate.'],
        'compare'  => ['label' => 'What-if comparison',       'section' => 'what-if',          'intro' => 'Compare your forecast (A) with one or two alternatives side by side.'],
    ],

    /* =================================================================
     * OUTCOMES — the engine gives closure, "delay or early dismissal"
     * (the middle) and normal. The middle is split by storm timing:
     * a storm that is over before school favours a late start; one that
     * arrives during school hours favours an early dismissal.
     * ============================================================== */
    'outcomes' => [
        'labels' => [
            'closure' => 'Closed (snow day)',
            'delay'   => 'Late start / delay',
            'early'   => 'Early dismissal',
            'normal'  => 'Normal schedule',
        ],
        'split' => [                          // engine timing key => share of the middle that is a delay
            'evening'   => 1,
            'overnight' => 1,
            'early'     => 0.95,
            'commute'   => 0.8,
            'school'    => 0.15,
        ],
        'probability_label' => 'Estimated scenario probability',
        'probability_note'  => 'A documented heuristic from the conditions you enter — not a measured historical probability.',
    ],

    /* =================================================================
     * TIMELINE — windows relative to the school start time (minutes;
     * negative = before school). Each maps to one of the engine's storm
     * timings in winter-weather.php `timing`. The window holding the peak
     * (or the heaviest block) sets the timing the estimate uses.
     * ============================================================== */
    'timeline' => [
        'default_school_start' => '08:00',
        'range'             => [-900, 540],   // clock times are placed from 15 h before to 9 h after the start
        'default_storm_min' => 60,            // storm length assumed when no end time is entered
        'windows' => [
            ['key' => 'evening',   'label' => 'Evening before',     'from' => -900, 'to' => -480, 'timing' => 'evening'],
            ['key' => 'overnight', 'label' => 'Overnight',          'from' => -480, 'to' => -180, 'timing' => 'overnight'],
            ['key' => 'predawn',   'label' => 'Pre-dawn',           'from' => -180, 'to' => -75,  'timing' => 'early'],
            ['key' => 'commute',   'label' => 'Morning commute',    'from' => -75,  'to' => 15,   'timing' => 'commute'],
            ['key' => 'school',    'label' => 'School hours',       'from' => 15,   'to' => 300,  'timing' => 'school'],
            ['key' => 'afternoon', 'label' => 'Afternoon / dismissal', 'from' => 300, 'to' => 450, 'timing' => 'school'],
            ['key' => 'return',    'label' => 'Evening return',     'from' => 450,  'to' => 720,  'timing' => 'evening'],
        ],
        /* Before the first window or after the last: these timings. */
        'before_all' => 'evening',
        'after_all'  => 'evening',
        /* Message when the peak (or a block) overlaps a window: {window}. */
        'messages' => [
            'peak'    => 'Peak snowfall overlaps the {window} window.',
            'span'    => 'The storm spans: {windows}.',
            'commute' => 'Snow is still falling during the morning commute — the timing that weighs most.',
            'clear'   => 'The storm is over {hours} before school starts, leaving time to plow and treat.',
            'early'   => 'Snow during school hours raises the chance of an early dismissal rather than a morning closure.',
        ],
        'block_types' => [
            'snow'          => ['label' => 'Snow',          'snow' => 1,   'ice' => 0],
            'mixed'         => ['label' => 'Sleet / mixed', 'snow' => 0.5, 'ice' => 0.5],
            'freezing_rain' => ['label' => 'Freezing rain', 'snow' => 0,   'ice' => 1],
            'rain'          => ['label' => 'Rain (above freezing)', 'snow' => 0, 'ice' => 0],
        ],
        'max_blocks' => 8,
        'block_hours_default' => 3,
    ],

    /* =================================================================
     * ROAD TREATMENT — lowers the road (commute) pressure. Effect =
     * points × temperature effectiveness × age effectiveness, never more
     * than the road's own points. Salt works poorly in deep cold; old
     * treatment wears off. Values are scenario assumptions.
     * ============================================================== */
    'treatment' => [
        'levels' => [
            'none'     => ['label' => 'Untreated',          'points' => 0],
            'partial'  => ['label' => 'Partially treated',  'points' => -4],
            'recent'   => ['label' => 'Recently treated',   'points' => -8],
            'well'     => ['label' => 'Well treated (plowed and salted)', 'points' => -12],
        ],
        'default' => 'none',
        /* x = road temperature °C, y = share of the treatment effect kept. */
        'temperature' => [[-20, 0.1], [-15, 0.3], [-10, 0.6], [-7, 1]],
        /* x = hours since treatment, y = share kept. */
        'age' => [[0, 1], [3, 0.85], [6, 0.65], [12, 0.35], [24, 0.1]],
        'label' => 'Road treatment',
    ],

    /* =================================================================
     * SCHOOL BUS ROUTES — added to the estimate as points (capped) and
     * shown as a route level.
     * ============================================================== */
    'bus' => [
        'dependence' => [
            'low'    => ['label' => 'Few students ride buses',  'points' => 0],
            'medium' => ['label' => 'About half ride buses',    'points' => 2],
            'high'   => ['label' => 'Most students ride buses', 'points' => 4],
        ],
        'setting' => [
            'city'     => ['label' => 'City',     'points' => 0],
            'suburban' => ['label' => 'Suburban', 'points' => 1],
            'rural'    => ['label' => 'Rural',    'points' => 3],
            'hilly'    => ['label' => 'Hilly / mountain roads', 'points' => 5],
        ],
        'route_km'  => [[0, 0], [10, 0], [25, 2], [50, 4]],   // longest route, km
        'route_min' => [[0, 0], [30, 0], [60, 2], [90, 3]],   // longest ride, minutes
        'weather_share' => 0.25,     // share of the road + ice + visibility pressure that reaches the route level
        'estimate_cap'  => 8,        // most points bus routes can add to the estimate
        'levels' => [
            ['below' => 8,   'label' => 'Low route risk'],
            ['below' => 16,  'label' => 'Moderate route risk'],
            ['below' => 26,  'label' => 'High route risk'],
            ['below' => 999, 'label' => 'Severe route risk'],
        ],
        'label' => 'School bus routes',
        'defaults' => ['dependence' => 'medium', 'setting' => 'suburban', 'route_km' => 15, 'route_min' => 40],
    ],

    /* =================================================================
     * COMMUTE RISK — one trip. Informational: it does not change the
     * school estimate (the morning-commute road choice already does).
     * ============================================================== */
    'commute_risk' => [
        'route_types' => [
            'highway' => ['label' => 'Main roads / highway', 'points' => 0],
            'mixed'   => ['label' => 'Mixed',                'points' => 2],
            'side'    => ['label' => 'Side streets',         'points' => 4],
            'rural'   => ['label' => 'Rural / unplowed roads','points' => 6],
        ],
        'distance_km' => [[0, 0], [5, 1], [15, 3], [40, 6]],
        'minutes'     => [[0, 0], [15, 1], [30, 3], [60, 6]],
        'weather_share' => 0.3,     // share of the weather pressure added to the trip score
        'timing_points' => ['evening' => 0, 'overnight' => 1, 'early' => 3, 'commute' => 8, 'school' => 4],
        'levels' => [
            ['below' => 8,   'label' => 'Minor disruption'],
            ['below' => 18,  'label' => 'Moderate disruption'],
            ['below' => 30,  'label' => 'Major disruption'],
            ['below' => 999, 'label' => 'Severe disruption'],
        ],
        'defaults' => ['distance_km' => 8, 'minutes' => 20, 'route' => 'mixed'],
    ],

    /* =================================================================
     * DISTRICT POLICY PROFILES — generic. A positive shift needs MORE
     * weather to close. `custom` uses the reader's own shift, bounded.
     * ============================================================== */
    'policy' => [
        'profiles' => [
            'typical' => ['name' => 'Typical threshold',        'description' => 'No adjustment.',                                          'shift' => 0,   'source' => null, 'effective' => null, 'verified' => false],
            'lower'   => ['name' => 'Lower closure threshold',  'description' => 'Closes for less weather (for example, little plowing capacity).', 'shift' => -8, 'source' => null, 'effective' => null, 'verified' => false],
            'higher'  => ['name' => 'Higher closure threshold', 'description' => 'Stays open in more weather (for example, used to frequent snow).', 'shift' => 8,  'source' => null, 'effective' => null, 'verified' => false],
            'custom'  => ['name' => 'Custom',                   'description' => 'Your own adjustment, in points of weather pressure.',       'shift' => 0,   'source' => null, 'effective' => null, 'verified' => false],
        ],
        'default'    => 'typical',
        'custom_min' => -25,
        'custom_max' => 25,
        'label'      => 'District policy profile',
    ],

    /* =================================================================
     * REGIONAL WEATHER TOLERANCE — scenario assumptions, not claims
     * about any state or province.
     * ============================================================== */
    'region' => [
        'profiles' => [
            'typical' => ['name' => 'Typical snow tolerance', 'description' => 'Snow is common enough that roads are usually cleared overnight.', 'shift' => 0,   'source' => null, 'effective' => null, 'verified' => false],
            'lower'   => ['name' => 'Lower snow tolerance',   'description' => 'Snow is rare; little equipment, so small amounts disrupt travel.', 'shift' => -12, 'source' => null, 'effective' => null, 'verified' => false],
            'higher'  => ['name' => 'Higher snow tolerance',  'description' => 'Heavy snow is routine; large plowing fleets.',                     'shift' => 10,  'source' => null, 'effective' => null, 'verified' => false],
        ],
        'default' => 'typical',
        'label'   => 'Regional weather tolerance',
    ],

    /* =================================================================
     * SNOW DAYS USED — OPTIONAL and OFF by default. Some districts grow
     * reluctant to close once their built-in days are used; that is a
     * habit, not a rule, so the effect is small and only applies when
     * the reader picks the heuristic.
     * ============================================================== */
    'days_used' => [
        'options'   => ['0', '1', '2', '3', '4', '5', '6+'],
        'custom_max'=> 30,
        'heuristics' => [
            'off'   => ['label' => 'No adjustment',               'table' => [[0, 0]]],
            'small' => ['label' => 'Small: harder to close as days are used', 'table' => [[0, 0], [3, 1], [5, 3], [8, 5]]],
        ],
        'default' => 'off',
        'label'   => 'Snow days used this school year',
        'note'    => 'This is a scenario adjustment, not an official district policy or snow-day budget.',
    ],

    /* =================================================================
     * PLOWING — theoretical. passes = ceil(depth ÷ depth_per_pass);
     * hours = road km × passes ÷ (plows × speed) + treatment delay.
     * ============================================================== */
    'plow' => [
        'speed_kmh'       => [[0, 25], [5, 20], [10, 15], [15, 10], [25, 7]],  // x = snow depth cm → working speed
        'depth_per_pass'  => 10,   // cm cleared per pass
        'defaults'        => ['road_km' => 120, 'plows' => 6, 'start' => '02:00', 'treat_delay_min' => 30],
        'commute_before'  => 75,   // minutes before school start the commute begins (matches the timeline window)
        'max_road_km'     => 5000,
        'max_plows'       => 500,
        'note'            => 'A theoretical scenario from the numbers you enter — real routes, traffic, refuelling and priority roads change it. Not a municipal estimate.',
    ],

    /* =================================================================
     * MESSAGES — input errors shown in the workspace.
     * ============================================================== */
    'errors' => [
        'school'      => 'Enter the school start time, for example 8:00 AM.',
        'start'       => 'Enter when the storm starts, for example 2:00 AM.',
        'span'        => 'The storm can last at most 24 hours on this timeline.',
        'block-start' => 'Each time block needs a start time, for example 03:00.',
        'road'        => 'Enter a road length greater than 0.',
        'plows'       => 'Enter the number of plows as a whole number (at least 1).',
        'snow'        => 'Enter a snowfall amount in the calculator above.',
        'time'        => 'Enter plowing start and school start as clock times.',
        'number'      => 'Enter numbers only (for example 15 or 2.5).',
        'custom'      => 'The custom adjustment must be a number.',
    ],

    /* =================================================================
     * WHAT-IF COMPARISON
     * ============================================================== */
    'compare' => [
        'max'    => 3,
        'fields' => ['snow_cm', 'ice_mm', 'temp_c', 'wind_kmh', 'timing', 'commute', 'vis'],
        'starts' => [
            'B' => ['snow_cm' => 20, 'temp_c' => -6, 'timing' => 'commute'],
            'C' => ['snow_cm' => 5,  'ice_mm' => 3,  'temp_c' => -2, 'timing' => 'early'],
        ],
    ],
];
