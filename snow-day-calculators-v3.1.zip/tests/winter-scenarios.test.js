/* Scenario workspace tests (v3.1) — node tests/winter-scenarios.test.js
 *
 * Runs ECS.snowday + ECS.snowdayScenarios on the REAL page config
 * (tests/export-winter-config.php) and covers: four outcomes, delay vs
 * early dismissal, storm and snowfall timing, road treatment, bus routes,
 * commute risk, policy / region / snow-days-used profiles, plowing, what-if
 * comparison, invalid / zero / extreme input, units — and the three
 * architecture promises:
 *   1. CENTRAL CONFIG: changing a threshold, a road weight or a policy shift
 *      ONLY in the PHP config changes the result (no JS/HTML edited);
 *   2. NO MAGIC NUMBERS in the scenario engine, NO YEAR in any engine or UI;
 *   3. NO LIVE DATA: no fetch / XHR / geolocation / weather API anywhere.
 */
'use strict';
const fs = require('fs');
const path = require('path');
const cp = require('child_process');

const PROJECT = path.resolve(__dirname, '..');
const ROOT = path.join(PROJECT, 'public_html');
const PHP = path.join(PROJECT, 'php', 'php.exe');
const php = fs.existsSync(PHP) ? PHP : 'php';
function exportCfg(slug, patch) {
  const args = patch ? ['tests/export-winter-config-override.php', slug, JSON.stringify(patch)] : ['tests/export-winter-config.php', slug];
  return JSON.parse(cp.execFileSync(php, ['-d', 'extension_dir=php/ext', '-d', 'extension=php_mbstring.dll'].concat(args), { cwd: PROJECT, stdio: ['ignore', 'pipe', 'ignore'] }).toString());
}
function load() {
  const window = { ECS: {} };
  new Function('window', fs.readFileSync(path.join(ROOT, 'assets/js/lib/snowday.js'), 'utf8'))(window);
  new Function('window', fs.readFileSync(path.join(ROOT, 'assets/js/lib/snowday-scenarios.js'), 'utf8'))(window);
  return window.ECS;
}

let pass = 0, fail = 0;
function ok(label, cond, extra) { if (cond) { pass++; console.log('ok   ' + label); } else { fail++; console.log('FAIL ' + label + (extra !== undefined ? '   got ' + JSON.stringify(extra) : '')); } }
function is(label, a, e) { ok(label + ' = ' + JSON.stringify(e), JSON.stringify(a) === JSON.stringify(e), a); }

const SLUG = 'snow-day-calculator';
const CFG = exportCfg(SLUG);
const E = load(), S = E.snowday.configure(CFG), SS = E.snowdayScenarios.configure(CFG);
const SET = { ignore: CFG.page.ignore, level: 'k12', tendency: 'typical', commuteSens: 'typical', area: 'suburban', school: 'public', busRule: 'delay' };
const BASE = { snow_cm: 0, snow_hours: 0, rain_mm: 0, ice_mm: 0, temp_c: -5, wind_kmh: 10, vis: 'good', timing: 'overnight', commute: 'clear', wait_min: 10 };
const V = (o) => Object.assign({}, BASE, o);
const NONE = { treatment: { level: 'none' }, bus: { enabled: false }, policy: 'typical', region: 'typical', daysHeuristic: 'off', daysUsed: 0 };
const st = (o) => Object.assign({}, NONE, o);
const run = (v, s, state) => SS.run(V(v), Object.assign({}, SET, s || {}), state || NONE);

/* ---------- config present ---------- */
ok('page config embeds the scenario rules', !!CFG.scenarios && !!CFG.scenarios.outcomes);
ok('other pages do NOT get scenario rules', !exportCfg('ice-day-calculator').scenarios);

/* ---------- backward compatibility ---------- */
const plain = S.calculate(V({ snow_cm: 12, timing: 'commute', commute: 'snowy' }), SET);
const viaRun = run({ snow_cm: 12, timing: 'commute', commute: 'snowy' }).res;
is('no scenario adjustments → identical to the plain engine', [viaRun.closure, viaRun.delay, viaRun.pressure], [plain.closure, plain.delay, plain.pressure]);

/* ---------- outcomes ---------- */
const cases = {
  'basic snow': { snow_cm: 5 }, 'heavy snow': { snow_cm: 30, timing: 'commute', commute: 'snowy', vis: 'poor' },
  'ice': { ice_mm: 3, commute: 'icy' }, 'freezing rain (rain counted only for freezing condition)': { rain_mm: 8 },
  'snow + ice': { snow_cm: 8, ice_mm: 2 }, 'wind': { snow_cm: 6, wind_kmh: 55, gust_kmh: 80 },
  'visibility': { snow_cm: 6, vis: 'verypoor' }, 'cold': { temp_c: -28, wind_kmh: 30 }, 'zero values': {}
};
Object.keys(cases).forEach((k) => {
  const r = run(cases[k]), o = r.outcomes;
  ok(k + ': four outcomes add to 100', o.closure + o.delay + o.early + o.normal === 100, o);
  ok(k + ': all outcomes within 0–100', [o.closure, o.delay, o.early, o.normal].every((x) => x >= 0 && x <= 100), o);
});
ok('heavy snow at commute → closure above basic snow', run(cases['heavy snow']).outcomes.closure > run(cases['basic snow']).outcomes.closure);
ok('plain rain does not become ice on its own', run({ rain_mm: 20, temp_c: 3 }).res.derived.freezingMm === 0);

/* delay vs early dismissal */
const night = run({ snow_cm: 10, timing: 'overnight' }).outcomes, day = run({ snow_cm: 10, timing: 'school' }).outcomes;
is('overnight storm → no early dismissal share', night.early, 0);
ok('school-hours storm → early dismissal outweighs late start', day.early > day.delay, day);
ok('commute storm → mostly late start', (() => { const o = run({ snow_cm: 10, timing: 'commute' }).outcomes; return o.delay >= o.early; })());

/* ---------- storm timing ---------- */
let t = SS.fromTimes({ school: '08:00', start: '02:00', peak: '07:30', end: '09:00' });
is('peak 7:30 for an 8:00 start → morning commute window', [t.ok, t.window.key, t.timing], [true, 'commute', 'commute']);
ok('message: peak overlaps the commute', t.messages.some((m) => /morning commute/i.test(m)), t.messages);
t = SS.fromTimes({ school: '8:00 AM', start: '6 pm', end: '10pm' });
is('evening storm → evening timing', [t.timing, t.hoursClear], ['evening', 10]);
t = SS.fromTimes({ school: '08:00', start: '11:00', peak: '13:00', end: '15:00' });
is('midday storm → school-hours timing', t.timing, 'school');
ok('…and the early-dismissal message', t.messages.some((m) => /early dismissal/i.test(m)));
is('invalid clock rejected', SS.fromTimes({ school: '25:00', start: '02:00' }).error, 'school');
is('missing start rejected', SS.fromTimes({ school: '08:00', start: '' }).error, 'start');
is('am/pm parsing', [SS.parseClock('12:15 am'), SS.parseClock('12 pm'), SS.parseClock('7.30pm'), SS.parseClock('13:61')], [15, 720, 1170, null]);

/* ---------- snowfall timing (blocks) ---------- */
let b = SS.fromBlocks([
  { start: '00:00', hours: 3, type: 'snow', snow_cm: 4 },
  { start: '03:00', hours: 3, type: 'snow', snow_cm: 9, temp_c: -6 },
  { start: '06:00', hours: 3, type: 'freezing_rain', ice_mm: 2, temp_c: -2 },
  { start: '09:00', hours: 3, type: 'rain', snow_cm: 5 }
], '08:00');
is('blocks: totals (rain block adds nothing)', [b.values.snow_cm, b.values.ice_mm], [13, 2]);
is('blocks: heaviest block sets timing (03:00–06:00 centre 04:30 → overnight window)', b.timing, 'overnight');
is('blocks: peak rate from the snowiest block', b.values.snow_rate, 3);
is('blocks: commute temperature from the nearest block', b.values.temp_c, -2);
is('blocks: bad start rejected', SS.fromBlocks([{ start: 'x' }], '08:00').error, 'block-start');
is('blocks: capped at max_blocks', SS.fromBlocks(Array(20).fill({ start: '01:00', snow_cm: 1 }), '08:00').blocks.length, CFG.scenarios.timeline.max_blocks);
b = SS.fromBlocks([{ start: '00:00', hours: 3, type: 'mixed', snow_cm: 4, ice_mm: 2 }], '08:00');
is('blocks: sleet / mixed counts half snow, half ice', [b.values.snow_cm, b.values.ice_mm], [2, 1]);

/* ---------- road treatment ---------- */
let tr = SS.treatment({ level: 'well', road: 'snowy', temp_c: -3, age_h: 0 });
is('well treated, mild cold, fresh → full effect', tr.points, CFG.scenarios.treatment.levels.well.points);
ok('deep cold weakens treatment', SS.treatment({ level: 'well', road: 'snowy', temp_c: -18, age_h: 0 }).points > tr.points);
ok('old treatment weakens', SS.treatment({ level: 'well', road: 'snowy', temp_c: -3, age_h: 12 }).points > tr.points);
is('treatment never goes below the road\'s own points', SS.treatment({ level: 'well', road: 'slushy', temp_c: -3 }).roadAfter, 0);
is('untreated = 0', SS.treatment({ level: 'none', road: 'icy' }).points, 0);
const tre = run({ snow_cm: 10, timing: 'early', commute: 'snowy' }, {}, st({ treatment: { level: 'well', age_h: 1 } }));
ok('treatment lowers the estimate', tre.outcomes.closure < run({ snow_cm: 10, timing: 'early', commute: 'snowy' }).outcomes.closure);
ok('treatment appears as a factor', tre.res.factors.some((f) => f.key === 'treatment' && f.points < 0));

/* ---------- bus ---------- */
const wint = run({ snow_cm: 10, commute: 'snowy' }).res;
const city = SS.bus({ dependence: 'low', setting: 'city', route_km: 5, route_min: 15 }, wint);
const hilly = SS.bus({ dependence: 'high', setting: 'hilly', route_km: 60, route_min: 100 }, wint);
ok('hilly, long, bus-dependent routes score above city routes', hilly.score > city.score, [city.score, hilly.score]);
ok('bus points capped at estimate_cap', hilly.estimatePoints <= CFG.scenarios.bus.estimate_cap);
is('bus adds nothing on a dry day', SS.bus({ dependence: 'high', setting: 'hilly', route_km: 60, route_min: 100 }, run({}).res).estimatePoints, 0);
ok('bus routes raise the estimate when enabled', run({ snow_cm: 10, commute: 'snowy' }, {}, st({ bus: { enabled: true, dependence: 'high', setting: 'rural', route_km: 40, route_min: 80 } })).outcomes.closure > run({ snow_cm: 10, commute: 'snowy' }).outcomes.closure);

/* ---------- commute ---------- */
const c1 = SS.commute({ distance_km: 3, minutes: 10, route: 'highway' }, run({}).res);
const c2 = SS.commute({ distance_km: 40, minutes: 70, route: 'rural' }, run({ snow_cm: 20, timing: 'commute', commute: 'icy' }).res);
ok('commute: long rural trip in a commute storm scores higher', c2.score > c1.score, [c1.score, c2.score]);
is('commute: timing conflict flagged', [c1.timingConflict, c2.timingConflict], [false, true]);
ok('commute level is a configured label', CFG.scenarios.commute_risk.levels.some((l) => l.label === c2.level));

/* ---------- policy / region / days used ---------- */
const snowy = { snow_cm: 12, timing: 'early', commute: 'snowy' };
const base = run(snowy).outcomes.closure;
ok('higher-threshold policy lowers the closure chance', run(snowy, {}, st({ policy: 'higher' })).outcomes.closure < base);
ok('lower-threshold policy raises it', run(snowy, {}, st({ policy: 'lower' })).outcomes.closure > base);
is('custom policy clamped to custom_max', SS.shifts({ policy: 'custom', custom: 999 })[0].shift, CFG.scenarios.policy.custom_max);
ok('lower regional tolerance raises it', run(snowy, {}, st({ region: 'lower' })).outcomes.closure > base);
is('snow days used: OFF by default → no shift', SS.shifts({ daysUsed: 6 }).length, 0);
ok('snow days used: small heuristic → small positive shift', (() => { const s = SS.shifts({ daysHeuristic: 'small', daysUsed: 6 }); return s.length === 1 && s[0].shift > 0 && s[0].shift <= 5; })());

/* ---------- plowing ---------- */
const pl = SS.plow({ road_km: 120, plows: 6, snow_cm: 10, start: '02:00', school: '08:00', treat_delay_min: 30 });
const sp = S.interp(10, CFG.scenarios.plow.speed_kmh);
is('plow: hours = km × passes ÷ (plows × speed)', pl.hours, S.round(120 * 1 / (6 * sp), 2));
is('plow: finish clock', pl.finish, SS.fmtClock(120 + 30 + 120 / (6 * sp) * 60));
const pl2 = SS.plow({ road_km: 400, plows: 2, snow_cm: 30, start: '04:00', school: '08:00', treat_delay_min: 0 });
ok('plow: deep snow, few plows → overlaps commute, part uncleared', pl2.overlapsCommute && pl2.clearedByCommute < 100 && pl2.remainingKm > 0, pl2);
is('plow: invalid inputs', [SS.plow({ road_km: 0, plows: 1, snow_cm: 1 }).error, SS.plow({ road_km: 10, plows: 0.5, snow_cm: 1 }).error, SS.plow({ road_km: 10, plows: 1, snow_cm: -1 }).error], ['road', 'plows', 'snow']);

/* ---------- what-if ---------- */
const cmp = SS.compare([
  { name: 'A', values: V({ snow_cm: 10, temp_c: -2, timing: 'overnight' }) },
  { name: 'B', values: V({ snow_cm: 20, temp_c: -6, timing: 'commute', commute: 'snowy' }) },
  { name: 'C', values: V({ snow_cm: 2, timing: 'evening' }) }
], SET, NONE);
ok('what-if: B above A, C below A', cmp[1].outcomes.closure > cmp[0].outcomes.closure && cmp[2].outcomes.closure < cmp[0].outcomes.closure);
ok('what-if: biggest changed factor reported', cmp[1].biggest && cmp[1].biggest.label, cmp[1].biggest);
ok('what-if: timing change flagged', cmp[1].timingChanged === true);
is('what-if: limited to compare.max', SS.compare(Array(5).fill({ name: 'x', values: V({}) }), SET, NONE).length, CFG.scenarios.compare.max);

/* ---------- invalid / extreme ---------- */
const ext = run({ snow_cm: 500, ice_mm: 100, temp_c: -60, wind_kmh: 250, gust_kmh: 250, vis: 'verypoor', timing: 'commute', commute: 'whiteout' });
ok('extreme values stay finite and capped', Number.isFinite(ext.res.pressure) && ext.outcomes.closure <= CFG.model.max_closure, ext.outcomes);
const junk = run({ snow_cm: 'abc', temp_c: 'NaN', wind_kmh: -5, vis: 'nope', timing: 'never', commute: '??' });
ok('junk input → no NaN, falls back to known keys', Number.isFinite(junk.res.pressure) && junk.res.values.vis === 'good' && junk.res.values.timing === 'overnight');

/* ---------- units ---------- */
is('units: in ↔ cm, °F ↔ °C, mph ↔ km/h round-trip', [S.fromDisplay('snow', S.toDisplay('snow', 10, 'us'), 'us'), S.fromDisplay('temp', 32, 'us'), S.fromDisplay('wind', S.toDisplay('wind', 50, 'us'), 'us')].map((x) => Math.round(x * 1e6) / 1e6), [10, 0, 50]);
ok('unit system never changes the result', (() => { const v = V({ snow_cm: 12.7, temp_c: -5 }); return JSON.stringify(run(v).outcomes) === JSON.stringify(run(V({ snow_cm: S.fromDisplay('snow', 5, 'us'), temp_c: S.fromDisplay('temp', 23, 'us') })).outcomes); })());

/* ================= CENTRAL-CONFIG TESTS (edit data, not code) ================= */
function withCfg(patch, fn) {
  const c = exportCfg(SLUG, patch), e = load();
  e.snowday.configure(c); e.snowdayScenarios.configure(c);
  return fn(e.snowday, e.snowdayScenarios);
}
const probe = { snow_cm: 8, timing: 'overnight', commute: 'snowy' };
const ref = run(probe).outcomes.closure;
// 1. snowfall threshold — the snow points table in winter-weather.php
const snowTable = CFG.model.snow.map(([x, y]) => [x, Math.min(100, y * 1.6)]);
const c1r = withCfg({ winter: { model: { snow: snowTable } } }, (s2, ss2) => ss2.run(V(probe), SET, NONE).outcomes.closure);
ok('CONFIG: changing ONLY the snowfall table changes the result', c1r !== ref, [ref, c1r]);
is('CONFIG: restored config gives the original result', withCfg({}, (s2, ss2) => ss2.run(V(probe), SET, NONE).outcomes.closure), ref);
// 2. road weight — commute.snowy.points
const c2r = withCfg({ winter: { commute: { snowy: { points: 25 } } } }, (s2, ss2) => ss2.run(V(probe), SET, NONE).outcomes.closure);
ok('CONFIG: changing ONLY a road weight changes the result', c2r > ref, [ref, c2r]);
// 3. policy threshold — scenarios.policy.profiles.higher.shift
const pRef = run(probe, {}, st({ policy: 'higher' })).outcomes.closure;
const c3r = withCfg({ scenarios: { policy: { profiles: { higher: { shift: 20 } } } } }, (s2, ss2) => ss2.run(V(probe), SET, st({ policy: 'higher' })).outcomes.closure);
ok('CONFIG: changing ONLY a policy shift changes the result', c3r < pRef, [pRef, c3r]);
// 4. outcome split
const c4r = withCfg({ scenarios: { outcomes: { split: { overnight: 0 } } } }, (s2, ss2) => ss2.run(V(probe), SET, NONE).outcomes);
ok('CONFIG: changing ONLY the delay/early split moves the outcome', c4r.delay === 0 && c4r.early > 0, c4r);

/* ================= NO MAGIC NUMBERS ================= */
const engine = fs.readFileSync(path.join(ROOT, 'assets/js/lib/snowday-scenarios.js'), 'utf8')
  .replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/.*$/gm, '').replace(/'[^']*'/g, "''");
const lits = (engine.match(/(?<![\w.])\d+(\.\d+)?(?![\w.])/g) || []).map(Number);
const ALLOWED = [0, 1, 2, 3, 9, 10, 11, 12, 23, 24, 30, 59, 60, 100, 1440];   // clock (12/24 h, 59 min, regex groups), percent and counting arithmetic only
const bad = [...new Set(lits.filter((n) => !ALLOWED.includes(n)))];
ok('scenario engine has no model constants (only clock / % arithmetic)', bad.length === 0, bad);
const sd = fs.readFileSync(path.join(ROOT, 'assets/js/lib/snowday.js'), 'utf8');
ok('snowday.js visual mixing now read from config (no 0.8 / 0.6 / 0.9 literals in visual())', !/coldK \* 0\.|windK \* 0\.|\* 0\.8 :/.test(sd));

/* ================= YEAR ROLL-FORWARD ================= */
['assets/js/lib/snowday.js', 'assets/js/lib/snowday-scenarios.js', 'assets/js/lib/winter-scene.js', 'assets/js/calculators/winter-calc.js', 'assets/js/calculators/winter-scenarios.js', 'assets/js/calculators/wind-chill.js', 'app/includes/winter-ui.php', 'app/config/winter-weather-scenarios.php'].forEach((f) => {
  const src = fs.readFileSync(path.join(ROOT, f), 'utf8');
  ok('no year (20xx) in ' + f, !/\b20[2-9]\d\b/.test(src), (src.match(/\b20[2-9]\d\b/g) || []).slice(0, 3));
  ok('no Date()/getFullYear in ' + f, !/new Date|getFullYear|Date\.now/.test(src));
});

/* ================= NO LIVE DATA ================= */
['assets/js/lib/snowday.js', 'assets/js/lib/snowday-scenarios.js', 'assets/js/lib/winter-scene.js', 'assets/js/calculators/winter-calc.js', 'assets/js/calculators/winter-scenarios.js'].forEach((f) => {
  const src = fs.readFileSync(path.join(ROOT, f), 'utf8');
  ok('no network / geolocation / storage in ' + f, !/fetch\(|XMLHttpRequest|navigator\.geolocation|sendBeacon|WebSocket|localStorage|sessionStorage|\/api\/|openweather|open-meteo|api\.weather/i.test(src));
  ok('no eval / Function / innerHTML in ' + f, !/\beval\(|new Function|innerHTML|outerHTML|insertAdjacentHTML/.test(src));
});

/* ================= KEYWORD REGISTRY ================= */
const reg = JSON.parse(cp.execFileSync(php, ['-r', 'echo json_encode(require $argv[1]);', path.join(ROOT, 'app/config/winter-weather-keywords.php')]).toString());
const pagesCfg = cp.execFileSync(php, ['-r', 'echo json_encode(array_keys((require $argv[1])["pages"]));', path.join(ROOT, 'app/config/winter-weather.php')]).toString();
ok('keyword registry targets only existing pages', reg.keywords.every((k) => JSON.parse(pagesCfg).includes(k.page)), reg.keywords.filter((k) => !JSON.parse(pagesCfg).includes(k.page)).map((k) => k.page));
ok('registry has no volume / KD / CPC fields', reg.keywords.every((k) => !('volume' in k) && !('kd' in k) && !('cpc' in k)));
ok('no calculator code reads the keyword registry', !['assets/js/lib/snowday.js', 'assets/js/lib/snowday-scenarios.js', 'assets/js/calculators/winter-calc.js', 'assets/js/calculators/winter-scenarios.js', 'app/includes/winter-ui.php'].some((f) => /winter-weather-keywords/.test(fs.readFileSync(path.join(ROOT, f), 'utf8'))));
const arts = cp.execFileSync(php, ['-r', '$a=require $argv[1]; $o=[]; foreach($a as $p=>$s){foreach($s as $x){$o[]=$p."#".$x["id"];}} echo json_encode($o);', path.join(ROOT, 'app/config/winter-weather-articles.php')]).toString();
const SECTIONS = JSON.parse(arts);
ok('every registry section exists in the article', reg.keywords.every((k) => SECTIONS.includes(k.page + '#' + k.section)), reg.keywords.filter((k) => !SECTIONS.includes(k.page + '#' + k.section)).map((k) => k.page + '#' + k.section));
ok('every scenario mode links to an existing article section', Object.values(CFG.scenarios.modes).every((m) => SECTIONS.includes(SLUG + '#' + m.section)));

console.log('\n' + pass + ' passed, ' + fail + ' failed');
process.exit(fail ? 1 : 0);
